// 政策与时间节点（方案第八节 区域六；第十七节：时间节点必须可追溯或可配置）
// 当前为前端可配置常量；上线后应改为读取后台配置接口（如 /api/config/policy），
// 避免把时间写死在前端代码里。所有展示均标注「以官方当年公布为准」。

export type PolicyTime = {
  key: string;
  label: string;
  date: string; // YYYY-MM-DD 或 "待官方公布"
  note?: string;
};

export const POLICY_TIMES: PolicyTime[] = [
  { key: "batch1", label: "第一批志愿（优质/示范/重点高中）填报", date: "待官方公布", note: "具体批次名称、时间与录取规则以陕西省/西安市教育部门当年公布为准" },
  { key: "batch2", label: "第二批志愿（普通高中及其他批次）填报", date: "待官方公布", note: "具体批次名称、时间与录取规则以陕西省/西安市教育部门当年公布为准" },
  { key: "deadline", label: "志愿填报截止时间", date: "待官方公布" },
  { key: "admit", label: "录取通知发放时间", date: "待官方公布" },
  { key: "enroll", label: "开学报名时间", date: "待官方公布" },
  { key: "officialLine", label: "城六区普高录取控制线公布", date: "2026-07-17", note: "已公布：普高 492.0 / 体育艺术特长生 295.2 / 试点综合高中班 465.0（640 分制）" },
];

export function getPolicyTime(key: string): PolicyTime | undefined {
  return POLICY_TIMES.find((p) => p.key === key);
}

// 长安成长地图 · 步骤18 Phase 2A · 研究数据 → 可发布数据 转换层
//
// 设计边界（与项目既有约束一致，且严格受限于步骤18 Phase 2A 授权）：
//  - 本模块是「纯内存 / 临时校验」转换层：输入两份 CSV 文本，输出结构化结果，
//    不写文件、不写数据库、不修改 verifiedSchools、不接入 /growth 页面、不改动 DEMO_SCHOOLS。
//  - 只接受显式列名映射，绝不按列位置猜测（与 importSchoolsCsv 的 HEADER_MAP 原则一致）。
//  - 发布资格判定一律复用既有统一发布闸门 importSchoolsCsv / isOwnershipConfirmed，
//    绝不复刻第二套规则；本模块的「候选过滤器」只做「能否进入闸门」的前置门禁
//    （例如必须 VERIFIED、性质必须已确认），不重判发布资格本身。
//  - 过渡政策字段（enrollmentPolicyStatus / enrollmentPolicyNote）仅作为兼容性附加字段
//    承载在本地扩展类型上，政策已核实 ≠ 招生范围已核实，绝不因此提升 verificationStatus
//    或 verificationLevel。
//  - 无浏览器 API、无浏览器存储读取，可在 Node 与边缘运行时安全复用。

import {
  parseCsv,
  importSchoolsCsv,
  isOwnershipConfirmed,
  STAGE_FROM_CN,
  type ImportResult,
} from "./growth-school-import.ts";
import type { GrowthSchool, SchoolOwnership } from "./growth-schools.ts";

// ===== 类型定义 =====

export type ResearchVerificationStatus = "VERIFIED" | "UNVERIFIED" | string;

// 研究层记录（读取自 16-CSV，13 列，按列名显式映射）
export interface ResearchSchoolRecord {
  schoolId: string;
  schoolName: string;
  stage: string; // 中文：幼儿园 / 小学 / 初中
  district: string;
  enrollmentScope: string;
  sourceName: string;
  sourceUrl: string;
  sourcePublishedAt: string;
  evidenceSummary: string;
  verificationStatus: ResearchVerificationStatus;
  enrollmentPolicyStatus: string;
  enrollmentPolicyNote: string;
}

// 合并后的记录：研究字段 + 来自 15.5 的性质归一化与地址
export interface MergedResearchRecord extends ResearchSchoolRecord {
  ownershipNormalized: SchoolOwnership;
  address: string;
}

// 兼容性扩展：发布候选在 GrowthSchool 之上附加过渡政策字段。
// 注意：不修改共享的 GrowthSchool 类型（避免触碰 DEMO_SCHOOLS 与未授权文件），
// 仅在转换层本地扩展；字段名严格按步骤18授权（enrollmentPolicyStatus / enrollmentPolicyNote）。
export interface PublishableSchoolCandidate extends GrowthSchool {
  enrollmentPolicyStatus?: string;
  enrollmentPolicyNote?: string;
}

export interface ExcludedSchool {
  schoolId: string;
  schoolName: string;
  verificationStatus: ResearchVerificationStatus;
  ownershipNormalized: SchoolOwnership;
  enrollmentPolicyStatus?: string;
  enrollmentPolicyNote?: string;
  reasons: string[];
  sourceTrace: SourceTraceEntry[];
}

export interface SourceTraceEntry {
  schoolId: string;
  field: string;
  sourceFile: string;
  sourceColumn: string;
  sourceValue: string;
}

export interface ConversionError {
  code: string;
  message: string;
  schoolId?: string;
}

export interface ConversionWarning {
  code?: string;
  message: string;
  schoolId?: string;
}

export interface ResearchToPublishableCounts {
  totalResearch: number;
  verifiedResearch: number;
  unverifiedResearch: number;
  candidatesEligibleByVerification: number;
  ownershipConfirmedAmongVerified: number;
  candidatesPassedFilter: number;
  convertedToPublishable: number;
  excludedTotal: number;
  excludedUnverified: number;
  excludedUnknownOwnership: number;
  publishableFromGate: number;
}

export interface ResearchToPublishableResult {
  convertedSchools: PublishableSchoolCandidate[];
  excludedSchools: ExcludedSchool[];
  errors: ConversionError[];
  warnings: ConversionWarning[];
  counts: ResearchToPublishableCounts;
  sourceTrace: SourceTraceEntry[];
  // 透传底层统一发布闸门的原始结果，便于审计，不用于页面展示。
  gate: ImportResult;
}

// ===== 常量 =====

// 官方域名后缀白名单：西安市及各区教育局 / 政府门户均为 .gov.cn。
const OFFICIAL_DOMAIN_SUFFIXES = [".gov.cn"];

// 研究层 CSV（16-CSV）必需的列名（显式，按名匹配）
const RESEARCH_REQUIRED_COLUMNS = [
  "schoolId",
  "schoolName",
  "stage",
  "district",
  "enrollmentScope",
  "sourceName",
  "sourceUrl",
  "sourcePublishedAt",
  "evidenceSummary",
  "verificationStatus",
  "enrollmentPolicyStatus",
  "enrollmentPolicyNote",
];

// 15.5 性质补采 CSV 必需列
const OWNERSHIP_REQUIRED_COLUMNS = ["学校ID", "ownershipNormalized"];

// 办学性质归一化（英文）→ 中文表头值，用于构造 V2 CSV 喂给统一闸门。
const OWNERSHIP_TO_CN: Record<string, string> = {
  public: "公办",
  private: "民办",
  inclusive: "融合/特教",
  unknown: "暂未核实",
};

// V2 CSV 表头（覆盖统一闸门 REQUIRED_HEADERS + A 级发布必备字段）
const V2_HEADERS = [
  "学校ID",
  "学校名称",
  "学段",
  "所在区",
  "学校性质",
  "详细地址",
  "招生范围",
  "信息来源名称",
  "信息来源链接",
  "可信等级",
  "采集日期",
  "备注",
  "是否演示数据",
];

// ===== 解析辅助 =====

function isOfficialDomain(url: string): boolean {
  if (!/^https?:\/\//i.test(url)) return false;
  try {
    const host = new URL(url).hostname;
    return OFFICIAL_DOMAIN_SUFFIXES.some(
      (suffix) => host === suffix.slice(1) || host.endsWith(suffix),
    );
  } catch {
    return false;
  }
}

function csvCell(value: string): string {
  if (/[",\n\r]/.test(value)) {
    return '"' + value.replace(/"/g, '""') + '"';
  }
  return value;
}

function getByHeader(
  row: { normalized: string[] },
  headerIndex: Map<string, number>,
  header: string,
): string {
  const idx = headerIndex.get(header);
  if (idx === undefined) return "";
  return (row.normalized[idx] ?? "").trim();
}

// ===== 解析：研究层 16-CSV =====

function parseResearchCsv(
  text: string,
  errors: ConversionError[],
  warnings: ConversionWarning[],
): ResearchSchoolRecord[] {
  const { headers, rows } = parseCsv(text);
  const missing = RESEARCH_REQUIRED_COLUMNS.filter((h) => !headers.includes(h));
  if (missing.length > 0) {
    errors.push({
      code: "research_missing_header",
      message: `研究层 CSV 缺少必需列：${missing.join(", ")}`,
    });
    return [];
  }
  const idx = new Map(headers.map((h, i) => [h, i]));
  const out: ResearchSchoolRecord[] = [];
  for (const r of rows) {
    out.push({
      schoolId: getByHeader(r, idx, "schoolId"),
      schoolName: getByHeader(r, idx, "schoolName"),
      stage: getByHeader(r, idx, "stage"),
      district: getByHeader(r, idx, "district"),
      enrollmentScope: getByHeader(r, idx, "enrollmentScope"),
      sourceName: getByHeader(r, idx, "sourceName"),
      sourceUrl: getByHeader(r, idx, "sourceUrl"),
      sourcePublishedAt: getByHeader(r, idx, "sourcePublishedAt"),
      evidenceSummary: getByHeader(r, idx, "evidenceSummary"),
      verificationStatus: getByHeader(r, idx, "verificationStatus"),
      enrollmentPolicyStatus: getByHeader(r, idx, "enrollmentPolicyStatus"),
      enrollmentPolicyNote: getByHeader(r, idx, "enrollmentPolicyNote"),
    });
  }
  return out;
}

// ===== 解析：15.5 性质补采 CSV（仅取 ownershipNormalized 与 详细地址_补采） =====

function parseOwnershipCsv(
  text: string,
  errors: ConversionError[],
  warnings: ConversionWarning[],
): Map<string, { ownershipNormalized: string; address: string }> {
  const { headers, rows } = parseCsv(text);
  const missing = OWNERSHIP_REQUIRED_COLUMNS.filter((h) => !headers.includes(h));
  if (missing.length > 0) {
    errors.push({
      code: "ownership_missing_header",
      message: `性质补采 CSV 缺少必需列：${missing.join(", ")}`,
    });
    return new Map();
  }
  const idx = new Map(headers.map((h, i) => [h, i]));
  const map = new Map<string, { ownershipNormalized: string; address: string }>();
  for (const r of rows) {
    const id = getByHeader(r, idx, "学校ID");
    if (!id) continue;
    const ownershipNormalized = getByHeader(r, idx, "ownershipNormalized");
    const addrIdx = idx.get("详细地址_补采");
    const address = addrIdx !== undefined ? (r.normalized[addrIdx] ?? "").trim() : "";
    map.set(id, { ownershipNormalized, address });
  }
  return map;
}

// ===== 来源追溯 =====

function buildTrace(m: MergedResearchRecord): SourceTraceEntry[] {
  return [
    { schoolId: m.schoolId, field: "schoolId", sourceFile: "16-CSV", sourceColumn: "schoolId", sourceValue: m.schoolId },
    { schoolId: m.schoolId, field: "schoolName", sourceFile: "16-CSV", sourceColumn: "schoolName", sourceValue: m.schoolName },
    { schoolId: m.schoolId, field: "stage", sourceFile: "16-CSV", sourceColumn: "stage", sourceValue: m.stage },
    { schoolId: m.schoolId, field: "district", sourceFile: "16-CSV", sourceColumn: "district", sourceValue: m.district },
    { schoolId: m.schoolId, field: "enrollmentScope", sourceFile: "16-CSV", sourceColumn: "enrollmentScope", sourceValue: m.enrollmentScope },
    { schoolId: m.schoolId, field: "verificationStatus", sourceFile: "16-CSV", sourceColumn: "verificationStatus", sourceValue: m.verificationStatus },
    { schoolId: m.schoolId, field: "sourceUrl", sourceFile: "16-CSV", sourceColumn: "sourceUrl", sourceValue: m.sourceUrl },
    { schoolId: m.schoolId, field: "enrollmentPolicyStatus", sourceFile: "16-CSV", sourceColumn: "enrollmentPolicyStatus", sourceValue: m.enrollmentPolicyStatus },
    { schoolId: m.schoolId, field: "ownershipNormalized", sourceFile: "15.5-CSV", sourceColumn: "ownershipNormalized", sourceValue: m.ownershipNormalized },
    { schoolId: m.schoolId, field: "address", sourceFile: "15.5-CSV", sourceColumn: "详细地址_补采", sourceValue: m.address },
  ];
}

// ===== 构造 V2 CSV 喂给统一发布闸门 =====

function buildV2Csv(candidates: MergedResearchRecord[]): string {
  const lines = [V2_HEADERS.join(",")];
  for (const c of candidates) {
    const row = [
      c.schoolId,
      c.schoolName,
      c.stage,
      c.district,
      OWNERSHIP_TO_CN[c.ownershipNormalized] ?? "暂未核实",
      c.address,
      c.enrollmentScope,
      c.sourceName,
      c.sourceUrl,
      "A", // 候选已通过 verificationStatus=VERIFIED 前置门禁，统一映射为 A（官方公开）
      c.sourcePublishedAt,
      c.evidenceSummary,
      "false", // 真实研究数据，非演示数据
    ];
    lines.push(row.map(csvCell).join(","));
  }
  return lines.join("\n");
}

// ===== 主入口 =====

export interface ConvertResearchInput {
  // 研究层招生范围补采 CSV（16-CSV，含 verificationStatus 与过渡政策字段）
  researchCsv: string;
  // 15.5 性质补采 CSV（ownershipNormalized 等基础字段）
  ownershipCsv: string;
}

export function convertResearchToPublishable(
  input: ConvertResearchInput,
): ResearchToPublishableResult {
  const errors: ConversionError[] = [];
  const warnings: ConversionWarning[] = [];
  const sourceTrace: SourceTraceEntry[] = [];

  const research = parseResearchCsv(input.researchCsv, errors, warnings);
  const ownershipMap = parseOwnershipCsv(input.ownershipCsv, errors, warnings);

  if (errors.length > 0) {
    // 结构缺失即无法继续，返回空结果并附错误。
    return {
      convertedSchools: [],
      excludedSchools: [],
      errors,
      warnings,
      counts: emptyCounts(),
      sourceTrace,
      gate: emptyGate(),
    };
  }

  // 按 schoolId 合并研究层与性质层
  const merged: MergedResearchRecord[] = research.map((r) => {
    const own = ownershipMap.get(r.schoolId);
    if (!own) {
      warnings.push({
        code: "ownership_missing",
        message: `学校 ${r.schoolId} 在 15.5 性质补采中未匹配到，按 unknown 处理（将排除）。`,
        schoolId: r.schoolId,
      });
    }
    return {
      ...r,
      ownershipNormalized: (own?.ownershipNormalized as SchoolOwnership) ?? "unknown",
      address: own?.address ?? "",
    };
  });

  const candidates: MergedResearchRecord[] = [];
  const excluded: ExcludedSchool[] = [];

  for (const m of merged) {
    const reasons: string[] = [];
    if (!/^[\w-]+$/.test(m.schoolId)) reasons.push("schoolId 非法或缺失");
    if (m.schoolName.trim().length === 0) reasons.push("schoolName 缺失");
    if (!(m.stage in STAGE_FROM_CN)) reasons.push(`stage 非法：${m.stage}`);
    if (m.district.trim().length === 0) reasons.push("district 缺失");
    if (!isOfficialDomain(m.sourceUrl)) reasons.push("来源链接非官方域名（非 .gov.cn）");
    if (m.verificationStatus !== "VERIFIED") {
      reasons.push(`verificationStatus=${m.verificationStatus}（招生范围未核实，非 VERIFIED）`);
    }
    if (!isOwnershipConfirmed(m.ownershipNormalized)) {
      reasons.push(`办学性质未确认（ownership=${m.ownershipNormalized}）`);
    }

    const trace = buildTrace(m);
    trace.forEach((t) => sourceTrace.push(t));

    if (reasons.length === 0) {
      candidates.push(m);
    } else {
      excluded.push({
        schoolId: m.schoolId,
        schoolName: m.schoolName,
        verificationStatus: m.verificationStatus,
        ownershipNormalized: m.ownershipNormalized,
        enrollmentPolicyStatus: m.enrollmentPolicyStatus || undefined,
        enrollmentPolicyNote: m.enrollmentPolicyNote || undefined,
        reasons,
        sourceTrace: trace,
      });
    }
  }

  // 调用既有统一发布闸门（禁止复制第二套规则）
  const v2csv = buildV2Csv(candidates);
  const gate = importSchoolsCsv(v2csv);
  const policyById = new Map(candidates.map((c) => [c.schoolId, c]));

  const converted: PublishableSchoolCandidate[] = [];
  for (const s of gate.publishableSchools) {
    const rec = policyById.get(s.id);
    converted.push({
      ...s,
      enrollmentPolicyStatus: rec?.enrollmentPolicyStatus || undefined,
      enrollmentPolicyNote: rec?.enrollmentPolicyNote || undefined,
    });
  }

  // 候选通过前置门禁但被底层闸门拦截者，也归入 excluded（附闸门原因）
  for (const res of gate.results) {
    if (res.publishable) continue;
    const rec = policyById.get(res.schoolId ?? "");
    if (!rec) continue;
    const trace = buildTrace(rec);
    trace.forEach((t) => sourceTrace.push(t));
    excluded.push({
      schoolId: rec.schoolId,
      schoolName: rec.schoolName,
      verificationStatus: rec.verificationStatus,
      ownershipNormalized: rec.ownershipNormalized,
      enrollmentPolicyStatus: rec.enrollmentPolicyStatus || undefined,
      enrollmentPolicyNote: rec.enrollmentPolicyNote || undefined,
      reasons: [...res.publishReasons],
      sourceTrace: trace,
    });
    res.publishBlockers.forEach((b) =>
      sourceTrace.push({
        schoolId: rec.schoolId,
        field: b.field ?? "",
        sourceFile: "publish-gate",
        sourceColumn: b.code,
        sourceValue: b.message,
      }),
    );
  }

  // 计数
  const verifiedResearch = research.filter((r) => r.verificationStatus === "VERIFIED").length;
  const counts: ResearchToPublishableCounts = {
    totalResearch: research.length,
    verifiedResearch,
    unverifiedResearch: research.length - verifiedResearch,
    candidatesEligibleByVerification: verifiedResearch,
    ownershipConfirmedAmongVerified: merged.filter(
      (m) => m.verificationStatus === "VERIFIED" && isOwnershipConfirmed(m.ownershipNormalized),
    ).length,
    candidatesPassedFilter: candidates.length,
    convertedToPublishable: converted.length,
    excludedTotal: excluded.length,
    excludedUnverified: excluded.filter((e) => e.verificationStatus !== "VERIFIED").length,
    excludedUnknownOwnership: excluded.filter((e) => e.ownershipNormalized === "unknown").length,
    publishableFromGate: gate.publishableRows,
  };

  return {
    convertedSchools: converted,
    excludedSchools: excluded,
    errors,
    warnings,
    counts,
    sourceTrace,
    gate,
  };
}

// ===== 空结果辅助 =====

function emptyCounts(): ResearchToPublishableCounts {
  return {
    totalResearch: 0,
    verifiedResearch: 0,
    unverifiedResearch: 0,
    candidatesEligibleByVerification: 0,
    ownershipConfirmedAmongVerified: 0,
    candidatesPassedFilter: 0,
    convertedToPublishable: 0,
    excludedTotal: 0,
    excludedUnverified: 0,
    excludedUnknownOwnership: 0,
    publishableFromGate: 0,
  };
}

function emptyGate(): ImportResult {
  return {
    headers: [],
    rows: [],
    schools: [],
    publishableSchools: [],
    errors: [],
    warnings: [],
    results: [],
    totalRows: 0,
    validRows: 0,
    publishableRows: 0,
    blockedRows: 0,
    publishBlockers: [],
  };
}

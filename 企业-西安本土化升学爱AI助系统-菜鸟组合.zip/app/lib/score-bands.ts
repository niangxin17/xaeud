// 2026 城六区中考总分一分一段表 → 累计位次
// 数据：chengliu-score-bands.json（用户提供的官方图片交叉确认版，覆盖 633–511 分，共 123 档）
// 匹配模块：laoyou-score-rank-matcher.js（原样接入；本文件仅做小数取整与表外外推的封装）
import bandsData from "../../data/chengliu-score-bands.json";
import { scoreToRank as rawScoreToRank } from "./laoyou-score-rank-matcher.js";

export type BandResult = {
  ok: boolean;
  exact: boolean;
  score: number;
  rank: number;
  countAtScore?: number;
  source: "band" | "extrapolated" | "model";
  message: string;
};

export const CHENGLIU_BAND_META = {
  min: 511,
  max: 633,
  maxScore: 640,
  totalAtMin: 50541, // 511 分及以上累计人数（来自官方图片）
  topRankAtMax: 86, // 633 分（表内最高）累计位次
};

// 取表内最低两档，按真实尾部斜率对 511 分以下线性外推（与官方表连续、单调，避免跳变）
function bandTailSlope(): number {
  const bands = (bandsData as any).bands as { score: number; cumulative_rank: number }[];
  const sorted = [...bands].sort((a, b) => a.score - b.score);
  const lo = sorted[0]; // 511
  const lo2 = sorted[1]; // 512
  return Math.max(1, lo.cumulative_rank - lo2.cumulative_rank);
}

// 分数（支持小数，向下取整到整数档）→ 城六区累计位次。
// 仅当分数非法时返回 ok:false；低于 511 / 高于 633 均给出带 source 标注的估算，绝不伪造“精准”。
export function chengliuScoreToRank(score: number): BandResult {
  const s = Math.floor(Number(score));
  if (!Number.isFinite(s)) {
    return { ok: false, exact: false, score: s, rank: 0, source: "model", message: "请输入有效分数。" };
  }

  // 高于表内最高分（633）：表内最高(633,86) → 满分(640,1) 线性外推
  if (s > CHENGLIU_BAND_META.max) {
    const { max, topRankAtMax, maxScore } = CHENGLIU_BAND_META;
    const t = Math.max(0, Math.min(1, (s - max) / (maxScore - max)));
    const rank = Math.max(1, Math.round(topRankAtMax * (1 - t) + 1 * t));
    return {
      ok: true,
      exact: false,
      score: s,
      rank,
      source: "extrapolated",
      message: `分数高于表内最高 ${max} 分，按表外线性外推，位次约 ${rank}（需官方完整分段表确认）。`,
    };
  }

  // 表内整数档（511–633）：调用原样接入的匹配模块，精准
  const res: any = rawScoreToRank(s, bandsData as any);
  if (res.ok && res.exact) {
    return {
      ok: true,
      exact: true,
      score: s,
      rank: res.rank,
      countAtScore: res.countAtScore,
      source: "band",
      message: res.message || `城六区 ${s} 分，累计位次约 ${res.rank}。`,
    };
  }

  // 低于 511 分：按官方表尾部斜率线性外推（连续、单调，标注为估算，不伪造精准）
  // 累计位次不可能超过城六区考生总数(82000)，超出部分截断，避免无意义数值
  if (s < CHENGLIU_BAND_META.min) {
    const slope = bandTailSlope();
    const rank = Math.min(82000, CHENGLIU_BAND_META.totalAtMin + (CHENGLIU_BAND_META.min - s) * slope);
    return {
      ok: true,
      exact: false,
      score: s,
      rank: Math.round(rank),
      source: "model",
      message: `${s} 分低于官方分段表起始（${CHENGLIU_BAND_META.min} 分），按表尾斜率外推，位次约 ${Math.round(rank)}（估算，非官方分段表）。`,
    };
  }

  return { ok: false, exact: false, score: s, rank: 0, source: "model", message: res?.message || "无法计算位次。" };
}

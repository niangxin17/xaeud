// 长安成长地图 · 学校对比逻辑（纯函数，无 React、无副作用、无浏览器存储）
// 职责：维护「已选对比学校 ID 列表」的增删去重、数量上限与同学段约束，
//       并定义唯一一份对比维度清单供各端渲染。
// 隐私与持久化边界：对比选择仅存在于当前页面的内存中，刷新即清空；
//       本模块绝不读写浏览器本地存储，也绝不序列化学校对象或任何家庭信息。

// 说明：显式带 .ts 后缀，使本模块既能被打包器解析，也能被 `node --test --experimental-strip-types` 直接运行。
import type { GrowthSchool, GrowthStage } from "./growth-schools.ts";
import {
  formatEmpty,
  formatVerification,
  formatAdmissionLine,
  formatCutHistory,
  OWNERSHIP_LABELS,
} from "./growth-schools.ts";

// ===== 数量约束 =====
export const MIN_COMPARE = 2; // 至少选择 2 所才能打开对比
export const MAX_COMPARE = 4; // 最多同时对比 4 所

export type CompareChangeReason =
  | "added"
  | "removed"
  | "duplicate"
  | "full"
  | "stage_mismatch"
  | "invalid";

export interface CompareChangeResult {
  ids: string[];
  ok: boolean;
  reason: CompareChangeReason;
}

// ===== 选择集合操作（全部返回新数组，不修改入参）=====

export function isInCompare(ids: string[], id: string): boolean {
  return ids.includes(id);
}

export function isCompareFull(ids: string[]): boolean {
  return ids.length >= MAX_COMPARE;
}

// 至少 MIN_COMPARE 所才允许打开对比视图。
export function canOpenCompare(ids: string[]): boolean {
  return ids.length >= MIN_COMPARE;
}

// 当前对比已锁定的学段：取列表中第一所学校的学段。
// 列表为空时返回 null，表示尚未锁定，可重新选择任意学段。
export function compareLockedStage(
  ids: string[],
  stageById: Record<string, GrowthStage>,
): GrowthStage | null {
  for (const id of ids) {
    const st = stageById[id];
    if (st) return st;
  }
  return null;
}

export function addToCompare(
  ids: string[],
  id: string,
  opts?: { stage?: GrowthStage; lockedStage?: GrowthStage | null },
): CompareChangeResult {
  if (typeof id !== "string" || id.trim().length === 0) {
    return { ids: [...ids], ok: false, reason: "invalid" };
  }
  // 自动去重：已存在则原样返回。
  if (isInCompare(ids, id)) {
    return { ids: [...ids], ok: false, reason: "duplicate" };
  }
  // 同学段限制：一旦锁定学段，不同学段的学校拒绝加入，列表保持不变。
  if (opts && opts.stage && opts.lockedStage && opts.stage !== opts.lockedStage) {
    return { ids: [...ids], ok: false, reason: "stage_mismatch" };
  }
  // 上限保护：第 MAX_COMPARE+1 所不得加入。
  if (isCompareFull(ids)) {
    return { ids: [...ids], ok: false, reason: "full" };
  }
  return { ids: [...ids, id], ok: true, reason: "added" };
}

export function removeFromCompare(ids: string[], id: string): string[] {
  return ids.filter((x) => x !== id);
}

export function toggleCompare(
  ids: string[],
  id: string,
  opts?: { stage?: GrowthStage; lockedStage?: GrowthStage | null },
): CompareChangeResult {
  if (isInCompare(ids, id)) {
    return { ids: removeFromCompare(ids, id), ok: true, reason: "removed" };
  }
  return addToCompare(ids, id, opts);
}

// ===== 对比维度（唯一定义，供桌面表格与手机分组共用）=====

export interface CompareDimension {
  key: string;
  label: string;
  value: (school: GrowthSchool) => string;
}

// 标签数组转文本：空数组显示「暂未核实」，不留空白单元格。
function joinTags(tags: string[]): string {
  return tags && tags.length > 0 ? tags.join("、") : "暂未核实";
}

// 12 个对比维度，顺序即展示顺序。全部走 formatEmpty，缺失一律「暂未核实」。
export const COMPARE_DIMENSIONS: CompareDimension[] = [
  { key: "district", label: "区域", value: (s) => formatEmpty(s.district) },
  {
    key: "ownership",
    label: "性质",
    value: (s) => formatEmpty(OWNERSHIP_LABELS[s.ownership]),
  },
  {
    key: "annualCost",
    label: "年度费用",
    value: (s) => formatEmpty(s.tuitionText),
  },
  {
    key: "commute",
    label: "通勤参考",
    value: (s) => formatEmpty(s.commuteText),
  },
  {
    key: "curriculum",
    label: "课程",
    value: (s) => joinTags(s.curriculumTags),
  },
  {
    key: "foreignTeacher",
    label: "外教",
    value: (s) => formatEmpty(s.foreignTeacherText),
  },
  {
    key: "classSize",
    label: "班额",
    value: (s) => formatEmpty(s.classSizeText),
  },
  { key: "meal", label: "餐食", value: (s) => formatEmpty(s.mealText) },
  {
    key: "management",
    label: "管理",
    value: (s) => formatEmpty(s.managementText),
  },
  {
    key: "enrollment",
    label: "招生信息",
    value: (s) => formatEmpty(s.enrollmentScope),
  },
  {
    key: "updatedAt",
    label: "更新时间",
    value: (s) => formatEmpty(s.sourceUpdatedAt),
  },
  {
    key: "verification",
    label: "可信等级",
    // 始终显示完整文字（如「官方公开」「暂未核实」），不显示单个字母。
    value: (s) => formatVerification(s.verificationLevel),
  },
];

// 高中阶段（中考录取）对比维度：仅当对比集合含高中时叠加，避免义务教育阶段学校出现空维度。
// 普通高中为考试录取，无学区划片，展示录取分数线 / 层次 / 批次 / 单元等。
const SENIOR_DIMENSIONS: CompareDimension[] = [
  {
    key: "admissionScore",
    label: "2026录取线",
    value: (s) => formatAdmissionLine(s),
  },
  {
    key: "admissionTier",
    label: "办学层次",
    value: (s) => formatEmpty(s.admissionTier ?? ""),
  },
  {
    key: "admissionBatch",
    label: "录取批次",
    value: (s) =>
      s.admissionBatch != null ? `第${s.admissionBatch}批` : "暂未核实",
  },
  {
    key: "admissionUnit",
    label: "招生单元",
    value: (s) => formatEmpty(s.admissionUnit ?? ""),
  },
  {
    key: "enrollmentPlan",
    label: "招生计划",
    value: (s) =>
      s.enrollmentPlan != null ? `${s.enrollmentPlan} 人` : "暂未核实",
  },
  {
    key: "directionalPlan",
    label: "定向计划",
    value: (s) =>
      s.directionalPlan != null ? `${s.directionalPlan} 人` : "暂未核实",
  },
  {
    key: "cutHistory",
    label: "历年分数线",
    value: (s) => formatCutHistory(s),
  },
  {
    key: "keyClass",
    label: "重点班",
    value: (s) => formatEmpty(s.keyClassInfo ?? ""),
  },
];

export interface CompareCell {
  schoolId: string;
  text: string;
}

export interface CompareRow {
  key: string;
  label: string;
  cells: CompareCell[];
}

// 按选择顺序取回学校对象，未知 ID 直接忽略。
export function resolveCompareSchools(
  all: GrowthSchool[],
  ids: string[],
): GrowthSchool[] {
  const byId = new Map(all.map((s) => [s.id, s]));
  const out: GrowthSchool[] = [];
  for (const id of ids) {
    const s = byId.get(id);
    if (s) out.push(s);
  }
  return out;
}

// 生成对比表：行 = 维度，列 = 学校。手机端按行分组渲染，桌面端按表格渲染。
export function buildCompareRows(schools: GrowthSchool[]): CompareRow[] {
  const hasSenior = schools.some((s) => s.stage === "senior");
  const dims = hasSenior
    ? [...COMPARE_DIMENSIONS, ...SENIOR_DIMENSIONS]
    : COMPARE_DIMENSIONS;
  return dims.map((d) => ({
    key: d.key,
    label: d.label,
    cells: schools.map((s) => ({
      schoolId: s.id,
      text: formatEmpty(d.value(s)),
    })),
  }));
}

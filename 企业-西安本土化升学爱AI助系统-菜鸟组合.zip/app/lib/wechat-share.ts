// 微信 JS-SDK 分享封装：动态加载 jweixin，按当前页面签名，配置转发卡片。
// 关键约束：wx.config 在所有页面生命周期内只能成功调用一次；SPA 路由切换时只更新分享内容，不再重签名。
// 签名 URL 使用当前页面 location.href.split('#')[0]（与后端 /api/wechat/js-config 约定一致）。

const JWEIXIN_SRC = "https://res.wx.qq.com/open/js/jweixin-1.6.0.js";

let sdkPromise: Promise<any> | null = null;
let configReady = false; // 本次页面生命周期内是否已成功 wx.config
let pendingApply: (() => void) | null = null; // config 成功后需要补应用的分享内容

export function loadWechatSdk(): Promise<any> {
  if (typeof window === "undefined") return Promise.reject(new Error("no-window"));
  const w = window as any;
  if (w.wx && w.wx.config) return Promise.resolve(w.wx);
  if (sdkPromise) return sdkPromise;
  sdkPromise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = JWEIXIN_SRC;
    script.async = true;
    script.onload = () => (w.wx ? resolve(w.wx) : reject(new Error("jweixin 加载异常")));
    script.onerror = () => reject(new Error("jweixin 脚本加载失败（网络受限）"));
    document.head.appendChild(script);
  });
  return sdkPromise;
}

function fetchConfig(pageUrl: string): Promise<{
  appId: string;
  timestamp: number;
  nonceStr: string;
  signature: string;
}> {
  return fetch(`/api/wechat/js-config?url=${encodeURIComponent(pageUrl)}`, {
    credentials: "same-origin",
  }).then((res) => {
    if (!res.ok) throw new Error("签名接口返回 " + res.status);
    return res.json();
  });
}

export interface ShareContent {
  title: string;
  desc: string;
  link: string;
  imgUrl: string;
}

export function applyShareContent(wx: any, content: ShareContent) {
  const safe = {
    title: content.title,
    desc: content.desc,
    link: content.link,
    imgUrl: content.imgUrl,
    success: () => {},
  };
  try {
    if (wx.updateAppMessageShareData) wx.updateAppMessageShareData(safe);
  } catch (_) {}
  try {
    if (wx.updateTimelineShareData) wx.updateTimelineShareData(safe);
  } catch (_) {}
  // 老版本微信（7.0 以下）兼容
  try {
    if (wx.onMenuShareAppMessage) wx.onMenuShareAppMessage(safe);
  } catch (_) {}
  try {
    if (wx.onMenuShareTimeline)
      wx.onMenuShareTimeline({ title: content.title, link: content.link, imgUrl: content.imgUrl, success: () => {} });
  } catch (_) {}
}

/**
 * 初始化微信分享：首次调用执行 wx.config 并配置内容；后续调用仅更新分享内容。
 * @returns Promise<boolean> 是否成功完成配置/刷新
 */
export async function initWechatShare(content: ShareContent): Promise<boolean> {
  let wx: any;
  try {
    wx = await loadWechatSdk();
  } catch (e) {
    return false; // 非微信环境或脚本加载失败：静默降级
  }

  if (configReady) {
    applyShareContent(wx, content);
    return true;
  }

  const pageUrl = location.href.split("#")[0];
  let cfg: Awaited<ReturnType<typeof fetchConfig>>;
  try {
    cfg = await fetchConfig(pageUrl);
  } catch (e) {
    return false;
  }

  return new Promise<boolean>((resolve) => {
    wx.config({
      debug: false,
      appId: cfg.appId,
      timestamp: cfg.timestamp,
      nonceStr: cfg.nonceStr,
      signature: cfg.signature,
      jsApiList: [
        "updateAppMessageShareData",
        "updateTimelineShareData",
        "onMenuShareAppMessage",
        "onMenuShareTimeline",
      ],
    });
    wx.ready(() => {
      configReady = true;
      applyShareContent(wx, content);
      if (pendingApply) {
        pendingApply();
        pendingApply = null;
      }
      resolve(true);
    });
    wx.error((err: any) => {
      // 签名失效（如 URL 变化、ticket 过期）时，尝试用当前 URL 重签一次
      pendingApply = () => applyShareContent(wx, content);
      resolve(false);
    });
  });
}

export function isWechat(): boolean {
  if (typeof navigator === "undefined") return false;
  return /MicroMessenger/i.test(navigator.userAgent);
}

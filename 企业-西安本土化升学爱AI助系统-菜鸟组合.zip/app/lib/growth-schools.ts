// 长安成长地图 · 学校数据模型（首版）
// 字段依据 docs/product/changan-growth-map/reference/西安学校数据采集模板.csv 的真实列定义，
// 前端首版仅保留必要字段。本模块为纯数据与工具函数，无副作用，可被服务端组件与客户端组件共用。

export type GrowthStage = "kindergarten" | "primary" | "junior" | "senior";
export type SchoolOwnership = "public" | "private" | "inclusive" | "unknown";
// 可信度等级：A 官方公开 / B 学校确认 / C 平台核验 / D 家长反馈 / UNVERIFIED 暂未核实
export type VerificationLevel = "A" | "B" | "C" | "D" | "UNVERIFIED";

export interface GrowthSchool {
  id: string;
  name: string;
  stage: GrowthStage;
  district: string;
  ownership: SchoolOwnership;
  address: string;
  // 年度费用说明（对应采集模板「年度学费」等费用列的汇总口径）
  tuitionText: string;
  // 通勤参考（周边交通/校车等客观描述，不做优劣判断）
  commuteText: string;
  mealText: string;
  // 是否配备外教（对应采集模板「是否外教」列）
  foreignTeacherText: string;
  // 班额（对应采集模板「班额」列）
  classSizeText: string;
  // 管理风格（对应采集模板「管理风格」列，客观描述）
  managementText: string;
  curriculumTags: string[];
  featureTags: string[];
  enrollmentScope: string;
  registrationMaterials: string;
  sourceName: string;
  sourceUrl: string;
  sourceUpdatedAt: string;
  verificationLevel: VerificationLevel;
  verificationLabel: string;
  verificationNote: string;
  // 过渡招生政策（仅高新等民转公过渡校赋值；政策已核实 ≠ 招生范围已核实，绝不因此提升可信等级）
  enrollmentPolicyStatus?: "transition_policy_verified" | null;
  enrollmentPolicyNote?: string | null;
  // ===== 高中阶段（中考录取）专用字段 =====
  // 普通高中为考试录取，无学区划片；下列字段来自西安市教育局 2026 年普通高中招生计划（data/schools.json）。
  // 均为可选；缺失时前端按「暂未核实」呈现，绝不编造分数线或学校名次。
  admissionScore?: number | null; // 2026 年统招录取分数线（官方）
  admissionBatch?: number | null; // 录取批次（1/2…）
  admissionTier?: string | null; // 办学层次：省示范 / 省标 / 普高
  directionalPlan?: number | null; // 定向生招生计划数
  admissionUnit?: string | null; // 招生单元（如 城六区）
  enrollmentPlan?: number | null; // 年度招生计划数
  cutHistory?: Record<string, number> | null; // 历年录取分数线 {2023,2024,2025,2026}
  keyClassInfo?: string | null; // 重点班 / 特色班说明
  // 所有示例记录必须为 true；真实资料库接入后由采集流程赋 false。
  isDemo: boolean;
  // 保留字段：来自采集模板中「前端暂不展示」的列（官方电话、各项费用明细、
  // 师资反馈、复核人员等）。仅用于追溯与后台复核，任何前端组件都不得读取或渲染。
  // 空值不进入此对象（与「空字符串转为 undefined」一致）。
  extra?: Record<string, string>;
  // ===== 官方分类标签（honors / branchOf，非优劣排序）=====
  // 来自教育局/教育厅官方名单的类别标识，例如「省示范高中」「市一级幼儿园」
  // 「名校+牵头校」「名校+成员校」。仅为官方分类，不含任何优劣次序；
  // 严禁填入「第X名」等优劣表述（growth-nav 闸门禁用此类词）。
  honors?: string[];
  // 名校分校的母校/牵头校全称（如「西北工业大学附属中学」）；非分校则为 null。
  branchOf?: string | null;
}

// ===== 可信度标签映射（完整文字，禁止只显示字母） =====
export const VERIFICATION_LABELS: Record<VerificationLevel, string> = {
  A: "官方公开",
  B: "学校确认",
  C: "平台核验",
  D: "家长反馈",
  UNVERIFIED: "暂未核实",
};

// ===== 阶段映射 =====
export const STAGE_LABELS: Record<GrowthStage, string> = {
  kindergarten: "幼儿园",
  primary: "小学",
  junior: "初中",
  senior: "高中",
};

// ===== 办学性质映射 =====
export const OWNERSHIP_LABELS: Record<SchoolOwnership, string> = {
  public: "公办",
  private: "民办",
  inclusive: "融合/特教",
  unknown: "暂未核实",
};

// 允许的可信度枚举，供校验与 UI 下拉使用。
export const VERIFICATION_LEVELS: VerificationLevel[] = [
  "A",
  "B",
  "C",
  "D",
  "UNVERIFIED",
];

// ===== 格式化辅助函数 =====

// 空字段统一显示为「暂未核实」，不得隐藏成已知事实。
export function formatEmpty(value: string | undefined | null): string {
  return value && value.trim().length > 0 ? value : "暂未核实";
}

// 可信度等级 -> 完整文字标签。
export function formatVerification(level: VerificationLevel): string {
  return VERIFICATION_LABELS[level] ?? "暂未核实";
}

// 来源：名称缺失显示「来源待补充」；URL 为空返回 null，调用方不得生成假链接。
export function formatSource(
  sourceName: string,
  sourceUrl: string,
): { label: string; url: string | null } {
  const name = formatEmpty(sourceName);
  const url = sourceUrl && sourceUrl.trim().length > 0 ? sourceUrl.trim() : "";
  return { label: name, url: url || null };
}

// 是否为高中阶段（中考录取，无学区划片，展示录取分数线而非招生范围）。
export function isSeniorSchool(s: GrowthSchool): boolean {
  return s.stage === "senior";
}

// 高中阶段录取摘要：2026 录取线 + 办学层次；分数缺失按「暂未核实」。
export function formatAdmissionLine(s: GrowthSchool): string {
  if (s.stage !== "senior") return formatEmpty(s.enrollmentScope);
  const score = s.admissionScore ?? null;
  const tier =
    s.admissionTier && s.admissionTier.trim().length > 0 ? s.admissionTier : null;
  const scoreText = score != null ? `${score} 分` : "暂未核实";
  return tier ? `${scoreText} · ${tier}` : scoreText;
}

// 历年录取分数线拼接（用于详情与对比），如「2023:668 / 2024:670」。
export function formatCutHistory(s: GrowthSchool): string {
  const h = s.cutHistory;
  if (!h) return "暂未核实";
  const parts = Object.keys(h)
    .sort()
    .map((y) => `${y}:${h[y]}`);
  return parts.length > 0 ? parts.join(" / ") : "暂未核实";
}

// ===== 筛选函数 =====

export interface SchoolFilter {
  stage: GrowthStage | "all";
  keyword: string;
  district: string; // "all" 表示不限
  ownership: SchoolOwnership | "all";
  verification: VerificationLevel | "all";
}

export function emptyFilter(): SchoolFilter {
  return {
    stage: "all",
    keyword: "",
    district: "all",
    ownership: "all",
    verification: "all",
  };
}

export function filterSchools(
  schools: GrowthSchool[],
  f: SchoolFilter,
): GrowthSchool[] {
  const kw = f.keyword.trim().toLowerCase();
  return schools.filter((s) => {
    if (f.stage !== "all" && s.stage !== f.stage) return false;
    if (f.district !== "all" && s.district !== f.district) return false;
    if (f.ownership !== "all" && s.ownership !== f.ownership) return false;
    if (f.verification !== "all" && s.verificationLevel !== f.verification)
      return false;
    if (kw.length > 0) {
      const haystack = [
        s.name,
        s.district,
        s.address,
        s.enrollmentScope,
        ...s.curriculumTags,
        ...s.featureTags,
      ]
        .join(" ")
        .toLowerCase();
      if (!haystack.includes(kw)) return false;
    }
    return true;
  });
}

// 去重后的所在区列表（供筛选下拉）。
export function distinctDistricts(schools: GrowthSchool[]): string[] {
  return Array.from(new Set(schools.map((s) => s.district))).sort();
}

// ===== 演示数据（虚构示例机构，不代表任何真实学校） =====
// 约束：isDemo=true、verificationLevel=UNVERIFIED；所有事实字段留空以「暂未核实」呈现，
// 不虚构真实学校的名称、收费、师资、外教、口碑或优劣次序等内容。
// 注意：演示数据默认不得在正式环境展示，须经显式演示开关（NEXT_PUBLIC_GROWTH_DEMO_MODE=1）
// 通过 getVisibleGrowthSchools 才进入页面；生产构建与变量缺失时一律不展示。
export const DEMO_SCHOOLS: GrowthSchool[] = [
  {
    id: "DEMO-K-001",
    name: "示例幼儿园A",
    stage: "kindergarten",
    district: "雁塔区",
    ownership: "public",
    address: "",
    tuitionText: "",
    commuteText: "",
    mealText: "",
    foreignTeacherText: "",
    classSizeText: "",
    managementText: "",
    curriculumTags: ["游戏化主题课程"],
    featureTags: ["户外活动"],
    enrollmentScope: "",
    registrationMaterials: "",
    sourceName: "演示数据",
    sourceUrl: "",
    sourceUpdatedAt: "",
    verificationLevel: "UNVERIFIED",
    verificationLabel: "暂未核实",
    verificationNote: "虚构示例机构，不代表真实学校信息。",
    isDemo: true,
  },
  {
    id: "DEMO-P-001",
    name: "示例小学B",
    stage: "primary",
    district: "碑林区",
    ownership: "private",
    address: "",
    tuitionText: "",
    commuteText: "",
    mealText: "",
    foreignTeacherText: "",
    classSizeText: "",
    managementText: "",
    curriculumTags: ["基础素养课程"],
    featureTags: ["家校沟通"],
    enrollmentScope: "",
    registrationMaterials: "",
    sourceName: "演示数据",
    sourceUrl: "",
    sourceUpdatedAt: "",
    verificationLevel: "UNVERIFIED",
    verificationLabel: "暂未核实",
    verificationNote: "虚构示例机构，不代表真实学校信息。",
    isDemo: true,
  },
  {
    id: "DEMO-J-001",
    name: "示例初中C",
    stage: "junior",
    district: "未央区",
    ownership: "inclusive",
    address: "",
    tuitionText: "",
    commuteText: "",
    mealText: "",
    foreignTeacherText: "",
    classSizeText: "",
    managementText: "",
    curriculumTags: ["综合实践课程"],
    featureTags: ["校园活动"],
    enrollmentScope: "",
    registrationMaterials: "",
    sourceName: "演示数据",
    sourceUrl: "",
    sourceUpdatedAt: "",
    verificationLevel: "UNVERIFIED",
    verificationLabel: "暂未核实",
    verificationNote: "虚构示例机构，不代表真实学校信息。",
    isDemo: true,
  },
];

// ===== 发布闸门：单条记录可否进入正式公开数据 =====
// 仅当「非演示数据」且「可信等级非 UNVERIFIED」且「满足该等级必填字段」时为可发布。
// 刻意与基础校验（valid）区分：valid 只代表通过字段格式校验，publishable 还需可信等级与来源齐全。
export function isPublishable(s: GrowthSchool): boolean {
  if (s.isDemo) return false;
  const level = s.verificationLevel;
  if (level === "UNVERIFIED") return false;
  const name = (s.name || "").trim();
  const sourceName = (s.sourceName || "").trim();
  const sourceUrl = (s.sourceUrl || "").trim();
  const updatedAt = (s.sourceUpdatedAt || "").trim();
  const note = (s.verificationNote || "").trim();
  if (name.length === 0) return false;
  switch (level) {
    case "A":
      return (
        sourceName.length > 0 &&
        sourceUrl.length > 0 &&
        updatedAt.length > 0 &&
        note.length > 0
      );
    case "B":
      return sourceName.length > 0 && updatedAt.length > 0 && note.length > 0;
    case "C":
      return sourceName.length > 0 && updatedAt.length > 0 && note.length > 0;
    case "D":
      return note.length > 0;
    default:
      return false;
  }
}

// ===== 可见学校选择（生产展示闸门） =====
// 规则：
// 1. demoMode=true：返回 DEMO_SCHOOLS 并保持演示标识（仅用于本地功能演示）。
// 2. demoMode=false（默认 / 生产 / 变量缺失）：只返回 isDemo=false 且通过发布闸门的真实数据；
//    当前真实数据源尚未接入公开页面（CSV 发布闸门与网页未自动连接），verifiedSchools 为空，
//    故返回空数组，由页面展示「核验中」空状态。
// 3. 禁止把 valid（基础校验通过）误当 publishable；禁止把示例/UNVERIFIED 混入正式数据。
export function getVisibleGrowthSchools({
  demoMode,
  verifiedSchools,
}: {
  demoMode: boolean;
  verifiedSchools: GrowthSchool[];
}): GrowthSchool[] {
  if (demoMode) {
    return DEMO_SCHOOLS.map((s) => ({ ...s }));
  }
  return verifiedSchools.filter((s) => isPublishable(s));
}

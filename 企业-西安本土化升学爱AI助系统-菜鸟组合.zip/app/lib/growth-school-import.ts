// 长安成长地图 · 学校 CSV 导入、字段映射、质量校验与发布闸门（纯 TS，无第三方依赖）
//
// 设计边界（与项目其它约束一致）：
//  - 本模块只做「解析 + 映射 + 校验 + 发布资格判断」，不写数据库、不接网络、不渲染、不部署；
//  - 不根据学校名称推断区县、性质或可信等级，所有字段都来自显式列；
//  - 校验对「内部 CSV」同样严格：公式注入、脚本链接、个人联系方式、违规承诺一律拒绝；
//  - 缺失值统一存为空串，由前端 formatEmpty 呈现为「暂未核实」，不在本模块编造事实；
//  - 办学性质未确认（空 / 非法枚举 / unknown）的记录一律不得进入 publishableSchools，
//    错误码 OWNERSHIP_UNVERIFIED；此类记录仍是「结构有效」记录，只是不可发布。
//
// 三套口径必须分开，不得互相代称：
//   validRows（结构有效） ≠ publishableRows（通过发布闸门） ≠ 资料完整（核心字段已核实）。
//   publishable=true 也不等于「允许公开展示」，公开展示需另经人工审批。

import type {
  GrowthSchool,
  GrowthStage,
  SchoolOwnership,
  VerificationLevel,
} from "./growth-schools.ts";
import { VERIFICATION_LABELS } from "./growth-schools.ts";

// ===== 表头 -> 字段映射（显式，按中文表头名匹配，绝不按列位置静默映射）=====
// 值 "extra" 表示「保留但前端不展示」的列，仅进入 school.extra 供追溯。
export type MappedField = keyof GrowthSchool | "extra";

export const HEADER_MAP: Record<string, MappedField> = {
  学校ID: "id",
  学校名称: "name",
  学段: "stage",
  所在区: "district",
  学校性质: "ownership",
  详细地址: "address",
  官方电话: "extra",
  官方网站: "extra",
  年度学费: "tuitionText",
  餐费: "extra",
  校车费: "extra",
  住宿费: "extra",
  其他费用: "extra",
  课程体系: "curriculumTags",
  是否外教: "foreignTeacherText",
  班额: "classSizeText",
  师资稳定性: "extra",
  老师耐心反馈: "extra",
  餐食情况: "mealText",
  午休情况: "extra",
  户外活动: "extra",
  家校沟通: "extra",
  管理风格: "managementText",
  招生范围: "enrollmentScope",
  报名时间: "extra",
  报名材料: "registrationMaterials",
  官方报名入口: "extra",
  特色标签: "featureTags",
  适合家庭: "extra",
  不适合家庭: "extra",
  信息来源名称: "sourceName",
  信息来源链接: "sourceUrl",
  可信等级: "verificationLevel",
  采集日期: "sourceUpdatedAt",
  复核人员: "extra",
  复核状态: "extra",
  备注: "verificationNote",
  是否演示数据: "isDemo",
};

// 保留字段白名单：仅以下「非个人、非敏感」的机构元数据可进入标准化结果的 extra。
// 排除项说明：
//  - 官方电话：定义为公开机构联系电话，但导入阶段无法核验其公开来源，
//    为避免把未经验证的电话带入标准化结果，本步骤不纳入 extra（如确有公开来源，
//    应在后续采集流程中单独核验后再决定留存方式）；
//  - 复核人员：属于个人姓名，严禁进入标准化结果（隐私底线）。
export const EXTRA_ALLOWED = new Set<string>([
  "官方网站",
  "餐费",
  "校车费",
  "住宿费",
  "其他费用",
  "师资稳定性",
  "老师耐心反馈",
  "午休情况",
  "户外活动",
  "家校沟通",
  "报名时间",
  "官方报名入口",
  "适合家庭",
  "不适合家庭",
  "复核状态",
]);

// 必要表头：缺失任一项，整份导入直接报错，不静默继续。
// 注：信息来源名称/链接/采集日期按可信等级在「发布闸门」中条件必填，
//     因此不列入文件级必填（避免对 UNVERIFIED 记录过度要求）。
export const REQUIRED_HEADERS: string[] = [
  "学校ID",
  "学校名称",
  "学段",
  "所在区",
  "学校性质",
  "可信等级",
  "是否演示数据",
];

// ===== 枚举白名单（不认识的枚举值一律报错，绝不自动猜测）=====
export const STAGE_FROM_CN: Record<string, GrowthStage> = {
  幼儿园: "kindergarten",
  小学: "primary",
  初中: "junior",
};

export const OWNERSHIP_FROM_CN: Record<string, SchoolOwnership> = {
  公办: "public",
  民办: "private",
  "融合/特教": "inclusive",
  暂未核实: "unknown",
};

// ===== 发布闸门错误码（结构化，便于 CLI 输出与 CI 断言）=====
// 这些码只表示「不得进入正式发布」，不代表 CSV 结构非法：
// 被拦截的记录仍然计入 validRows，只是不进入 publishableSchools。
export const OWNERSHIP_UNVERIFIED = "OWNERSHIP_UNVERIFIED";

export const PUBLISH_BLOCK_CODES = {
  ownershipUnverified: OWNERSHIP_UNVERIFIED,
  verificationUnverified: "VERIFICATION_UNVERIFIED",
  sourceNameMissing: "SOURCE_NAME_MISSING",
  sourceUrlMissing: "SOURCE_URL_MISSING",
  sourceDateMissing: "SOURCE_DATE_MISSING",
  verificationNoteMissing: "VERIFICATION_NOTE_MISSING",
} as const;

// 办学性质「已确认」白名单：只有归一化为以下值才算已确认。
// unknown（暂未核实）、空值、无法归一化的写法一律视为未确认。
//
// 与采集纪律一致（务必保持）：
//   「财政全额拨款」「事业单位法人」「举办单位为教育主管部门」「县级教育部门」
//   等表述只能写入来源说明，不得据此推断办学性质；本闸门只认官方正文里
//   字面出现的性质枚举（公办 / 民办 / 融合特教）经显式列映射后的结果。
const CONFIRMED_OWNERSHIPS = new Set<SchoolOwnership>([
  "public",
  "private",
  "inclusive",
]);

export function isOwnershipConfirmed(
  ownership: SchoolOwnership | null | undefined,
): boolean {
  if (ownership === null || ownership === undefined) return false;
  return CONFIRMED_OWNERSHIPS.has(ownership);
}

export const VERIFICATION_FROM_CN: Record<string, VerificationLevel> = {
  A: "A",
  官方公开: "A",
  B: "B",
  学校确认: "B",
  C: "C",
  平台核验: "C",
  D: "D",
  家长反馈: "D",
  UNVERIFIED: "UNVERIFIED",
  暂未核实: "UNVERIFIED",
};

// 标签统一分隔符：竖线、顿号、全/半角逗号、分号。
const TAG_SEPARATORS = /[|、，,；;]/;

// 违规承诺用语（与项目真实性闸门口径一致，不得出现保证录取、内部名额等）。
const ILLEGAL_PROMISE =
  /(保证录取|内部名额|保过|包录取|百分百录取|稳录|名校直通车|内部指标|提前锁定名额|录取承诺|内部名额预留)/;

// 明文个人联系方式（手机号 / 身份证号）。微信号等难以可靠识别，交由人工复核。
const MOBILE_RE = /(?<!\d)1[3-9]\d{9}(?!\d)/;
const ID_RE = /(?<!\d)\d{17}[\dXx](?!\d)|(?<!\d)\d{15}(?!\d)/;

// ===== 解析结果类型 =====
export interface ParsedRow {
  // 文件行号（含表头第 1 行），用于错误定位。
  rowNumber: number;
  raw: string[];
  normalized: string[];
}

export interface ImportError {
  line?: number;
  field?: string;
  code: string;
  message: string;
}

export interface ImportRowResult {
  rowNumber: number;
  schoolId: string | null;
  school: GrowthSchool | null;
  errors: ImportError[];
  warnings: string[];
  // 是否通过发布闸门（可进入正式发布）。
  publishable: boolean;
  // 不可发布原因（仅当 publishable=false 时有内容）。
  publishReasons: string[];
  // 不可发布原因的结构化形式（含错误码），与 publishReasons 顺序一一对应。
  publishBlockers: ImportError[];
}

export interface ImportResult {
  headers: string[];
  rows: ParsedRow[];
  schools: GrowthSchool[];
  publishableSchools: GrowthSchool[];
  errors: ImportError[];
  warnings: string[];
  results: ImportRowResult[];
  totalRows: number;
  validRows: number;
  publishableRows: number;
  // 结构合法但被发布闸门拦截的行数。恒等式：validRows = publishableRows + blockedRows。
  blockedRows: number;
  // 发布闸门拦截明细（仅汇总「结构合法但被拦截」的行；结构非法的行已在 errors 中报告，
  // 不在此重复计数，避免同一行被同时计入两套口径）。
  publishBlockers: ImportError[];
}

export interface ImportOptions {
  // 可选：数据行数上限，防止超大文件拖垮导入（0/未设表示不限制）。
  maxRows?: number;
}

// ===== 行号表：每个字符位置对应的文件行号 =====
function lineNumbers(text: string): number[] {
  const lines: number[] = new Array(text.length);
  let cur = 1;
  for (let k = 0; k < text.length; k++) {
    lines[k] = cur;
    const c = text[k];
    if (c === "\n") cur++;
    else if (c === "\r" && text[k + 1] !== "\n") cur++;
  }
  return lines;
}

// ===== RFC 4180 词法分析：处理引号字段、字段内逗号、双引号转义、CRLF/LF =====
function tokenize(input: string): { line: number; fields: string[] }[] {
  const lines = lineNumbers(input);
  const records: { line: number; fields: string[] }[] = [];
  let field = "";
  let fields: string[] = [];
  let inQuotes = false;
  const n = input.length;
  let i = 0;
  let recStartLine = 1;
  let recStarted = false;

  const beginRecord = () => {
    if (!recStarted) {
      recStartLine = lines[i] ?? 1;
      recStarted = true;
    }
  };
  const pushRecord = () => {
    records.push({ line: recStartLine, fields });
    fields = [];
    field = "";
    recStarted = false;
  };

  while (i < n) {
    const c = input[i];
    if (inQuotes) {
      if (c === '"') {
        if (input[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i++;
        continue;
      }
      beginRecord();
      field += c;
      i++;
      continue;
    }
    if (c === '"') {
      beginRecord();
      inQuotes = true;
      i++;
      continue;
    }
    if (c === ",") {
      beginRecord();
      fields.push(field);
      field = "";
      i++;
      continue;
    }
    if (c === "\r" || c === "\n") {
      beginRecord();
      fields.push(field);
      pushRecord();
      if (c === "\r" && input[i + 1] === "\n") i += 2;
      else i++;
      continue;
    }
    beginRecord();
    field += c;
    i++;
    continue;
  }
  if (inQuotes) {
    // 未闭合的双引号字段属于 CSV 语法错误，应显式报错而非静默截断。
    throw new Error(`CSV 语法错误：第 ${recStartLine} 行的双引号字段未闭合。`);
  }
  if (recStarted || field.length > 0 || fields.length > 0) {
    fields.push(field);
    pushRecord();
  }
  return records;
}

// 解析 CSV 文本为表头与数据行（已处理 BOM / CRLF / 引号 / 转义 / 空行）。
export function parseCsv(text: string): { headers: string[]; rows: ParsedRow[] } {
  let stripped = text;
  // UTF-8 BOM 去除
  if (stripped.charCodeAt(0) === 0xfeff) stripped = stripped.slice(1);

  const records = tokenize(stripped);
  // 丢弃完全空白的行（形如 [""] 的空行）。
  const nonEmpty = records.filter(
    (r) => !(r.fields.length === 1 && r.fields[0].trim() === ""),
  );
  if (nonEmpty.length === 0) {
    return { headers: [], rows: [] };
  }
  const headerRec = nonEmpty[0];
  const headers = headerRec.fields.map((f) => f.trim());
  const rows: ParsedRow[] = nonEmpty.slice(1).map((r) => ({
    rowNumber: r.line,
    raw: r.fields,
    normalized: r.fields.map((f) => f.trim()),
  }));
  return { headers, rows };
}

// ===== 基础校验辅助 =====
function isValidDate(v: string): boolean {
  const m = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(v);
  if (!m) return false;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return false;
  const dt = new Date(y, mo - 1, d);
  return (
    dt.getFullYear() === y &&
    dt.getMonth() === mo - 1 &&
    dt.getDate() === d
  );
}

function splitTags(value: string): string[] {
  const out: string[] = [];
  for (const part of value.split(TAG_SEPARATORS)) {
    const s = part.trim();
    if (s.length === 0) continue;
    if (!out.includes(s)) out.push(s);
  }
  return out;
}

// 办学性质未确认时生成发布闸门拦截项；已确认则返回 null。
// 三种未确认情形分别给出可定位的说明，便于人工补证时知道差在哪一步。
function ownershipBlocker(
  ownership: SchoolOwnership | null,
  ownCn: string,
  line: number,
): ImportError | null {
  if (isOwnershipConfirmed(ownership)) return null;
  let detail: string;
  if (ownCn.length === 0) {
    detail = "办学性质为空";
  } else if (ownership === "unknown") {
    detail = `办学性质为「${ownCn}」（归一化为 unknown）`;
  } else {
    detail = `办学性质「${ownCn}」无法归一化`;
  }
  return {
    line,
    field: "学校性质",
    code: OWNERSHIP_UNVERIFIED,
    message: `${detail}：办学性质未经官方来源确认，不得进入正式发布。`,
  };
}

// ===== 单行映射 + 校验 + 发布闸门 =====
function mapAndValidateRow(
  row: ParsedRow,
  headerIndex: Map<string, number>,
  headerMap: Record<string, MappedField>,
  seenIds: Set<string>,
): ImportRowResult {
  const errors: ImportError[] = [];
  const warnings: string[] = [];
  const line = row.rowNumber;

  const get = (header: string): string => {
    const idx = headerIndex.get(header);
    if (idx === undefined) return "";
    return (row.normalized[idx] ?? "").trim();
  };

  // 收集所有映射值，用于全局文本安全检查（公式注入 / 脚本 / 违规承诺 / 个人联系方式）。
  const allValues: { field: string; value: string }[] = [];
  for (const header of Object.keys(headerMap)) {
    const idx = headerIndex.get(header);
    if (idx === undefined) continue;
    allValues.push({ field: header, value: (row.raw[idx] ?? "").trim() });
  }

  for (const { field, value } of allValues) {
    const v = value.trim();
    if (v.length === 0) continue;
    if (v.startsWith("=") || v.startsWith("+") || v.startsWith("-") || v.startsWith("@")) {
      errors.push({
        line,
        field,
        code: "formula_injection",
        message: `字段「${field}」疑似表格公式注入（以 = + - @ 开头），已拒绝。`,
      });
    }
    if (/<script|javascript:|onerror\s*=|onload\s*=|data:/i.test(v)) {
      errors.push({
        line,
        field,
        code: "script_injection",
        message: `字段「${field}」含脚本或危险链接，已拒绝。`,
      });
    }
    if (ILLEGAL_PROMISE.test(v)) {
      errors.push({
        line,
        field,
        code: "illegal_promise",
        message: `字段「${field}」含违规承诺用语，已拒绝。`,
      });
    }
    if (MOBILE_RE.test(v) || ID_RE.test(v)) {
      errors.push({
        line,
        field,
        code: "pii_contact",
        message: `字段「${field}」含明文个人联系方式（手机号/身份证号），已拒绝。`,
      });
    }
  }

  // 必填基础字段
  const idRaw = get("学校ID");
  const id = idRaw.trim();
  if (id.length === 0) {
    errors.push({ line, field: "学校ID", code: "missing_id", message: "学校ID 不能为空。" });
  } else if (!/^[\w-]+$/.test(id)) {
    errors.push({
      line,
      field: "学校ID",
      code: "invalid_id",
      message: "学校ID 只能含字母、数字、下划线或连字符。",
    });
  } else if (seenIds.has(id)) {
    errors.push({ line, field: "学校ID", code: "duplicate_id", message: `学校ID 重复：${id}。` });
  }

  const name = get("学校名称");
  if (name.length === 0) {
    errors.push({ line, field: "学校名称", code: "missing_name", message: "学校名称 不能为空。" });
  }

  const stageCn = get("学段");
  let stage: GrowthStage | null = null;
  if (stageCn.length === 0) {
    errors.push({ line, field: "学段", code: "missing_stage", message: "学段 不能为空。" });
  } else if (!(stageCn in STAGE_FROM_CN)) {
    errors.push({
      line,
      field: "学段",
      code: "invalid_stage",
      message: `不认识的学段枚举值：${stageCn}（仅支持 幼儿园/小学/初中）。`,
    });
  } else {
    stage = STAGE_FROM_CN[stageCn];
  }

  const district = get("所在区");
  if (district.length === 0) {
    errors.push({ line, field: "所在区", code: "missing_district", message: "所在区 不能为空。" });
  }

  const ownCn = get("学校性质");
  let ownership: SchoolOwnership | null = null;
  if (ownCn.length === 0) {
    errors.push({ line, field: "学校性质", code: "missing_ownership", message: "学校性质 不能为空。" });
  } else if (!(ownCn in OWNERSHIP_FROM_CN)) {
    errors.push({
      line,
      field: "学校性质",
      code: "invalid_ownership",
      message: `不认识的办学性质枚举值：${ownCn}。`,
    });
  } else {
    ownership = OWNERSHIP_FROM_CN[ownCn];
  }

  const lvlCn = get("可信等级");
  let level: VerificationLevel | null = null;
  if (lvlCn.length === 0) {
    errors.push({ line, field: "可信等级", code: "missing_verification", message: "可信等级 不能为空。" });
  } else if (!(lvlCn in VERIFICATION_FROM_CN)) {
    errors.push({
      line,
      field: "可信等级",
      code: "invalid_verification",
      message: `不认识的可信等级：${lvlCn}（仅支持 A/官方公开, B/学校确认, C/平台核验, D/家长反馈, UNVERIFIED/暂未核实）。`,
    });
  } else {
    level = VERIFICATION_FROM_CN[lvlCn];
  }

  const demoRaw = get("是否演示数据").toLowerCase();
  let isDemo = false;
  if (demoRaw.length === 0) {
    errors.push({
      line,
      field: "是否演示数据",
      code: "missing_isdemo",
      message: "是否演示数据 不能为空，必须为 true 或 false。",
    });
  } else if (demoRaw === "true") {
    isDemo = true;
  } else if (demoRaw === "false") {
    isDemo = false;
  } else {
    errors.push({
      line,
      field: "是否演示数据",
      code: "invalid_isdemo",
      message: `是否演示数据 必须为 true 或 false，收到：${demoRaw}。`,
    });
  }

  const sourceUrl = get("信息来源链接");
  if (sourceUrl.length > 0 && !/^https?:\/\//i.test(sourceUrl)) {
    errors.push({
      line,
      field: "信息来源链接",
      code: "invalid_source_url",
      message: `信息来源链接 必须是 http/https 链接：${sourceUrl}`,
    });
  }

  const updatedAt = get("采集日期");
  if (updatedAt.length > 0 && !isValidDate(updatedAt)) {
    errors.push({
      line,
      field: "采集日期",
      code: "invalid_date",
      message: `采集日期 不是合法日期：${updatedAt}。`,
    });
  }

  const curriculum = splitTags(get("课程体系"));
  const feature = splitTags(get("特色标签"));

  // 保留字段（extra）：仅存白名单内、非空的值；白名单外（官方电话、复核人员等）
  // 一律不进入标准化结果，避免把未核验或个人信息带入 extra。
  const extra: Record<string, string> = {};
  for (const header of Object.keys(headerMap)) {
    if (headerMap[header] !== "extra") continue;
    if (!EXTRA_ALLOWED.has(header)) continue;
    const idx = headerIndex.get(header);
    if (idx === undefined) continue;
    const val = (row.raw[idx] ?? "").trim();
    if (val.length > 0) extra[header] = val;
  }

  // 发布闸门 · 办学性质硬规则：性质未确认即拦截（与可信等级无关）。
  // 提前计算，使「结构非法」的行也能同时给出 OWNERSHIP_UNVERIFIED 定位信息。
  const ownBlocker = ownershipBlocker(ownership, ownCn, line);

  // 存在阻断性错误：不生成 school 对象。
  if (errors.length > 0) {
    return {
      rowNumber: line,
      schoolId: id || null,
      school: null,
      errors,
      warnings,
      publishable: false,
      publishReasons: ownBlocker ? [ownBlocker.message] : [],
      publishBlockers: ownBlocker ? [ownBlocker] : [],
    };
  }

  const sourceName = get("信息来源名称");
  const verificationNote = get("备注");

  const school: GrowthSchool = {
    id,
    name,
    stage: stage as GrowthStage,
    district,
    ownership: ownership as SchoolOwnership,
    address: get("详细地址"),
    tuitionText: get("年度学费"),
    commuteText: "", // 采集模板暂无通勤列，导入后由 formatEmpty 呈现「暂未核实」。
    mealText: get("餐食情况"),
    foreignTeacherText: get("是否外教"),
    classSizeText: get("班额"),
    managementText: get("管理风格"),
    curriculumTags: curriculum,
    featureTags: feature,
    enrollmentScope: get("招生范围"),
    registrationMaterials: get("报名材料"),
    sourceName,
    sourceUrl,
    sourceUpdatedAt: updatedAt,
    verificationLevel: level as VerificationLevel,
    verificationLabel: VERIFICATION_LABELS[level as VerificationLevel],
    verificationNote,
    isDemo,
    extra,
  };

  // 通过基础校验才登记 ID，避免重复 ID 之间的级联误判。
  seenIds.add(id);

  // ===== 发布闸门 =====
  // 语义边界（务必保持，不得在后续改动中放宽）：
  //   publishable=true 仅表示「通过导入闸门」，
  //     - 不等于「资料完整」：学费/餐食/课程/特色/招生范围等核心字段可以全为空，
  //       仍然 publishable=true，由前端 formatEmpty 呈现「暂未核实」；
  //     - 不等于「允许公开展示」：公开展示需另经人工审批。
  //   闸门只做「可否进入正式发布」的判断，绝不据此宣称数据完整或已可对外。
  const publishBlockers: ImportError[] = [];
  const block = (code: string, field: string, message: string) => {
    publishBlockers.push({ line, field, code, message });
  };

  // 1) 办学性质未确认（空 / 非法枚举 / unknown 暂未核实）一律拦截。
  //    未确认性质的学校若被公开展示，等同于向家长呈现未经核实的关键信息。
  if (ownBlocker) publishBlockers.push(ownBlocker);

  // 2) 可信等级与来源完备性闸门。
  if (level === "UNVERIFIED") {
    block(
      PUBLISH_BLOCK_CODES.verificationUnverified,
      "可信等级",
      "可信等级为暂未核实（UNVERIFIED），不得进入正式发布。",
    );
  }
  if (level === "A") {
    if (sourceName.length === 0) {
      block(PUBLISH_BLOCK_CODES.sourceNameMissing, "信息来源名称", "A 官方公开：缺少信息来源名称。");
    }
    if (sourceUrl.length === 0) {
      block(PUBLISH_BLOCK_CODES.sourceUrlMissing, "信息来源链接", "A 官方公开：缺少信息来源链接。");
    }
    if (updatedAt.length === 0) {
      block(PUBLISH_BLOCK_CODES.sourceDateMissing, "采集日期", "A 官方公开：缺少采集日期。");
    }
    if (verificationNote.length === 0) {
      block(PUBLISH_BLOCK_CODES.verificationNoteMissing, "备注", "A 官方公开：可信度说明应说明官方来源。");
    }
  }
  if (level === "B") {
    if (sourceName.length === 0) {
      block(PUBLISH_BLOCK_CODES.sourceNameMissing, "信息来源名称", "B 学校确认：缺少信息来源名称。");
    }
    if (updatedAt.length === 0) {
      block(PUBLISH_BLOCK_CODES.sourceDateMissing, "采集日期", "B 学校确认：缺少采集日期。");
    }
    if (verificationNote.length === 0) {
      block(
        PUBLISH_BLOCK_CODES.verificationNoteMissing,
        "备注",
        "B 学校确认：可信度说明必须说明学校确认方式。",
      );
    }
  }
  if (level === "C") {
    if (sourceName.length === 0) {
      block(PUBLISH_BLOCK_CODES.sourceNameMissing, "信息来源名称", "C 平台核验：缺少信息来源名称。");
    }
    if (updatedAt.length === 0) {
      block(PUBLISH_BLOCK_CODES.sourceDateMissing, "采集日期", "C 平台核验：缺少采集日期。");
    }
    if (verificationNote.length === 0) {
      block(PUBLISH_BLOCK_CODES.verificationNoteMissing, "备注", "C 平台核验：必须保留核验说明。");
    }
  }
  if (level === "D") {
    if (verificationNote.length === 0) {
      block(
        PUBLISH_BLOCK_CODES.verificationNoteMissing,
        "备注",
        "D 家长反馈：可信度说明必填，且页面会明确标注“家长反馈”。",
      );
    }
  }

  return {
    rowNumber: line,
    schoolId: id,
    school,
    errors: [],
    warnings,
    publishable: publishBlockers.length === 0,
    publishReasons: publishBlockers.map((b) => b.message),
    publishBlockers,
  };
}

// ===== 顶层入口：解析 + 映射 + 校验 + 发布闸门 =====
export function importSchoolsCsv(
  text: string,
  opts?: ImportOptions,
): ImportResult {
  const { headers, rows } = parseCsv(text);
  const errors: ImportError[] = [];
  const warnings: string[] = [];
  const results: ImportRowResult[] = [];
  const schools: GrowthSchool[] = [];
  const publishableSchools: GrowthSchool[] = [];
  const publishBlockers: ImportError[] = [];
  const seenIds = new Set<string>();

  // 重复表头
  const seenHeaders = new Set<string>();
  const dupHeaders: string[] = [];
  for (const h of headers) {
    if (seenHeaders.has(h)) dupHeaders.push(h);
    seenHeaders.add(h);
  }
  if (dupHeaders.length > 0) {
    errors.push({
      line: 1,
      code: "duplicate_header",
      message: `存在重复表头：${dupHeaders.join("、")}`,
    });
  }

  // 缺失必要表头
  const missing = REQUIRED_HEADERS.filter((h) => !headers.includes(h));
  if (missing.length > 0) {
    errors.push({
      line: 1,
      code: "missing_required_header",
      message: `缺少必要表头：${missing.join("、")}`,
    });
  }

  // 未识别表头 -> 警告（不静默丢弃）
  const unknown = headers.filter((h) => !(h in HEADER_MAP));
  for (const u of unknown) {
    warnings.push(`未识别表头（已忽略该列，不参与映射）：${u}`);
  }

  const headerIndex = new Map<string, number>();
  headers.forEach((h, idx) => headerIndex.set(h, idx));

  // 行数上限
  if (opts && opts.maxRows && opts.maxRows > 0 && rows.length > opts.maxRows) {
    errors.push({
      line: 1,
      code: "too_many_rows",
      message: `数据行数 ${rows.length} 超过上限 ${opts.maxRows}。`,
    });
  }

  for (const row of rows) {
    const r = mapAndValidateRow(row, headerIndex, HEADER_MAP, seenIds);
    results.push(r);
    if (r.school) {
      schools.push(r.school);
      if (r.publishable) {
        publishableSchools.push(r.school);
      } else {
        // 结构合法但被闸门拦截：只在此处汇总，不写入 errors，
        // 以保证「结构有效」与「可发布」是两套独立口径。
        for (const b of r.publishBlockers) publishBlockers.push(b);
      }
    }
    for (const e of r.errors) errors.push(e);
    for (const w of r.warnings) warnings.push(`第 ${row.rowNumber} 行：${w}`);
  }

  return {
    headers,
    rows,
    schools,
    publishableSchools,
    errors,
    warnings,
    results,
    totalRows: rows.length,
    validRows: schools.length,
    publishableRows: publishableSchools.length,
    blockedRows: schools.length - publishableSchools.length,
    publishBlockers,
  };
}

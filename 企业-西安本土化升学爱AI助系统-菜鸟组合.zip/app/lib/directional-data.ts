// 定向生数据层（西安市教育局 2026-07-16 官方定向生分学校生源计划）
// 定向生学校必须按「所在区县 + 就读初中」筛选，不能把所有学校混在一起展示。
import { schools, DISTRICT_TO_DATA, type School } from "./volunteer-data";

// 就读初中按区县分组（来自 2026 年城六区/西咸新区省级标准化高中定向生分校生源计划表）
export const JUNIOR_SCHOOLS_BY_DISTRICT: Record<string, string[]> = {
  "xincheng": [
    "西安市东方中学",
    "西安市华山中学",
    "西安市大明宫中学",
    "西安市昆仑中学",
    "西安市汇文中学",
    "西安市汇知中学",
    "西安市秦川中学",
    "西安市第七十二中学",
    "西安市第三十中学",
    "西安市第三十八中学",
    "西安市第八十三中学",
    "西安市第八十九中学",
    "西安市第八十九中学教育集团尚德中学",
    "西安市第八十九中学教育集团弘德中学",
    "西安市第四十三中学",
    "西安市西光中学",
    "西安市黄河中学",
    "西安电机厂子弟学校",
    "陕西汽车集团有限责任公司第二职工子弟学校",
    "陕西省西安爱知中学"
  ],
  "beilin": [
    "西北大学附属中学",
    "西北工业大学附属中学",
    "西安交通大学附属中学",
    "西安工业大学附中",
    "西安市中铁中学",
    "西安市含光中学",
    "西安市太乙路中学",
    "西安市星光实验学校",
    "西安市第七十一中学",
    "西安市第三中学",
    "西安市第三中学分校",
    "西安市第二中学",
    "西安市第二十六中学",
    "西安市第二十六中学分校",
    "西安市第八中学",
    "西安市第八十二中学",
    "西安市第八十六中学",
    "西安市第六中学",
    "西安市第六中学分校",
    "西安市第十二中学",
    "西安市铁一中学",
    "西安建筑科技大学附属中学",
    "西安理工大学附属中学",
    "西安翱翔中学",
    "西安辅轮中学"
  ],
  "lianhu": [
    "西安市回民中学",
    "西安市大兴新区初级中学",
    "西安市庆安初级中学",
    "西安市第一中学",
    "西安市第七十中学",
    "西安市第三十一中学",
    "西安市第二十三中学",
    "西安市第二十五中学",
    "西安市第六十七中学",
    "西安市第十中学",
    "西安市第四十二中学",
    "西安市第四十四中学",
    "西安市莲湖第一中学",
    "西安市莲湖第一学校",
    "西安市莲湖第二学校",
    "西安市西电中学",
    "西安市远东第一中学",
    "西安市远东第二中学",
    "西安益新中学"
  ],
  "yanta": [
    "西京公司子校",
    "西安东仪中学",
    "西安交通大学附属中学雁塔校区",
    "西安南苑中学",
    "西安博迪学校",
    "西安外国语大学附属学校",
    "西安太白学校",
    "西安崇是中学",
    "西安市城南中学",
    "西安市曲江第一中学",
    "西安市曲江第一学校",
    "西安市曲江第三中学",
    "西安市曲江第三初级中学",
    "西安市曲江第二中学",
    "西安市浐灞丝路学校",
    "西安市第七十八中学",
    "西安市第九十九中学",
    "西安市第九十八中学",
    "西安市第五十三中学",
    "西安市第五十二中学",
    "西安市第八十五中学",
    "西安市第十四中学",
    "西安市第四十五中学",
    "西安市第四十六中学",
    "西安市育才中学",
    "西安市航天中学",
    "西安市航空六一八中学",
    "西安市阳光中学",
    "西安市雁塔区第一中学",
    "西安市雁塔区第一学校",
    "西安市雁塔区第三中学",
    "西安市雁塔区第二中学",
    "西安市雁塔区第二学校",
    "西安市高新一中初级中学",
    "西安市高新第一学校",
    "西安市高新第二初级中学",
    "西安市高新逸翠园初级中学",
    "西安曲江康桥学校",
    "西安曲江德闳学校",
    "西安电子科技中学",
    "西安电子科技大学附属中学",
    "西安科技大学附属中学",
    "西安航天菁英学校",
    "西安藤信学校",
    "西安雁南中学",
    "西安高新一中实验中学",
    "西安高新东区初级中学",
    "西安高新区第七初级中学",
    "西安高新区第三初级中学",
    "西安高新区第五初级中学",
    "西安高新区第十一初级中学",
    "西安高新区第十初级中学",
    "西安高新区第四初级中学",
    "西安高新区第四学校",
    "西安高新区第四完全中学",
    "西安高新唐南中学",
    "西安高新第三中学",
    "西安高新第二学校",
    "长安大学附属中学",
    "陕西师范大学附属中学"
  ],
  "bashan": [
    "西安滨河学校(原铁一滨河)",
    "西安国际港务区高新一中陆港中学",
    "西安市浐灞第一中学",
    "西安市庆华中学",
    "西安国际港务区实验中学",
    "西安国际港务区陆港初级中学",
    "西安市东城第一中学",
    "西安市东城第二学校",
    "西安市五环中学",
    "西安市交大附中浐灞右岸学校",
    "西安市半坡初级中学",
    "西安市奥体学校",
    "西安市宇航中学",
    "西安市浐灞第七初级中学",
    "西安市灞桥初级中学",
    "西安市第七十七中学",
    "西安市第七十九中学",
    "西安市第三十四中学",
    "西安市第五十七中学",
    "西安市第五十五中学",
    "西安市第五十六中学",
    "西安市第八十一中学",
    "西安市第六十三中学",
    "西安市第六十二中学",
    "西安市第六十五中学",
    "西安市第十九中学",
    "西安市第四十七中学",
    "西安市高桥中学",
    "西安市鹿原中学",
    "西安港务区铁一中陆港初级中学",
    "西安西港花园学校"
  ],
  "weiyang": [
    "西安凤凰城初级中学",
    "西安博爱学校",
    "西安市东元路学校",
    "西安市凤城学校",
    "西安市北城学校",
    "西安市太元路学校",
    "西安市尚稷路学校",
    "西安市文景中学",
    "西安市未央区实验学校",
    "西安市未央区第一学校",
    "西安市汉都新苑中学",
    "西安市汉都第一学校",
    "西安市浐灞欧亚中学",
    "西安市浐灞第三初级中学",
    "西安市浐灞第二中学",
    "西安市浐灞第十学校",
    "西安市第一实验学校",
    "西安市第七十五中学",
    "西安市第七十六中学",
    "西安市第五十八中学",
    "西安市第十一中学",
    "西安市第十七中学",
    "西安市第四十八中学",
    "西安市经开区第六学校",
    "西安市经开第一中学",
    "西安市经开第三中学",
    "西安市经开第二学校",
    "西安市经开第五学校",
    "西安市西大附中浐灞中学",
    "西安市西航一中",
    "西安市西航二中",
    "西安市长庆未央湖学校",
    "西安泾河工业区中心学校",
    "西安经开第一学校",
    "西安经开第二中学",
    "西安锦园中学",
    "西安高级中学",
    "长庆二中",
    "长庆第八中学"
  ],
  "xixian": [
    "西咸新区沣东新城第一初级中学",
    "西咸新区沣东昆明池学校",
    "西咸新区第二初级中学",
    "西咸新区铁一中金湾中学",
    "西咸新区黄冈泾河学校",
    "西安市创新港中学",
    "西安市第五十中学",
    "西安市第六十八中学",
    "西安市西城中学",
    "西安市车辆中学",
    "西安沣东第二初级中学",
    "西安沣东阿房路学校",
    "西安高新一中沣东中学"
  ]
};

// 细粒度映射：就读初中 -> 可定向的高中 id 列表（2026 官方数据）
export const DIRECTIONAL_MAP: Record<string, Record<string, string[]>> = {
  "xincheng": {
    "陕西省西安爱知中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市第三十八中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang"
    ],
    "西安市汇知中学": [
      "gx1",
      "qa"
    ],
    "西安市第八十九中学": [
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安市第四十三中学": [
      "tz",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市第三十中学": [
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市第七十二中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市大明宫中学": [
      "tz",
      "gx1",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市汇文中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市秦川中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z"
    ],
    "西安市黄河中学": [
      "tz",
      "jdfz"
    ],
    "西安市西光中学": [
      "tz"
    ],
    "西安市华山中学": [
      "tz",
      "jdfz"
    ],
    "西安市昆仑中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安市东方中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安市第八十九中学教育集团弘德中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang"
    ],
    "西安市第八十三中学": [
      "jdfz",
      "qujiang"
    ],
    "陕西汽车集团有限责任公司第二职工子弟学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市第八十九中学教育集团尚德中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安电机厂子弟学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ]
  },
  "beilin": {
    "西安市第三中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第三中学分校": [
      "gx1",
      "jdfz",
      "sdfz",
      "qa",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市含光中学": [
      "tz",
      "jdfz",
      "qa",
      "gx2",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市中铁中学": [
      "gx1",
      "jdfz",
      "qa",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第二中学": [
      "gx1",
      "jdfz",
      "sdfz",
      "qa",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第六中学分校": [
      "tz",
      "sdfz",
      "qa",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第十二中学": [
      "gx1",
      "qujiang",
      "qa",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第二十六中学分校": [
      "tz",
      "sdfz",
      "qujiang",
      "qa",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第二十六中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第七十一中学": [
      "tz",
      "gx1",
      "gx2",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第八十二中学": [
      "tz",
      "jdfz",
      "qujiang",
      "qa",
      "gx2",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第八十六中学": [
      "gx1",
      "qujiang",
      "qa",
      "gx2",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市太乙路中学": [
      "gx1",
      "sdfz",
      "qujiang",
      "qa",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西北大学附属中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "gx2",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安工业大学附中": [
      "gx1",
      "jdfz",
      "qa",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安理工大学附属中学": [
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安建筑科技大学附属中学": [
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市星光实验学校": [
      "tz",
      "gx1",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安辅轮中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第六中学": [
      "tz",
      "sdfz",
      "qujiang",
      "qa",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市铁一中学": [
      "tz",
      "gx1",
      "qa",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安市第八中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西北工业大学附属中学": [
      "tz",
      "gx1",
      "qujiang",
      "qa",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安翱翔中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ],
    "西安交通大学附属中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z",
      "xaZX",
      "1z",
      "3z",
      "htxx",
      "xg",
      "binhe",
      "89z",
      "hz",
      "yg",
      "43z",
      "xxKG"
    ]
  },
  "lianhu": {
    "西安市第一中学": [
      "tz",
      "qa"
    ],
    "西安市第十中学": [
      "tz",
      "qa"
    ],
    "西安市第二十三中学": [
      "tz",
      "gx1",
      "qa"
    ],
    "西安市第二十五中学": [
      "tz",
      "gx1",
      "qa"
    ],
    "西安市第三十一中学": [
      "tz",
      "jdfz",
      "qa",
      "gx2"
    ],
    "西安市第四十二中学": [
      "tz",
      "qujiang"
    ],
    "西安市第四十四中学": [
      "tz",
      "qa"
    ],
    "西安市第六十七中学": [
      "tz",
      "gx1"
    ],
    "西安市第七十中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市回民中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安市西电中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市庆安初级中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市远东第一中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市远东第二中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市大兴新区初级中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安市莲湖第一学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市莲湖第二学校": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安益新中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang"
    ],
    "西安市莲湖第一中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ]
  },
  "yanta": {
    "西安市第四十五中学": [
      "tz",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市第四十六中学": [
      "tz",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市第五十三中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安市曲江第三中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市第七十八中学": [
      "tz",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市第九十八中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安市第九十九中学": [
      "tz",
      "jdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市育才中学": [
      "tz"
    ],
    "陕西师范大学附属中学": [
      "jdfz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安市第八十五中学": [
      "tz",
      "sdfz",
      "qujiang"
    ],
    "西安科技大学附属中学": [
      "tz",
      "jdfz",
      "6z"
    ],
    "西安崇是中学": [
      "tz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安市雁塔区第一中学": [
      "tz",
      "gx1",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安电子科技大学附属中学": [
      "tz"
    ],
    "西安东仪中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安南苑中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qa"
    ],
    "西安交通大学附属中学雁塔校区": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang"
    ],
    "西安市城南中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "长安大学附属中学": [
      "tz",
      "gx1",
      "jdfz",
      "qa"
    ],
    "西安市航空六一八中学": [
      "tz",
      "gx1",
      "jdfz",
      "qa"
    ],
    "西安电子科技中学": [
      "tz",
      "qa"
    ],
    "西安市航天中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang"
    ],
    "西京公司子校": [
      "tz",
      "jdfz"
    ],
    "西安市雁塔区第一学校": [
      "tz",
      "gx1",
      "jdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z"
    ],
    "西安市曲江第一学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市雁塔区第三中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安太白学校": [
      "tz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安曲江康桥学校": [
      "tz",
      "qa"
    ],
    "西安曲江德闳学校": [
      "jdfz"
    ],
    "西安市雁塔区第二学校": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安高新唐南中学": [
      "tz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安市曲江第三初级中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang"
    ],
    "西安雁南中学": [
      "tz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市曲江第一中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z"
    ],
    "西安航天菁英学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安市浐灞丝路学校": [
      "tz",
      "jdfz"
    ],
    "西安市阳光中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qa"
    ],
    "西安外国语大学附属学校": [
      "tz",
      "jdfz"
    ],
    "西安市曲江第二中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "gx2",
      "6z"
    ],
    "西安藤信学校": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安市雁塔区第二中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang"
    ],
    "西安市第十四中学": [
      "tz",
      "qa"
    ],
    "西安市第五十二中学": [
      "tz",
      "qa"
    ],
    "西安博迪学校": [
      "tz",
      "qa"
    ],
    "西安市高新一中初级中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安高新第二学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2"
    ],
    "西安高新第三中学": [
      "jdfz",
      "sdfz",
      "qujiang"
    ],
    "西安市高新逸翠园初级中学": [
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安市高新第一学校": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安高新东区初级中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安高新区第三初级中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安高新区第四初级中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安高新区第十初级中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安高新区第四完全中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安高新一中实验中学": [
      "jdfz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安市高新第二初级中学": [
      "jdfz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安高新区第十一初级中学": [
      "jdfz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西安高新区第四学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安高新区第七初级中学": [
      "tz"
    ],
    "西安高新区第五初级中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2"
    ]
  },
  "bashan": {
    "西安市第十九中学": [
      "tz",
      "gx1",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市第三十四中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市第五十五中学": [
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市第六十二中学": [
      "tz",
      "gx1",
      "sdfz",
      "qa"
    ],
    "西安国际港务区实验中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市东城第二学校": [
      "tz",
      "gx1",
      "jdfz",
      "qa"
    ],
    "西安市交大附中浐灞右岸学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市浐灞第一中学": [
      "tz",
      "gx1",
      "jdfz"
    ],
    "西安市东城第一中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z"
    ],
    "西安市五环中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市浐灞第七初级中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安国际港务区陆港初级中学": [
      "tz",
      "jdfz",
      "sdfz"
    ],
    "西安国际港务区高新一中陆港中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang"
    ],
    "西安市庆华中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安港务区铁一中陆港初级中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安滨河学校(原铁一滨河)": [
      "tz",
      "jdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市宇航中学": [
      "tz",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安西港花园学校": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市第五十六中学": [
      "jdfz",
      "sdfz"
    ],
    "西安市第五十七中学": [
      "tz",
      "qa"
    ],
    "西安市第六十三中学": [
      "tz",
      "qa"
    ],
    "西安市第六十五中学": [
      "tz",
      "jdfz",
      "sdfz"
    ],
    "西安市第七十七中学": [
      "tz",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市第七十九中学": [
      "sdfz"
    ],
    "西安市灞桥初级中学": [
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z"
    ],
    "西安市鹿原中学": [
      "tz",
      "gx1",
      "qa"
    ],
    "西安市高桥中学": [
      "tz"
    ],
    "西安市半坡初级中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ]
  },
  "weiyang": {
    "西安市第十一中学": [
      "tz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市文景中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市第十七中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安市第四十八中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市第五十八中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市汉都第一学校": [
      "tz",
      "qa"
    ],
    "西安市第七十五中学": [
      "tz",
      "gx1",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市第七十六中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安市太元路学校": [
      "tz",
      "jdfz",
      "qa",
      "gx2"
    ],
    "西安市东元路学校": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市西航一中": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z"
    ],
    "西安市西航二中": [
      "tz",
      "gx1",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市凤城学校": [
      "tz",
      "gx1",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市北城学校": [
      "tz",
      "sdfz",
      "qujiang"
    ],
    "西安市尚稷路学校": [
      "tz",
      "sdfz"
    ],
    "长庆第八中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安博爱学校": [
      "tz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安锦园中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安泾河工业区中心学校": [
      "tz"
    ],
    "西安经开第一学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z"
    ],
    "长庆二中": [
      "tz"
    ],
    "西安市长庆未央湖学校": [
      "tz",
      "qujiang"
    ],
    "西安市经开第三中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安经开第二中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市经开第一中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市浐灞欧亚中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市西大附中浐灞中学": [
      "tz",
      "gx1",
      "jdfz",
      "qujiang",
      "qa",
      "gx2",
      "6z"
    ],
    "西安高级中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安凤凰城初级中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市经开第二学校": [
      "tz",
      "gx1",
      "sdfz",
      "qa"
    ],
    "西安市浐灞第二中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市浐灞第十学校": [
      "tz",
      "sdfz",
      "qa"
    ],
    "西安市汉都新苑中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市经开区第六学校": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市浐灞第三初级中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西安市未央区第一学校": [
      "tz",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市经开第五学校": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安市第一实验学校": [
      "tz",
      "qa",
      "6z"
    ],
    "西安市未央区实验学校": [
      "tz",
      "jdfz"
    ]
  },
  "xixian": {
    "西安沣东第二初级中学": [
      "tz",
      "gx1",
      "jdfz",
      "qujiang",
      "qa"
    ],
    "西安市第五十中学": [
      "tz",
      "jdfz",
      "qa"
    ],
    "西安沣东阿房路学校": [
      "tz"
    ],
    "西安市第六十八中学": [
      "jdfz"
    ],
    "西安市西城中学": [
      "tz"
    ],
    "西安市车辆中学": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西安高新一中沣东中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa",
      "6z"
    ],
    "西咸新区黄冈泾河学校": [
      "tz",
      "jdfz",
      "sdfz",
      "qujiang",
      "6z"
    ],
    "西咸新区沣东新城第一初级中学": [
      "tz"
    ],
    "西安市创新港中学": [
      "tz",
      "gx1",
      "jdfz",
      "sdfz",
      "qujiang",
      "qa"
    ],
    "西咸新区铁一中金湾中学": [
      "tz",
      "jdfz",
      "qa"
    ]
  }
};

// 取得某区县+就读初中对应的定向高中列表（含定向名额、去年参考分）
export function getDirectionalSchools(district: string, juniorSchool?: string): School[] {
  const dataDistrict = DISTRICT_TO_DATA[district] || "chengliuqu";
  let pool = schools.filter((s) => s.district === dataDistrict && (s.directionalQuota ?? 0) > 0);

  // 若配置了细粒度映射且当前初中在其中，则进一步过滤
  const fine = DIRECTIONAL_MAP[district]?.[juniorSchool || ""];
  if (fine && fine.length) {
    const set = new Set(fine);
    pool = pool.filter((s) => set.has(s.id));
  }
  return pool.sort((a, b) => (b.directionalQuota ?? 0) - (a.directionalQuota ?? 0));
}

// 取某初中的定向高中 id 列表（供志愿填报页预填）
export function directionalHighSchoolIds(district: string, juniorSchool?: string): string[] {
  return getDirectionalSchools(district, juniorSchool).map((s) => s.id);
}

// 西安市中考 / 中招录取 官方数据（抓取于 2026-07-16，来源：西安市教育局 2026-07-16 官方 PDF）
// 真实性原则：仅收录已官方发布的数据，并标注来源与发布时间。
// 2026 各校录取分数线在录取结束前未公布，一律标「待官方发布」，不预测、不估算；
// 城六区录取控制线已于 2026-07-17 由西安市教育局公布（普高 492.0 / 体育艺术特长生 295.2 / 试点综合高中班 465.0），已收录于 CONTROL_LINES.y2026。

export type SourceMeta = {
  name: string;
  publisher: string;
  url: string;
  published: string; // YYYY-MM-DD
};

// ===== 官方来源 =====
export const SOURCES: Record<string, SourceMeta> = {
  scheme2026: {
    name: "西安市2026年高中阶段学校招生录取工作方案",
    publisher: "西安市教育局",
    url: "https://edu.xa.gov.cn/xwzx/tzgg/2076480238905311234.html",
    published: "2026-07-12",
  },
  plan2026: {
    name: "西安市2026年普通高中分学校招生计划（5 个 PDF）",
    publisher: "西安市教育局",
    url: "https://edu.xa.gov.cn/xwzx/tzgg/2077576360413937666.html",
    published: "2026-07-16",
  },
  directional2026: {
    name: "2026年城六区省级标准化高中定向生分学校生源计划表（7 个 PDF）",
    publisher: "西安市教育局",
    url: "https://edu.xa.gov.cn/xwzx/tzgg/2077570654019817474.html",
    published: "2026-07-16",
  },
  controlLine2025: {
    name: "西安市2025年城六区中招录取控制线",
    publisher: "西安市中招领导小组",
    url: "http://m.sxjybk.com/2025/0718/119496.html",
    published: "2025-07-18",
  },
  controlLine2026: {
    name: "西安市2026年城六区招生单元中招录取控制线",
    publisher: "西安市教育局（中招领导小组）",
    url: "https://edu.xa.gov.cn/xwzx/tzgg/",
    published: "2026-07-17",
  },
  controlLines2026Districts: {
    name: "西安市2026年五区二县及西咸新区普通高中招生录取控制线（各区县教育局公布，本站汇总）",
    publisher: "各区县教育局 / 西安市教育局（汇总自西安本地宝、腾讯新闻）",
    url: "https://xa.bendibao.com/tour/20141120/116618.shtm",
    published: "2026-07-17",
  },
  platform: {
    name: "西安市初中学业水平考试招生管理平台（志愿填报／录取查询）",
    publisher: "西安市教育考试中心",
    url: "https://222.91.162.190:91/",
    published: "2026-07-13",
  },
  privateJunior2026: {
    name: "西安市2026年民办学校初中招生计划",
    publisher: "西安市教育局（义务教育招生入学工作安排）",
    url: "http://edu.xa.gov.cn/xxgk/wsbs/xxjy/2072508508068151298.html",
    pdf: "https://edu.xa.gov.cn/web_files/edu/file/2026/07/02/202607021029010749697.pdf",
    published: "2026-07-02",
  },
};

// ===== 2026 中考计分改革 =====
export const EXAM_2026 = {
  totalScore: 640,
  note: "2026年起西安市中考执行7科计分，总分640分。",
  scorePublish: "2026-07-17 12:00",
};

// ===== 2026 录取工作方案要点（西安市教育局，2026-07-12）=====
export const ADMISSION_SCHEME_2026 = {
  fillWindow: {
    chengliu: "2026-07-18 08:00 ~ 2026-07-20 18:00（城六区）",
    others: "2026-07-21 08:00 ~ 2026-07-23 18:00（五区二县及西咸新区独立单元）",
  },
  chengliuBatches: [
    { batch: "第一批次", desc: "3所省级示范高中（或市级特色示范高中）志愿；须至少填报2所方可提交" },
    { batch: "第二批次", desc: "4所省级标准化高中和其他普通高中志愿；须填满4所方可提交" },
  ],
  parallel: "城六区两个批次均为平行志愿；定向生（指标到校）志愿每生限报1所。",
  directionalPolicy:
    "优质普通高中（含民办）总计划（单列计划除外）中不低于50%定向分配到招生单元内各初中学校（含民办），并向办学质量、育人效果提升明显的薄弱初中倾斜。",
  admissionBasis:
    "依据综合素质评价 + 学业水平考试成绩 + 学校招生计划 + 考生志愿录取；录取工作结束后不再进行补录。",
  tieBreak: [
    "四个条件依次优先：全国公安系统一/二级英模子女 → 其他军人子女 → 少数民族考生 → 西安农村独生子女户和双女户考生",
    "两项指标：综合素质评价5个维度高等级个数多者优先；其次理化生实验与信息科技操作考试高等级个数多者优先",
    "学科成绩：以上仍无法区分时，按学科分数依次比对录取",
  ],
  eligibility: {
    regular:
      "综合素质评价5个维度与学业水平考试成绩均达C等级以上（含C），具备普通高中与试点综合高中班录取资格。",
    provincial:
      "报考省级标准化高中（含省示范）：5个维度中至少2维度达B以上，且理化生实验与信息科技操作考试至少2科达B以上。",
  },
  carePolicy: [
    "烈士子女：录取总分 +20 分后参加录取",
    "因公牺牲民警子女、一至四级残疾民警子女、因公牺牲军人子女、一至四级残疾军人子女、归侨/归侨子女/华侨在西安子女、台湾籍考生：+10 分",
    "全国公安系统一/二级英模子女、其他军人子女、少数民族考生、农村独生子女户和双女户考生：同等条件优先录取",
    "同一考生具有多项照顾条件的，按最高一项给予",
  ],
};

// ===== 2026 普通高中招生计划（西安市教育局 2026-07-16 发布）=====
export const PLAN_2026 = {
  totalSenior: 90928,
  totalVocational: 23672, // 职业高中计划招生（未在本次 PDF 中更新，沿用前值）
  chengliuPublic: {
    total: 42429,
    zhaotong: 24566,
    dingxiang: 17476,
    tese: 812,
    teSeBan: 1790,
    xizang: 56,
  },
  wuquErxianPublic: 32709,
  chengliuPrivate: {
    total: 11420,
    zhaotong: 6049,
    dingxiang: 5006,
    tese: 338,
    teSeBan: 740,
  },
  wuquErxianPrivate: { total: 4370, zhaotong: 2705, dingxiang: 1665 },
  comprehensiveHigh: 0,
  // 分学校招生计划（官方已发布；来源：西安市教育局 2026-07-16）
  bySchool: [
  {
    "name": "西北工业大学附属中学(省示范)",
    "plan": 1000,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安交通大学附属中学(省示范)",
    "plan": 870,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第三中学(省示范)",
    "plan": 420,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第六中学(省示范)",
    "plan": 330,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市含光中学(省标)",
    "plan": 440,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市中铁中学(省标)",
    "plan": 350,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第二中学(省标)",
    "plan": 300,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第二十六中学(省示范)",
    "plan": 400,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第七十一中学(省标)",
    "plan": 350,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第八十二中学(省标)",
    "plan": 410,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第八十六中学(省标)",
    "plan": 400,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市太乙路中学(省标)",
    "plan": 200,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市铁一中学(省示范)",
    "plan": 720,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西北大学附属中学(省示范)",
    "plan": 350,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安工业大学附中(省标)",
    "plan": 270,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安建筑科技大学附属中学(省示范)",
    "plan": 340,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第八中学(省标)",
    "plan": 420,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第六中学分校(省标)",
    "plan": 300,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第八十三中学(省示范)",
    "plan": 500,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第三十八中学(省标)",
    "plan": 400,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第八十九中学(省示范)",
    "plan": 560,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第四十三中学(省标)",
    "plan": 320,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第三十中学(省标)",
    "plan": 400,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第七十二中学(省标)",
    "plan": 300,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市大明宫中学(省标)",
    "plan": 380,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市黄河中学(省标)",
    "plan": 470,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市西光中学(省示范)",
    "plan": 500,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市华山中学(省标)",
    "plan": 450,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市昆仑中学(省标)",
    "plan": 340,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市东方中学(省标)",
    "plan": 400,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第八十九中学分校(普高)",
    "plan": 400,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第一中学(省示范)",
    "plan": 500,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第十中学(省标)",
    "plan": 360,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第二十五中学(省标)",
    "plan": 270,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第四十二中学(省标)",
    "plan": 320,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第四十四中学(省标)",
    "plan": 360,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市西电中学(省标)",
    "plan": 420,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市远东第一中学(省示范)",
    "plan": 450,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市庆安高级中学(省示范)",
    "plan": 510,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市远东第二中学(省示范)",
    "plan": 530,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第七十中学(省示范)",
    "plan": 510,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市莲湖第一中学(普高)",
    "plan": 260,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第三十一中学(普高)",
    "plan": 300,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第四十五中学(省标)",
    "plan": 320,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第四十六中学(省标)",
    "plan": 355,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第五十三中学(省标)",
    "plan": 355,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市育才中学(省示范)",
    "plan": 455,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第八十五中学(省示范)",
    "plan": 500,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "陕西师范大学附属中学(省示范)",
    "plan": 596,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安电子科技大学附属中学(省示范)",
    "plan": 312,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安东仪中学(省标)",
    "plan": 320,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市航天中学(省示范)",
    "plan": 355,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安高新第三中学(省示范)",
    "plan": 500,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市曲江第一中学(省示范)",
    "plan": 650,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市曲江第二中学(省标)",
    "plan": 650,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市雁塔区第二中学(普高)",
    "plan": 330,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市阳光中学(省标)",
    "plan": 315,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安高新一中实验中学(普高)",
    "plan": 700,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安高新区第四完全中学(普高)",
    "plan": 425,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安高新区第五高级中学(普高)",
    "plan": 315,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市航天城第二中学(普高)",
    "plan": 103,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市高新第二高级中学(省标)",
    "plan": 690,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市航天城第一中学(省标)",
    "plan": 103,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "陕西师范大学附属中学长安校区(省示范)",
    "plan": 120,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市浐灞丝路学校(普高)",
    "plan": 300,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第十一中学(省标)",
    "plan": 330,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第四十八中学(省标)",
    "plan": 425,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第六十六中学(省示范)",
    "plan": 550,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第七十五中学(省示范)",
    "plan": 520,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市西航一中(省示范)",
    "plan": 500,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "陕西省西安中学(省示范)",
    "plan": 1245,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "长庆二中(省标)",
    "plan": 380,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安高级中学(省示范)",
    "plan": 735,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市经开第一中学(省示范)",
    "plan": 525,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市西大附中浐灞中学(省标)",
    "plan": 720,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市经开第三中学(省标)",
    "plan": 525,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市浐灞第二中学(普高)",
    "plan": 510,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市经开第二中学(省标)",
    "plan": 410,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市汉都新苑中学(普高)",
    "plan": 430,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第五十八中学(普高)",
    "plan": 400,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市渭北中学(普高)",
    "plan": 430,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第十九中学(省标)",
    "plan": 330,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第三十四中学(省标)",
    "plan": 480,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第五十五中学(省标)",
    "plan": 350,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第六十二中学(省标)",
    "plan": 350,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安国际港务区实验中学(省标)",
    "plan": 350,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市东城第一中学(省示范)",
    "plan": 510,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市五环中学(省标)",
    "plan": 510,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市浐灞国际港陕西师范大学陆港中学(普高)",
    "plan": 240,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市庆华中学(省标)",
    "plan": 420,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安国际港务区铁一中陆港高级中学(普高)",
    "plan": 590,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市宇航中学(省标)",
    "plan": 330,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安国际港务区高新一中陆港中学(普高)",
    "plan": 355,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市交大附中浐灞右岸学校(普高)",
    "plan": 300,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市第六十五中学(普高)",
    "plan": 240,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市浐灞国际港陕西师范大学陆港学校(普高)",
    "plan": 255,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市车辆中学(省示范)",
    "plan": 125,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "陕西省西咸新区秦汉中学(省示范)",
    "plan": 300,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西咸新区空港实验高级中学（西安交通大学附属中学空港高级中学）(普高)",
    "plan": 195,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西咸新区泾河新城第一中学(普高)",
    "plan": 100,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市创新港中学（创新港西安交通大学附属中学）(普高)",
    "plan": 225,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西咸新区铁一中金湾中学(普高)",
    "plan": 180,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西咸新区沣东第一高级中学(普高)",
    "plan": 150,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西咸新区沣西第一高级中学(普高)",
    "plan": 60,
    "ownership": "public",
    "region": "城六区"
  },
  {
    "name": "西安市阎良区关山中学(省标)",
    "plan": 650,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市阎良区西飞第一中学(省示范)",
    "plan": 1420,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市临潼区华清中学(省示范)",
    "plan": 1050,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市临潼区临潼中学(省示范)",
    "plan": 1050,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市临潼区马额中学(省标)",
    "plan": 550,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市临潼区雨金中学(省标)",
    "plan": 750,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市临潼区陕鼓中学(省标)",
    "plan": 520,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市临潼区铁路中学(省标)",
    "plan": 660,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市渭北中学(普高)",
    "plan": 200,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第一中学(省示范)",
    "plan": 930,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第二中学(省示范)",
    "plan": 1120,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第四中学(省标)",
    "plan": 450,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第五中学(省标)",
    "plan": 800,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第六中学(省标)",
    "plan": 700,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第八中学(省标)",
    "plan": 540,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第九中学(省标)",
    "plan": 360,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第十中学(省标)",
    "plan": 600,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第三中学(省标)",
    "plan": 650,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市高新第二高级中学(省标)",
    "plan": 50,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市航天城第一中学(省标)",
    "plan": 407,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市航天城第二中学(普高)",
    "plan": 407,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第七中学(省标)",
    "plan": 50,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区第十二中学(省标)",
    "plan": 30,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "陕西师范大学附属中学长安校区(省示范)",
    "plan": 280,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市长安区实验中学(普高)",
    "plan": 200,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市高陵区第一中学(省示范)",
    "plan": 1350,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市高陵区第三中学(省标)",
    "plan": 1260,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "鄠邑区第一中学(省示范)",
    "plan": 1050,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市鄠邑区第二中学(省标)",
    "plan": 540,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市鄠邑区第四中学(省标)",
    "plan": 750,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市鄠邑区第三高级中学（普高）",
    "plan": 300,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安惠安中学(省示范)",
    "plan": 800,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市鄠邑区电厂中学(省标)",
    "plan": 440,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市田家炳中学(省示范)",
    "plan": 930,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "蓝田县城关中学(省标)",
    "plan": 930,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市白鹿原高级中学(省标)",
    "plan": 450,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "蓝田县焦岱中学(省标)",
    "plan": 450,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "蓝田县洩湖中学(省标)",
    "plan": 450,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "蓝田县玉山中学(省标)",
    "plan": 450,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "周至县第一中学(省标)",
    "plan": 705,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "周至县第二中学(省标)",
    "plan": 660,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "周至县第三中学(省标)",
    "plan": 660,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "周至县第四中学(省标)",
    "plan": 705,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "周至县第五中学(省标)",
    "plan": 705,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "周至县第六中学(省标)",
    "plan": 660,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "周至中学(省示范)",
    "plan": 760,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安高新区第五高级中学(普高)",
    "plan": 50,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市车辆中学(省示范)",
    "plan": 205,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "陕西省西咸新区秦汉中学(省示范)",
    "plan": 400,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西咸新区空港实验高级中学（西安交通大学附属中学空港高级中学）(普高)",
    "plan": 300,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西咸新区泾河新城第一中学(普高)",
    "plan": 450,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安市创新港中学（创新港西安交通大学附属中学）(普高)",
    "plan": 335,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西咸新区铁一中金湾中学(普高)",
    "plan": 270,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西咸新区沣东第一高级中学(普高)",
    "plan": 290,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西咸新区沣西第一高级中学(普高)",
    "plan": 240,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西咸新区空港第一学校(普高)",
    "plan": 100,
    "ownership": "public",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安铁一中国际合作学校(省标)",
    "plan": 660,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安电子科技中学(省标)",
    "plan": 440,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安曲江德闳学校(普高)",
    "plan": 50,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安博迪学校(省标)",
    "plan": 1000,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安太白学校(省标)",
    "plan": 310,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安高新第一中学(省示范)",
    "plan": 1160,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安高新唐南中学(省标)",
    "plan": 420,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安崇是中学(省标)",
    "plan": 220,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安雁南中学(省标)",
    "plan": 410,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安交通大学附属中学航天高级中学(省标)",
    "plan": 700,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安景泓高级中学(普高，营利性)",
    "plan": 450,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安藤信高级中学(普高)",
    "plan": 580,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安博爱学校(省标)",
    "plan": 750,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安锦园中学(省标)",
    "plan": 350,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安外国语学校(省标)",
    "plan": 560,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安铁一中滨河高级中学(省示范)",
    "plan": 580,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安西港花园高级中学(省标)",
    "plan": 700,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安思源中学(省标)",
    "plan": 750,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安高新一中沣东中学(省示范)",
    "plan": 230,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西咸泾河泾华学校(省标)",
    "plan": 200,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西咸新区黄冈泾河中学(省标)",
    "plan": 900,
    "ownership": "private",
    "region": "城六区"
  },
  {
    "name": "西安市长安区第一民办中学(省标)",
    "plan": 320,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安南开高级中学(普高)",
    "plan": 600,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安湖滨中学(普高)",
    "plan": 500,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安交大附中航天高级中学(省标)",
    "plan": 200,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "陕西实验高级中学(省标)",
    "plan": 815,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安鸿德高级中学(普高)",
    "plan": 280,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安蓝田工业园高级中学(省标)",
    "plan": 800,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安高新一中沣东中学(省示范)",
    "plan": 155,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "西咸新区黄冈泾河中学(省标)",
    "plan": 100,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "西咸泾河泾华学校(省标)",
    "plan": 600,
    "ownership": "private",
    "region": "五区二县及西咸"
  },
  {
    "name": "西安职业中等专业学校（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安综合职业中等专业学校（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安第四联合职业中学（民办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安实验职业中等专业学校（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安陕文投睿德职业高级中学（民办）",
    "plan": 300,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安市雁塔区职业高级中学（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安大唐综合职业高中有限公司（民办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安新希望职业高中（民办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安东方职业高级中学（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安市灞桥区职业高级中学（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安虹途职业高中（民办）",
    "plan": 300,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安育华职业高中（民办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安交通职业学校（民办）",
    "plan": 150,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安铁道职业学校（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安新高教职业高中（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安市未央区职业教育中心（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安康桥职业高中（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安市阎良区职教中心（武屯校区）（公办）",
    "plan": 300,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安市临潼区职业教育中心（公办）",
    "plan": 250,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安市长安区职教中心（公办）",
    "plan": 400,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安现代综合职业高中（民办）",
    "plan": 300,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安博雅艺术职业高中有限公司（民办）",
    "plan": 150,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安华跃职业高级中学（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安市高陵区职业技术教育中心（公办）",
    "plan": 400,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安市鄠邑区职教中心（公办）",
    "plan": 240,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "蓝田县职业教育中心（公办）",
    "plan": 410,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "周至县职业教育中心（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安领航职业高级中学（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安南湖博苑综合职业高中（民办）",
    "plan": 150,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安启航职业高级中学（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安工业经济综合职业高中（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安培英育才职业高中有限公司（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安涉外职业高中（民办）",
    "plan": 150,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西咸新区丝路艺术职业学校（民办）",
    "plan": 100,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "陕西省建筑材料工业学校（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "陕西省石油化工学校（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  },
  {
    "name": "西安旅游职业中等专业学校（公办）",
    "plan": 200,
    "ownership": "public",
    "region": ""
  }
],
};

// ===== 2026 定向生分学校生源计划（城六区 7 区 + 西咸新区城六区）=====
export const DIRECTIONAL_2026 = {
  summary: {
  "新城区": {
    "juniorSchools": 20,
    "totalQuota": 1943
  },
  "碑林区": {
    "juniorSchools": 25,
    "totalQuota": 2887
  },
  "莲湖区": {
    "juniorSchools": 19,
    "totalQuota": 1426
  },
  "雁塔区": {
    "juniorSchools": 60,
    "totalQuota": 5131
  },
  "灞桥区": {
    "juniorSchools": 31,
    "totalQuota": 3112
  },
  "未央区": {
    "juniorSchools": 39,
    "totalQuota": 3440
  },
  "西咸新区": {
    "juniorSchools": 13,
    "totalQuota": 835
  }
},
  source: SOURCES.directional2026,
};

// ===== 2026 民办初中招生计划（义务教育·电脑随机录取，与高中中招志愿分属不同招生阶段）=====
// 来源：西安市教育局 2026-07-02《关于下达2026年民办学校初中招生计划的通知》附件 PDF
// 说明：民办初中实行电脑随机录取（摇号），不填报志愿；与高中「中招志愿」阶段不同，仅作官方信息收录。
export const PRIVATE_JUNIOR_2026 = {
  stage: "义务教育·民办初中（小升初）",
  admitMode: "电脑随机录取（摇号），不填报志愿",
  total: { classes: 259, plan: 12311, shengzhi: 2944 },
  byDistrict: [
    { district: "碑林区", classes: 36, plan: 1800, shengzhi: 92 },
    { district: "雁塔区", classes: 44, plan: 2200, shengzhi: 362 },
    { district: "灞桥区", classes: 28, plan: 1200, shengzhi: 172 },
    { district: "未央区", classes: 18, plan: 900, shengzhi: 762 },
    { district: "长安区", classes: 35, plan: 1650, shengzhi: 941 },
    { district: "蓝田县", classes: 14, plan: 650, shengzhi: 0 },
    { district: "周至县", classes: 6, plan: 280, shengzhi: 0 },
    { district: "浐灞国际港", classes: 6, plan: 300, shengzhi: 21 },
    { district: "高新区", classes: 14, plan: 700, shengzhi: 232 },
    { district: "经开区", classes: 8, plan: 400, shengzhi: 0 },
    { district: "曲江新区", classes: 11, plan: 331, shengzhi: 4 },
    { district: "航天基地", classes: 18, plan: 900, shengzhi: 59 },
    { district: "西咸新区", classes: 21, plan: 1000, shengzhi: 299 },
  ],
  schools: [
    { seq: 1, name: "西安翱翔中学", classes: 16, plan: 800, shengzhi: 92, district: "碑林区" },
    { seq: 2, name: "西安辅轮中学", classes: 20, plan: 1000, shengzhi: 0, district: "碑林区" },
    { seq: 3, name: "西安电子科技中学", classes: 6, plan: 300, shengzhi: 57, district: "雁塔区" },
    { seq: 4, name: "西安太白学校", classes: 10, plan: 500, shengzhi: 62, district: "雁塔区" },
    { seq: 5, name: "西安雁南中学", classes: 6, plan: 300, shengzhi: 242, district: "雁塔区" },
    { seq: 6, name: "西安藤信学校", classes: 6, plan: 300, shengzhi: 0, district: "雁塔区" },
    { seq: 7, name: "西安崇是中学", classes: 8, plan: 400, shengzhi: 1, district: "雁塔区" },
    { seq: 8, name: "西安高新唐南中学", classes: 8, plan: 400, shengzhi: 0, district: "雁塔区" },
    { seq: 9, name: "西安滨河学校", classes: 28, plan: 1200, shengzhi: 172, district: "灞桥区" },
    { seq: 10, name: "西安凤凰城初级中学", classes: 12, plan: 600, shengzhi: 501, district: "未央区" },
    { seq: 11, name: "西安锦园中学", classes: 6, plan: 300, shengzhi: 261, district: "未央区" },
    { seq: 12, name: "西安西京初级中学", classes: 8, plan: 350, shengzhi: 205, district: "长安区" },
    { seq: 13, name: "西安万科城初级中学", classes: 12, plan: 600, shengzhi: 366, district: "长安区" },
    { seq: 14, name: "西安湖滨中学", classes: 15, plan: 700, shengzhi: 370, district: "长安区" },
    { seq: 15, name: "蓝田县北关实验学校", classes: 14, plan: 650, shengzhi: 0, district: "蓝田县" },
    { seq: 16, name: "周至县育英学校", classes: 2, plan: 80, shengzhi: 0, district: "周至县" },
    { seq: 17, name: "周至县实验中学", classes: 2, plan: 100, shengzhi: 0, district: "周至县" },
    { seq: 18, name: "周至铸才初级中学", classes: 2, plan: 100, shengzhi: 0, district: "周至县" },
    { seq: 19, name: "西安西港花园学校", classes: 6, plan: 300, shengzhi: 21, district: "浐灞国际港" },
    { seq: 20, name: "西安博迪学校", classes: 4, plan: 200, shengzhi: 0, district: "高新区" },
    { seq: 21, name: "西安高新东区初级中学", classes: 10, plan: 500, shengzhi: 232, district: "高新区" },
    { seq: 22, name: "西安博爱学校", classes: 8, plan: 400, shengzhi: 0, district: "经开区" },
    { seq: 23, name: "西安曲江康桥学校", classes: 8, plan: 256, shengzhi: 4, district: "曲江新区" },
    { seq: 24, name: "西安曲江德闳学校", classes: 3, plan: 75, shengzhi: 0, district: "曲江新区" },
    { seq: 25, name: "西安航天菁英学校", classes: 18, plan: 900, shengzhi: 59, district: "航天基地" },
    { seq: 26, name: "西咸泾河泾华学校", classes: 7, plan: 330, shengzhi: 0, district: "西咸新区" },
    { seq: 27, name: "西咸新区黄冈泾河学校", classes: 14, plan: 670, shengzhi: 299, district: "西咸新区" },
  ],
  source: SOURCES.privateJunior2026,
};

// ===== 录取控制线 =====
export const CONTROL_LINES = {
  // 2025 官方（历史参考）
  y2025: {
    chengliuRegular: 611.0,
    sportsArt: 366.6,
    comprehensiveHigh: 595.0,
    note: "西安市2025年城六区招生单元普通高中录取控制线；五区二县等独立单元由各区县教育局公布。",
  },
  // 2026 控制线：西安市教育局 2026-07-17 12:00 公布
  y2026: {
    status: "active" as const,
    published: "2026-07-17",
    chengliuRegular: 492.0,
    sportsArt: 295.2,
    comprehensiveHigh: 465.0,
    note: "2026年城六区招生单元普通高中学校招生录取控制线：普通高中 492.0 分；体育、艺术特长生 295.2 分；试点综合高中班 465.0 分（西安市教育局 2026-07-17 公布）。",
    // 五区二县及西咸新区为独立招生单元，控制线由各区县教育局公布（2026-07-17）。
    // 来源：controlLines2026Districts（汇总自西安本地宝 / 腾讯新闻，原始为各区县教育局公告）。
    districts: [
      { name: "长安区", regular: 425.0, sportsArt: 255.0, comprehensiveHigh: 386.0, estimated: false, published: "2026-07-17", note: "" },
      { name: "临潼区", regular: 342.0, sportsArt: null, comprehensiveHigh: 323.0, estimated: false, published: "2026-07-17", note: "" },
      { name: "鄠邑区", regular: 357.0, sportsArt: 214.2, comprehensiveHigh: 333.0, estimated: true, published: "2026-07-17", note: "预估最低控制线" },
      { name: "阎良区", regular: 383.0, sportsArt: 229.8, comprehensiveHigh: 350.0, estimated: false, published: "2026-07-17", note: "" },
      { name: "高陵区", regular: 387.0, sportsArt: null, comprehensiveHigh: 336.0, estimated: false, published: "2026-07-17", note: "" },
      { name: "西咸新区", regular: 383.0, sportsArt: 229.8, comprehensiveHigh: 370.0, estimated: false, published: "2026-07-17", note: "" },
      { name: "周至县", regular: 345.6, sportsArt: 207.4, comprehensiveHigh: 332.5, estimated: false, published: "2026-07-17", note: "" },
      { name: "蓝田县", regular: null, sportsArt: null, comprehensiveHigh: null, estimated: false, published: null, note: "暂未公布" },
    ],
  },
};

// 临潼区分段锚点（非完整一分一段表）：来源 今日头条《城六区620分以上2109人,临潼区只有3个…》(2026-07-19)。
// 仅收录公开报道中明确列出的「≥该分数人数」锚点，用于直观对比城六区与郊县生源差距；
// 非官方完整分段表，不可用于精确位次计算。五区二县其余单元暂无可公开查证的逐分区段数据。
export const LINTONG_SCORE_ANCHORS = {
  totalCandidates: 6411,
  source: "公开报道锚点（非官方完整一分一段表）",
  anchors: [
    { score: 620, geCount: 3 },
    { score: 610, geCount: 18 },
    { score: 600, geCount: 46 },
    { score: 510, geCount: 1594 },
  ],
};

// 一句话数据状态说明（用于页面脚注）
export const DATA_STATUS_NOTE =
  "本站仅收录西安市教育局等官方渠道已发布的数据并标注来源；2026 年城六区录取控制线（普高 492.0 / 特长生 295.2 / 综合高中班 465.0）已于 2026-07-17 由西安市教育局公布并收录，位次估算据此校准；五区二县及西咸新区各单元 2026 录取控制线（长安 425 / 临潼 342 / 鄠邑 357(预估) / 阎良 383 / 高陵 387 / 西咸 383 / 周至 345.6，蓝田暂未公布）已据各区县教育局公布汇总收录。2026 年各校录取分数线在录取结束前未公布，统一标注「待官方发布」，不进行预测或估算；一分一段表全市目前仅城六区官方公开发布完整版（已收录并用于位次估算），五区二县其余单元待官方分段表发布后补充。普通高中招生计划、定向生计划来自西安市教育局 2026-07-16 官方 PDF；民办初中（小升初）招生计划来自西安市教育局 2026-07-02 官方通知，属义务教育电脑随机录取阶段，与高中中招志愿不同。";

// 学校数据层（方案第十、十一、十二节）
// 校库来自 data/schools.json；本文件统一类型并封装匹配/分类/代码匹配逻辑。
import schoolsRaw from "../../data/schools.json";
import { chengliuScoreToRank } from "./score-bands";

export type School = {
  id: string;
  name: string;
  code: string;
  district: string; // 数据区县：chengliuqu / xixian / changan
  tier: string;
  batch: number;
  cut: Record<string, number>;
  region?: string; // 学校所属行政区/开发区（如雁塔区、碑林区、曲江新区等）
  schoolType?: "high" | "junior" | "vocational" | "comprehensive"; // high=普通高中（默认），junior=初中，vocational=职业高中，comprehensive=综合高中（低于普高线，结对普高）；首页推荐/匹配仅面向普高
  enroll?: number;
  promo?: number;
  pressure?: number;
  distance?: number;
  directionalQuota?: number; // 原字段名 dingxiang
  pairHigh?: string; // 综合高中结对普通高中（如「航天中学」）；仅 schoolType==="comprehensive" 使用
  g985?: number;
  g211?: number;
  keyClass?: string;
  nonKey?: string;
  ownership?: "public" | "private"; // 公办 / 民办
  referenceScore: number; // 派生：最新年份录取参考分
  ref2026?: number; // 五区二县等暂无 2026 官方线的区县：由历史线按实测折算系数填入（2026 等效参考分）
  est2026?: number; // 2026 预估投档线（来自最新估分总表）；非空时主分数应按“2026预估分”标注
  lastYearRank?: string;
  // —— 2026 官方招生计划字段（来自西安市教育局《2026年普通高中分学校招生计划》）——
  planStatus?: "verified" | "pending_review"; // verified=已录入 2026 官方计划；pending_review=旧库校、未出现在 2026 官方计划
  admissionUnit?: string; // 招生单元（城六区 / 长安区 / 西咸新区直管区 / 其他招生单元）
  planYear?: number; // 计划年份
  planSource?: string; // 官方 PDF 来源 URL
  citySixPlan?: number; // 面向城六区计划数
  localPlan?: number; // 区县内 / 单元内计划数
};

// 数据来源声明（西安市教育局 2026 中招官方口径，须在推荐/计划页展示）
export const DATA_SOURCE_STATEMENT =
  "数据来源：西安市教育局《2026年普通高中分学校招生计划》；学校计划、招生单元及办学层级以官方附件为准。志愿推荐结果仅作信息参考，最终以西安市中招录取平台公布结果为准。";

// 学校层级中文选项（仅 省示范 / 省标 / 普高）
export const TIER_OPTIONS = ["省示范", "省标", "普高"] as const;
export type TierOption = (typeof TIER_OPTIONS)[number];
export function tierLabel(t?: string): string {
  return t === "省示范" || t === "省标" || t === "普高" ? t : "";
}

export type Ownership = "public" | "private";

// 公办/民办 中文标签
export const OWNERSHIP_CN: Record<Ownership, string> = {
  public: "公办",
  private: "民办",
};

// 取学校性质的中文标签，未知返回空串
export function ownershipLabel(o?: Ownership): string {
  return o === "public" || o === "private" ? OWNERSHIP_CN[o] : "";
}

// 将原始数据映射到统一结构，并把 dingxiang 映射到 directionalQuota，补充 referenceScore
function normalize(raw: any): School {
  const years = Object.keys(raw.cut || {}).map(Number).sort((a, b) => b - a);
  // est2026（最新预估投档线）优先作为 2026 参考分；其次 ref2026（折算）；再次 cut 最新年份。
  const ref = raw.est2026 != null ? raw.est2026
    : raw.ref2026 != null ? raw.ref2026
    : raw.cut?.[String(years[0])] ?? 0;
  return {
    id: raw.id,
    name: raw.name,
    code: raw.code || "",
    district: raw.district,
    tier: raw.tier,
    batch: raw.batch ?? 2,
    cut: raw.cut || {},
    enroll: raw.enroll,
    promo: raw.promo,
    pressure: raw.pressure,
    distance: raw.distance,
    directionalQuota: raw.dingxiang,
    g985: raw.g985,
    g211: raw.g211,
    keyClass: raw.keyClass,
    nonKey: raw.nonKey,
    ownership: raw.ownership === "private" ? "private" : "public",
    referenceScore: ref,
    schoolType: raw.schoolType === "junior" ? "junior" : raw.schoolType === "vocational" ? "vocational" : raw.schoolType === "comprehensive" ? "comprehensive" : "high",
    est2026: raw.est2026 ?? undefined,
    planStatus: raw.planStatus === "verified" ? "verified" : raw.planStatus === "pending_review" ? "pending_review" : undefined,
    admissionUnit: raw.admissionUnit,
    planYear: raw.planYear,
    planSource: raw.planSource,
    citySixPlan: raw.citySixPlan,
    localPlan: raw.localPlan,
    region: raw.region,
    pairHigh: raw.pairHigh,
  };
}

export const schools: School[] = (schoolsRaw as any[]).map(normalize);

// 数据区县（chengliuqu / xixian / changan）
export function latestYear(cut: Record<string, number>): number {
  return Object.keys(cut).map(Number).sort((a, b) => b - a)[0] ?? 0;
}

// 精准推荐匹配选项：可按学校性质、学校层级二次筛选；默认排除 待核验（pending_review）学校
export type MatchOptions = {
  ownership?: "public" | "private";
  tier?: string; // 省示范 / 省标 / 普高
  includePending?: boolean; // 仅搜索/核对场景用，精准推荐必须为 false
};

// 免费版：向下 20 分、向上 40 分（如 560 分 → 540–600），按与用户分数差值升序
// 2026-07-17 新增：
//  - 必须按招生单元（城六区/长安/西咸）隔离，避免城六区学生匹配到长安/西咸高中；
//  - 必须排除 planStatus==="pending_review" 的学校——未出现在 2026 官方计划中的校不得进入精准推荐，
//    只能以「待核验」形式呈现（用户手动选校时可见，但自动推荐不出）。
export function getFreeMatchedSchools(
  score: number,
  dataDistrict: string,
  list: School[] = schools,
  opts: MatchOptions = {}
): School[] {
  const source = (dataDistrict ? list.filter((s) => s.district === dataDistrict) : list).filter(
    (s) => s.schoolType === "high"
  );
  const verified = source.filter((s) => (opts.includePending ? true : s.planStatus !== "pending_review"));
  const filtered = verified.filter((s) => {
    if (opts.ownership && s.ownership !== opts.ownership) return false;
    if (opts.tier && s.tier !== opts.tier) return false;
    return true;
  });
  return filtered
    .filter((s) => {
      const d = s.referenceScore - score;
      return d >= -20 && d <= 40;
    })
    .sort((a, b) => Math.abs(a.referenceScore - score) - Math.abs(b.referenceScore - score));
}

// 是否已在 2026 官方计划中核验（供 UI 展示「待核验」徽标）
export function isVerifiedPlan(s: School): boolean {
  return s.planStatus === "verified";
}

// 冲稳保分类（方案第十二节）
export function classifySchool(score: number, referenceScore: number): "冲" | "稳" | "保" {
  const diff = referenceScore - score;
  if (diff >= 6) return "冲";
  if (diff >= -8) return "稳";
  return "保";
}

// 录取概率（模型估算）：基于考生分与学校预估投档线的分差，用 logistic 函数映射为 1–99 的百分比。
// 表示“达到/超过该校投档线的可能性”，为统计估算值，非官方一分一段表，仅供参考；
// 两端 clamp（1%–99%）以保留“任何学校都不保证 100%、任何冲刺都不至 0%”的诚实边界。
export function admissionProbability(score: number, referenceScore: number): number {
  const k = 0.14; // 分差每 ±7 分约对应概率翻倍/减半，贴合中考普高线附近的现实分散度
  const p = 1 / (1 + Math.exp(k * (referenceScore - score)));
  return Math.max(1, Math.min(99, Math.round(p * 100)));
}

// 录取概率配色：统一红色加亮（浅红底 + 红字 + 加粗），突出展示。
// 风险方向已由冲/稳/保徽标传达，概率本身不再分级配色，故忽略入参。
export function probClass(_p: number): string {
  return "text-[#dc2626] font-black bg-[#fee2e2]";
}

// 输入学校名称自动匹配代码（方案第八节 区域三）
export function findSchoolCode(name: string): string {
  const s = schools.find((x) => x.name === name);
  return s?.code ?? "";
}

export function getSchoolByName(name: string): School | undefined {
  return schools.find((x) => x.name === name);
}

export function getSchoolByCode(code: string): School | undefined {
  return schools.find((x) => x.code === code);
}

// 按名称或代码取学校性质（用于填报/官方页只存了名称或代码的志愿行）
export function getOwnership(name?: string, code?: string): Ownership | undefined {
  const byName = name ? getSchoolByName(name) : undefined;
  if (byName?.ownership) return byName.ownership;
  const byCode = code ? getSchoolByCode(code) : undefined;
  return byCode?.ownership;
}

// 按数据区县取学校
export function schoolsByDataDistrict(dataDistrict: string): School[] {
  return schools.filter((s) => s.district === dataDistrict);
}

// 常见学校简称 / 别名 -> 官方全称（支持搜索时命中简称）
const SCHOOL_NAME_ALIASES: Record<string, string> = {
  "西电附中": "西安电子科技大学附属中学",
  "西电中学": "西安市西电中学",
  "远东一中": "西安市远东第一中学",
  "高新四完": "西安高新区第四完全中学",
  "高新五中": "西安高新区第五高级中学",
  "西安中学": "陕西省西安中学",
  "曲江第一中学": "西安市曲江第一中学",
  "经开一中": "西安市经开第一中学",
  "经开三中": "西安市经开第三中学",
  "建大附中": "西安建筑科技大学附属中学",
  "西航一中": "西安市西航一中",
  "车辆中学": "西安市车辆中学",
  "铁一中陆港中学": "西安国际港务区铁一中陆港高级中学",
  "清华附中秦汉学校": "陕西省西咸新区秦汉中学",
  "西咸新区秦汉中学": "陕西省西咸新区秦汉中学",
  "陕西师范大学附属中学(长安校区)": "陕西师范大学附属中学长安校区",
  "高新一中沣东中学": "西安高新一中沣东中学",
  "长安区第一民办中学": "西安市长安区第一民办中学",
  "航天城第一中学": "西安市航天城第一中学",
  "航天城第二中学": "西安市航天城第二中学",
  "高新一中实验中学": "西安高新一中实验中学",
  "锦园中学": "西安锦园中学",
  "雁南中学": "西安雁南中学",
  "汉都新苑中学": "西安市汉都新苑中学",
  "东仪中学": "西安东仪中学",
  "东方中学": "西安市东方中学",
  "中铁中学": "西安市中铁中学",
  "五环中学": "西安市五环中学",
  "昆仑中学": "西安市昆仑中学",
  "华山中学": "西安市华山中学",
  "庆安中学": "西安市庆安高级中学",
  "西安市庆安初级中学(高中部)": "西安市庆安高级中学",
  "太白路中学": "西安太白学校",
  "博爱高级中学": "西安博爱学校",
  "西港花园高级中学": "西安西港花园高级中学",
  "西安滨河学校": "西安铁一中滨河高级中学",
  "西安博迪中学": "西安博迪学校",
  "雁塔二中": "西安市雁塔区第二中学",
  "高新四高(长安四中)": "西安市长安区第四中学",
  "蓝田县第一中学": "蓝田县城关中学",
  "西安市第十一中": "西安市第十一中学",
  "西安市崇是中学": "西安崇是中学",
  "西安市鄠邑区第一中学": "鄠邑区第一中学",
  "西安市鄠邑区第四中学(西安高新区第六高级中学)": "西安市鄠邑区第四中学",
  "西安市高新六高级中学": "西安市鄠邑区第四中学",
  "西安交大附中航天学校": "西安交通大学附属中学航天高级中学",
  "交大创新港中学": "西安市创新港中学(创新港西安交通大学附属中学)",
  "铁一中分校": "西安铁一中国际合作学校",
  "浐灞丝路学校(新学校)": "西安市浐灞丝路学校",
  "陕西师范大学陆港学校": "西安市浐灞国际港陕西师范大学陆港学校",
  "西咸新区泾河第一中学": "西咸新区泾河新城第一中学",
  "泾河新城第一中学": "西咸新区泾河新城第一中学",
  "西安高新二中": "西安市高新第二高级中学",
  "西安阳光中学": "西安市阳光中学",
  "西安景泓中学": "西安景泓高级中学",
  "西咸新区沣西中学": "西咸新区沣西第一高级中学",
  "西咸新区空港实验学校": "西咸新区空港第一学校",
  "西安高新第三高级中学": "西安高新第三中学",
  "西安博爱国际学校": "西安博爱学校",
  "西安交大附中航天高级中学": "西安交通大学附属中学航天高级中学",
  // 额外常用简称
  "远东二中": "西安市远东第二中学",
  "一中": "西安市第一中学",
  "三中": "西安市第三中学",
  "六中": "西安市第六中学",
  "八中": "西安市第八中学",
  "二十六中": "西安市第二十六中学",
  "八十五中": "西安市第八十五中学",
  "铁一中": "西安市铁一中学",
  "高新一中": "西安高新第一中学",
  "西工大附中": "西北工业大学附属中学",
  "交大附中": "西安交通大学附属中学",
  "师大附中": "陕西师范大学附属中学",
};

function normalizeSearchName(name: string): string {
  return name
    .replace(/\s+/g, "")
    .replace(/[\(（][^\(\)（）]*?(省示范|省标|普高)[^\(\)（）]*?[\)）]/g, "")
    .replace(/（/g, "(")
    .replace(/）/g, ")");
}

function coreName(name: string): string {
  return name.replace(/[\(（].*?[\)）]/g, "");
}

export function canonicalSearchName(name: string): string {
  const n = normalizeSearchName(name);
  return SCHOOL_NAME_ALIASES[n] ?? n;
}

// 全局学校搜索（支持简称/别名 + 字符级模糊匹配）
// 返回值按相关度排序，最多 20 条
export function searchSchools(query: string, opts: MatchOptions = {}): School[] {
  const raw = query.trim();
  if (!raw) return [];
  const q = normalizeSearchName(raw);
  const qCanon = canonicalSearchName(q);
  const qCore = normalizeSearchName(coreName(qCanon));

  const pool = schools.filter((s) => {
    if (s.schoolType === "junior") return false;
    if (opts.ownership && s.ownership !== opts.ownership) return false;
    if (opts.tier && s.tier !== opts.tier) return false;
    return true;
  });

  const scored = pool.map((s) => {
    const sName = normalizeSearchName(s.name);
    const sCore = normalizeSearchName(coreName(s.name));
    let score = 0;

    // 别名直接命中
    if (SCHOOL_NAME_ALIASES[q] === s.name || SCHOOL_NAME_ALIASES[q] === coreName(s.name)) score += 1000;

    // 规范名完全相等
    if (sName === qCanon || sCore === qCanon || sName === qCore || sCore === qCore) score += 900;

    // 子串命中
    if (sName.includes(q) || sCore.includes(q)) score += 400;

    // 2-gram 命中
    const bigrams = new Set<string>();
    for (let i = 0; i < q.length - 1; i++) bigrams.add(q.slice(i, i + 2));
    let biHits = 0;
    for (const b of bigrams) {
      if (sName.includes(b)) biHits++;
    }
    score += biHits * 60;

    // 单字符命中
    const chars = new Set(q.split(""));
    let charHits = 0;
    for (const c of chars) {
      if (sName.includes(c)) charHits++;
    }
    score += charHits * 5;

    // 代码命中
    if (s.code && s.code.includes(raw)) score += 80;

    return { s, score };
  });

  return scored
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((x) => x.s)
    .slice(0, 20);
}

// 数据区县 -> 页面招生单元下拉框 value（城六区默认雁塔，作为共享分数段位次表的入口）
export const DATA_TO_DISTRICT: Record<string, string> = {
  chengliuqu: "yanta",
  changan: "changan",
  xixian: "xixian",
  yanliang: "yanliang",
  lintong: "lintong",
  gaoling: "gaoling",
  huyi: "huyi",
  lantian: "lantian",
  zhouzhi: "zhouzhi",
};

// 区县（页面用 value）-> 数据区县 映射，与首页 DATA_DISTRICT 保持一致
export const DISTRICT_TO_DATA: Record<string, string> = {
  xincheng: "chengliuqu",
  yanta: "chengliuqu",
  beilin: "chengliuqu",
  lianhu: "chengliuqu",
  weiyang: "chengliuqu",
  bashan: "chengliuqu",
  xixian: "xixian",
  changan: "changan",
  // 五区二县：每个区县为独立招生区域（西安市教育局 2026 中招方案），各自成单元，不混用
  yanliang: "yanliang",
  lintong: "lintong",
  gaoling: "gaoling",
  huyi: "huyi",
  lantian: "lantian",
  zhouzhi: "zhouzhi",
};

// 数据区县 / 招生单元 -> 中文区域标签（用于学校悬浮提示“所属区域”）
export const DISTRICT_LABELS: Record<string, string> = {
  chengliuqu: "城六区",
  changan: "长安区",
  xixian: "西咸新区",
  yanliang: "阎良区",
  lintong: "临潼区",
  gaoling: "高陵区",
  huyi: "鄠邑区",
  lantian: "蓝田县",
  zhouzhi: "周至县",
};
export function districtLabelOf(d: string): string {
  return DISTRICT_LABELS[d] || d;
}

/* ---------------- 位次估算（与首页一致，供报告模块复用） ---------------- */
// total 取自官方公布的 2026 年西安市中考考生人数（城六区 8.2 万 / 长安 2.4 万 / 西咸约 1.2 万）
// 2026-07-17 官方公布城六区普高录取控制线 492.0 分（体育艺术特长生 295.2 / 试点综合高中班 465.0）。
// 校准锚点：城六区普高计划（公办 42429 + 民办 11420 = 53849 人），即“过 492 线≈具备普高资格”的群体≈53849 人。
//   => 以正态分布锚定 rank(492) ≈ 53849：z(492)=NCDF⁻¹(1−53849/82000)=−0.4035。
//   => 取 spread=80（640 分制下中考成绩经验标准差），得 mean = 492 − (−0.4035)×80 ≈ 524.3。
// changan/xixian 无独立官方控制线，按与城六区相同的“控制线→计划”偏移量(+42.3)平移均值，保持内部一致。
// 位次结果为“估算值”，非官方一分一段表；控制线附近因实际过线群体含少量余量，真实位次可能略高于本估算。
const DISTRICT_STATS: Record<string, { total: number; mean: number; spread: number }> = {
  chengliuqu: { total: 82000, mean: 524.3, spread: 80 },
  changan: { total: 24000, mean: 518.3, spread: 74 },
  xixian: { total: 12000, mean: 516.3, spread: 72 },
  // 五区二县：考生人数与均值为估算（无官方一分一段），位次标注“模型估算”，仅供参考
  yanliang: { total: 3500, mean: 500, spread: 70 },
  lintong: { total: 9000, mean: 500, spread: 72 },
  gaoling: { total: 5500, mean: 500, spread: 70 },
  huyi: { total: 7500, mean: 500, spread: 72 },
  lantian: { total: 8500, mean: 500, spread: 72 },
  zhouzhi: { total: 9500, mean: 500, spread: 72 },
};

function erf(x: number): number {
  const t = 1 / (1 + 0.3275911 * Math.abs(x));
  const y =
    1 -
    (((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t *
      Math.exp(-x * x));
  return x >= 0 ? y : -y;
}
function ncdf(x: number): number {
  return 0.5 * (1 + erf(x / Math.SQRT2));
}

// 分数 -> 位次（dataDistrict: chengliuqu / xixian / changan）
// 城六区优先使用 2026 官方一分一段表（511–633 精准；表外按真实表尾/表头斜率外推）；
// 长安/西咸无官方分段表，回落到已锚定 2026 控制线(492)的正态模型估算。
export function estimateRank(score: number, dataDistrict = "chengliuqu"): { rank: number; total: number; percentile: number; exact?: boolean; source?: "band" | "model" | "extrapolated" } {
  if (!Number.isFinite(score)) return { rank: 0, total: 82000, percentile: 0 };
  const st = DISTRICT_STATS[dataDistrict] || DISTRICT_STATS.chengliuqu;

  if (dataDistrict === "chengliuqu") {
    const band = chengliuScoreToRank(score);
    if (band.ok) {
      const TOTAL = 82000;
      const pct = Math.round((band.rank / TOTAL) * 1000) / 10;
      return { rank: band.rank, total: TOTAL, percentile: pct, exact: band.exact, source: band.source };
    }
  }

  // 长安/西咸 或城六区异常：正态模型估算（已锚定 2026 官方控制线 492.0）
  const z = (score - st.mean) / st.spread;
  const p = ncdf(z);
  const rank = Math.max(1, Math.round(st.total * (1 - p)));
  return { rank, total: st.total, percentile: Math.round((1 - p) * 1000) / 10, exact: false, source: "model" };
}

// 定向生预估录取线：西安市政策为“定向生录取分数不低于本校统招线 50 分”
export const DIRECTIONAL_DROP = 50;

// 取城六区（chengliuqu）全部高中，按参考分降序并附估算位次，供报告“分数位次一览”使用
export function chengliuquSchoolsWithRank(): Array<School & { rank: number }> {
  return schools
    .filter((s) => s.district === "chengliuqu" && s.schoolType === "high")
    .map((s) => ({ ...s, rank: estimateRank(s.referenceScore, "chengliuqu").rank }))
    .sort((a, b) => b.referenceScore - a.referenceScore);
}

// 取指定数据区县内带定向生名额的学校（dingxiang > 0），按参考分降序
export function directionalSchools(dataDistrict: string): School[] {
  return schools
    .filter((s) => s.district === dataDistrict && s.schoolType === "high" && (s.directionalQuota ?? 0) > 0)
    .sort((a, b) => b.referenceScore - a.referenceScore);
}

// 根据分数与就读初中所在数据区县，推荐 3 所合适的定向生高中
// 策略：按“定向生预估线（统招线 - 50 分）”与用户分数的接近程度排序，取前 3。
export function directionalPlanSchools(score: number, dataDistrict: string): School[] {
  const list = directionalSchools(dataDistrict);
  if (!list.length || !Number.isFinite(score)) return [];
  return list
    .sort(
      (a, b) =>
        Math.abs(a.referenceScore - DIRECTIONAL_DROP - score) -
        Math.abs(b.referenceScore - DIRECTIONAL_DROP - score)
    )
    .slice(0, 3);
}

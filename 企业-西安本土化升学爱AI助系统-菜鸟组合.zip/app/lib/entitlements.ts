// 套餐权益与权限规则（方案第九节）
// 纯前端权限层；服务端在 /api 权益校验接口会再次校验，避免仅靠 localStorage 越权。

export type PackageId = "free" | "upgrade_99" | "match_29_9" | "planning_199" | "review_599";

export type ProfileLock = {
  score: number;
  rank: string;
  district: string;
  juniorSchool: string;
  directionalSchool?: string;
  packageId: PackageId;
  lockedAt: string;
};

export const packageRules = {
  free: {
    canEditFiling: false,
    canGenerate: false,
    simulationLimit: 0,
    canViewRiskLayers: false,
    canViewMatchAnalysis: false,
    canViewTeacherReview: false,
  },
  // 升学会员（¥99 入门）：解锁参考学校推荐与志愿方案生成（核心查询能力）
  upgrade_99: {
    canEditFiling: true,
    canGenerate: true,
    simulationLimit: 3,
    canViewRiskLayers: true,
    canViewMatchAnalysis: false,
    canViewTeacherReview: false,
  },
  match_29_9: {
    canEditFiling: true,
    canGenerate: true,
    simulationLimit: 3,
    canViewRiskLayers: true,
    canViewMatchAnalysis: false,
    canViewTeacherReview: false,
  },
  planning_199: {
    canEditFiling: true,
    canGenerate: true,
    simulationLimit: Infinity,
    canViewRiskLayers: true,
    canViewMatchAnalysis: true,
    canViewTeacherReview: false,
  },
  review_599: {
    canEditFiling: true,
    canGenerate: true,
    simulationLimit: Infinity,
    canViewRiskLayers: true,
    canViewMatchAnalysis: true,
    canViewTeacherReview: true,
  },
} as const;

export const packageMeta: Record<PackageId, { label: string; price: number; desc: string }> = {
  free: { label: "免费版", price: 0, desc: "分数上下80分学校匹配、定向生查询、基础报告" },
  upgrade_99: { label: "升学会员", price: 99, desc: "解锁参考学校推荐 + 志愿方案生成 + 位次/概率分析（入门会员）" },
  match_29_9: { label: "冲稳保分析", price: 29.9, desc: "冲刺/稳妥/保底推荐 + 升学概率 + 3次模拟填报" },
  planning_199: { label: "AI志愿规划", price: 199, desc: "不限次模拟 + 匹配度/压力/三年规划/985·211预测" },
  review_599: { label: "老师复审", price: 599, desc: "199全部权益 + 老师人工复审与最终方案确认" },
};

export function canGeneratePlan(packageId: PackageId, usedCount: number) {
  const rule = packageRules[packageId];
  if (!rule.canGenerate) return false;
  if (rule.simulationLimit === Infinity) return true;
  return usedCount < rule.simulationLimit;
}

export function getSimulationLabel(packageId: PackageId, usedCount: number) {
  const rule = packageRules[packageId];
  if (rule.simulationLimit === 0) return "免费用户不可生成志愿方案";
  if (rule.simulationLimit === Infinity) return "不限次模拟填报";
  return `已使用${usedCount}/${rule.simulationLimit}次`;
}

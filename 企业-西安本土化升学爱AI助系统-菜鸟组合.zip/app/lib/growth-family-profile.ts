// 长安成长地图 · 家庭成长档案模型（首版，纯函数，无副作用）
//
// 隐私边界（硬性）：本模块不读取/不写入任何浏览器本地存储或 Cookie，不发起任何网络请求或
// 调用服务端 Action/API，不收集可识别未成年人的个人信息（姓名、证件、联系方式、住址、
// 学校班级、成绩、诊断等）。档案仅存在于调用方（页面内存）中，刷新或关闭页面即清空。
//
// 本模块刻意「只整理家长填写的关注点」，不产出任何教育诊断、心理评估、智力/人格结论、
// 录取概率预测或学校排名。所有摘要都必须附带「生成依据」。
//
// 显式带 .ts 后缀，使本模块既能被打包器解析，也能被 `node --test --experimental-strip-types` 直接运行。

import type { GrowthStage, SchoolOwnership } from "./growth-schools.ts";

// ===== 枚举与字段类型 =====

export type ChildStage =
  | "kindergarten"
  | "primary_lower"
  | "primary_upper"
  | "junior"
  | "unknown";

export type ChildAgeBand =
  | "age_3_5"
  | "age_6_8"
  | "age_9_12"
  | "age_13_15"
  | "prefer_not_to_say";

// 西安区县枚举（首版取常用区县；未限定与西安以外单独区分，避免伪造区域）。
export type XiAnDistrict =
  | "新城区"
  | "碑林区"
  | "莲湖区"
  | "雁塔区"
  | "灞桥区"
  | "未央区"
  | "阎良区"
  | "临潼区"
  | "长安区"
  | "高陵区"
  | "鄠邑区"
  | "蓝田县"
  | "周至县";

export type FamilyDistrict = XiAnDistrict | "undecided" | "outside_xian";

export type ResidenceSituation =
  | "local_household"
  | "nonlocal_with_residence"
  | "nonlocal_other"
  | "unclear"
  | "prefer_not_to_say";

export type SchoolOwnershipPreference =
  | "public"
  | "private"
  | "inclusive"
  | "no_preference";

export type AnnualBudgetBand =
  | "under_1w"
  | "1w_3w"
  | "3w_6w"
  | "over_6w"
  | "unclear"
  | "prefer_not_to_say";

export type CommutePreference =
  | "under_30m"
  | "30m_60m"
  | "over_60m"
  | "boarding_possible"
  | "unclear";

export type Priority =
  | "admission_policy"
  | "tuition"
  | "commute"
  | "meals"
  | "teacher_stability"
  | "teacher_patience"
  | "curriculum"
  | "foreign_language"
  | "outdoor_activity"
  | "class_size"
  | "homework_load"
  | "school_management"
  | "parent_communication"
  | "transition_support";

export type LearningObservation =
  | "needs_interest_guidance"
  | "needs_habit_support"
  | "needs_reading_support"
  | "needs_writing_support"
  | "needs_calculation_support"
  | "needs_language_environment"
  | "adapts_slowly"
  | "sensitive_to_pressure"
  | "prefers_hands_on"
  | "no_specific_observation";

// 多选项数量上限（关注重点与学习观察均适用）。
export const MAX_MULTI_CHOICE = 5;
// 补充说明字数上限。
export const NOTES_MAX_LENGTH = 200;

export interface FamilyProfile {
  childStage: ChildStage;
  childAgeBand: ChildAgeBand;
  familyDistrict: FamilyDistrict;
  residenceSituation: ResidenceSituation;
  schoolOwnershipPreference: SchoolOwnershipPreference;
  annualBudgetBand: AnnualBudgetBand;
  commutePreference: CommutePreference;
  priorities: Priority[];
  learningObservations: LearningObservation[];
  notes: string;
  guardianConfirmed: boolean;
}

// 严禁字段（仅作静态防御性声明；本模块绝不使用这些字段，也不接受外部注入）。
export const FORBIDDEN_FIELDS = [
  "iq",
  "intelligenceScore",
  "mbti",
  "diagnosis",
  "personalityType",
  "admissionProbability",
  "recommendedSchoolRank",
] as const;

// ===== 标签映射（供 UI 与摘要复用，避免散落硬编码）=====

export const CHILD_STAGE_LABELS: Record<ChildStage, string> = {
  kindergarten: "幼儿园",
  primary_lower: "小学低年级",
  primary_upper: "小学高年级",
  junior: "初中",
  unknown: "暂未选择",
};

export const CHILD_AGE_BAND_LABELS: Record<ChildAgeBand, string> = {
  age_3_5: "3-5 岁",
  age_6_8: "6-8 岁",
  age_9_12: "9-12 岁",
  age_13_15: "13-15 岁",
  prefer_not_to_say: "暂不填写",
};

export const RESIDENCE_LABELS: Record<ResidenceSituation, string> = {
  local_household: "西安户籍",
  nonlocal_with_residence: "非西安户籍（有居住证/落户）",
  nonlocal_other: "非西安户籍（其他情况）",
  unclear: "暂不清楚",
  prefer_not_to_say: "暂不填写",
};

export const OWNERSHIP_PREF_LABELS: Record<SchoolOwnershipPreference, string> = {
  public: "公办",
  private: "民办",
  inclusive: "融合/特教",
  no_preference: "无偏好",
};

export const BUDGET_LABELS: Record<AnnualBudgetBand, string> = {
  under_1w: "1 万以内",
  "1w_3w": "1 万至 3 万",
  "3w_6w": "3 万至 6 万",
  over_6w: "6 万以上",
  unclear: "暂不清楚",
  prefer_not_to_say: "暂不填写",
};

export const COMMUTE_LABELS: Record<CommutePreference, string> = {
  under_30m: "30 分钟以内",
  "30m_60m": "30 至 60 分钟",
  over_60m: "60 分钟以上",
  boarding_possible: "可考虑寄宿",
  unclear: "暂不清楚",
};

export const PRIORITY_LABELS: Record<Priority, string> = {
  admission_policy: "入学政策",
  tuition: "费用",
  commute: "通勤",
  meals: "餐食",
  teacher_stability: "师资稳定性",
  teacher_patience: "教师耐心",
  curriculum: "课程设置",
  foreign_language: "外语",
  outdoor_activity: "户外活动",
  class_size: "班额",
  homework_load: "作业量",
  school_management: "学校管理",
  parent_communication: "家校沟通",
  transition_support: "衔接支持",
};

export const OBSERVATION_LABELS: Record<LearningObservation, string> = {
  needs_interest_guidance: "兴趣引导",
  needs_habit_support: "习惯养成",
  needs_reading_support: "阅读支持",
  needs_writing_support: "书写支持",
  needs_calculation_support: "计算支持",
  needs_language_environment: "语言环境",
  adapts_slowly: "适应较慢",
  sensitive_to_pressure: "对压力较敏感",
  prefers_hands_on: "偏好动手实践",
  no_specific_observation: "暂无具体观察",
};

// ===== 校验相关类型 =====

export interface ValidationIssue {
  code: string;
  message: string;
  field?: string;
}

export interface ProfileValidation {
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
}

// ===== 纯函数实现 =====

export function createEmptyFamilyProfile(): FamilyProfile {
  return {
    childStage: "unknown",
    childAgeBand: "prefer_not_to_say",
    familyDistrict: "undecided",
    residenceSituation: "unclear",
    schoolOwnershipPreference: "no_preference",
    annualBudgetBand: "unclear",
    commutePreference: "unclear",
    priorities: [],
    learningObservations: [],
    notes: "",
    guardianConfirmed: false,
  };
}

// 清空档案：返回一份全新的空档案（不修改入参）。
export function clearFamilyProfile(): FamilyProfile {
  return createEmptyFamilyProfile();
}

// 多选项通用切换：返回新数组，不修改入参。
// - 已在列表中：移除。
// - 达到上限 max：忽略新增（保持原样）。
// - 若指定 exclusive（互斥项，如 no_specific_observation）：
//   * 选中互斥项时，清空其它项，仅保留互斥项；
//   * 选中非互斥项时，若列表中存在互斥项则先移除互斥项。
export function toggleLimitedChoice<T extends string>(
  current: T[],
  value: T,
  opts: { max: number; exclusive?: T },
): T[] {
  const has = current.includes(value);
  if (has) {
    return current.filter((v) => v !== value);
  }
  let next = current.slice();
  const { exclusive } = opts;
  if (exclusive !== undefined) {
    if (value === exclusive) {
      return [exclusive];
    }
    next = next.filter((v) => v !== exclusive);
  }
  if (next.length >= opts.max) {
    return current;
  }
  next.push(value);
  return next;
}

// 清洗补充说明：去除 HTML/脚本、javascript: 协议、联系方式与身份证样式内容，并截断到上限。
// 行为明确：截断 + 清理；返回清理后的字符串（不抛出、不保留敏感片段）。
export function sanitizeFamilyNotes(raw: string): string {
  if (typeof raw !== "string") return "";
  let s = raw;

  // 1) 去除 HTML 标签（含 <script>...</script> 等成对标签与自闭合标签）。
  s = s.replace(/<\/?[a-zA-Z][^>]*>/g, "");

  // 2) 去除 javascript: 协议与内联事件处理（onload=、onerror= 等，值可为引号或单段 token）。
  s = s.replace(/javascript:/gi, "");
  s = s.replace(/\bon[a-zA-Z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "");

  // 3) 去除常见脚本调用（alert/confirm/prompt/eval 等），防止残留可执行片段。
  s = s.replace(/\b(alert|confirm|prompt|eval)\s*\([^)]*\)/gi, "");

  // 4) 去除联系方式样式内容。先做身份证（长数字，带词边界），再做手机号
  //    （同样带词边界，避免误吞身份证内的连续数字）：
  //    - 身份证样式（18 位末位可为 X，或 15 位）
  //    - 手机号（1 开头、第二位 3-9、共 11 位）
  //    - 微信号提示（"微信号"后接内容）
  //    - 邮箱（含 @ 的地址）
  s = s.replace(/\b\d{17}[\dXx]\b|\b\d{15}\b/g, "");
  s = s.replace(/\b1[3-9]\d{9}\b/g, "");
  s = s.replace(/微信号\s*[:：]?\s*\S+/gi, "");
  s = s.replace(/[\w.+-]+@[\w-]+\.[\w.-]+/gi, "");

  // 5) 折叠多余空白，去除首尾空格。
  s = s.replace(/\s+/g, " ").trim();

  // 6) 截断到上限（按码点，避免截断半个字符）。
  if (s.length > NOTES_MAX_LENGTH) {
    s = s.slice(0, NOTES_MAX_LENGTH);
  }
  return s;
}

// 校验档案合法性。注意：
// - guardianConfirmed=false 本身不是错误（生成摘要时另行拦截）；
// - notes 长度由 UI 在写入前经 sanitizeFamilyNotes 截断，此处仅作防御性校验。
export function validateFamilyProfile(p: FamilyProfile): ProfileValidation {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];

  if (!Array.isArray(p.priorities) || p.priorities.length > MAX_MULTI_CHOICE) {
    errors.push({
      code: "priorities_exceed_max",
      message: `关注重点最多可选 ${MAX_MULTI_CHOICE} 项`,
      field: "priorities",
    });
  }

  if (
    !Array.isArray(p.learningObservations) ||
    p.learningObservations.length > MAX_MULTI_CHOICE
  ) {
    errors.push({
      code: "observations_exceed_max",
      message: `学习观察最多可选 ${MAX_MULTI_CHOICE} 项`,
      field: "learningObservations",
    });
  }

  if (
    Array.isArray(p.learningObservations) &&
    p.learningObservations.includes("no_specific_observation") &&
    p.learningObservations.length > 1
  ) {
    errors.push({
      code: "observation_exclusive",
      message: "「暂无具体观察」不能与其它观察同时选择",
      field: "learningObservations",
    });
  }

  if (typeof p.notes === "string" && p.notes.length > NOTES_MAX_LENGTH) {
    errors.push({
      code: "notes_too_long",
      message: `补充说明最多 ${NOTES_MAX_LENGTH} 字`,
      field: "notes",
    });
  }

  return { errors, warnings };
}

// ===== 规划摘要与筛选建议 =====

export interface SuggestedFilters {
  stage: GrowthStage | "all";
  // "all" 表示不限；具体区县时给出区县名。若区域未在示例数据中存在，仍可给出建议，
  // 但不伪造任何匹配结果（筛选器按真实数据判定）。
  district: string;
  ownership: SchoolOwnership | "all";
}

export interface PlanningSummary {
  // 已填写条件摘要
  filledConditions: string[];
  // 当前规划重点
  planningFocus: string[];
  // 建议优先核实的信息
  suggestedVerifications: string[];
  // 建议筛选条件（仅阶段/区域/性质）
  suggestedFilters: SuggestedFilters;
  // 生成依据（每条结论对应哪些用户选择）
  basis: string[];
}

// 子阶段 -> 学校筛选阶段。unknown 映射为 "all"（不限）。
const STAGE_FROM_CHILD: Record<ChildStage, GrowthStage | "all"> = {
  kindergarten: "kindergarten",
  primary_lower: "primary",
  primary_upper: "primary",
  junior: "junior",
  unknown: "all",
};

// 办学性质偏好 -> 筛选性质。no_preference 映射为 "all"（不限）。
const OWNERSHIP_FROM_PREF: Record<
  SchoolOwnershipPreference,
  SchoolOwnership | "all"
> = {
  public: "public",
  private: "private",
  inclusive: "inclusive",
  no_preference: "all",
};

// 仅允许把「阶段 / 区域 / 性质」映射为筛选条件；其它维度（预算、通勤、关注点）不进入筛选。
export function deriveSuggestedSchoolFilters(p: FamilyProfile): SuggestedFilters {
  const stage = STAGE_FROM_CHILD[p.childStage];
  const ownership = OWNERSHIP_FROM_PREF[p.schoolOwnershipPreference];
  // 仅当选择了具体西安区县时才限定区域；未决定/西安以外均按不限处理（不伪造区域匹配）。
  const district =
    p.familyDistrict === "undecided" || p.familyDistrict === "outside_xian"
      ? "all"
      : p.familyDistrict;
  return { stage, district, ownership };
}

// 生成可解释的规划摘要。
// 规则：
// - guardianConfirmed=false 时返回 null（不在未确认时生成摘要）；
// - 只描述「家长填写的关注点」，不诊断孩子，不产出智力/人格/心理/医学结论；
// - 不预测录取概率，不生成学校排名；
// - 所有输出附「生成依据」。
export function buildPlanningSummary(p: FamilyProfile): PlanningSummary | null {
  if (!p.guardianConfirmed) {
    return null;
  }

  const filledConditions: string[] = [];
  const planningFocus: string[] = [];
  const suggestedVerifications: string[] = [];
  const basis: string[] = [];

  // 当前阶段
  if (p.childStage !== "unknown") {
    const stageText = CHILD_STAGE_LABELS[p.childStage];
    filledConditions.push(`孩子目前处于${stageText}阶段`);
    planningFocus.push(`建议优先了解${stageText}阶段的入学政策与衔接安排`);
    basis.push(`规划重点依据：您选择的孩子当前阶段（${stageText}）`);
  }

  // 家庭所在区域
  if (p.familyDistrict === "undecided" || p.familyDistrict === "outside_xian") {
    suggestedVerifications.push("建议优先核实目标区当年入学政策与划片范围");
  } else {
    filledConditions.push(`家庭所在区域为${p.familyDistrict}`);
    planningFocus.push(`建议核实${p.familyDistrict}当年划片与报名时间`);
    suggestedVerifications.push(
      `建议优先核实${p.familyDistrict}当年入学政策与划片范围`,
    );
    basis.push(`区域筛选依据：您选择的家庭所在区域（${p.familyDistrict}）`);
  }

  // 居住情况
  if (
    p.residenceSituation !== "unclear" &&
    p.residenceSituation !== "prefer_not_to_say"
  ) {
    filledConditions.push(`居住情况：${RESIDENCE_LABELS[p.residenceSituation]}`);
  }

  // 办学性质偏好
  if (p.schoolOwnershipPreference !== "no_preference") {
    const o = OWNERSHIP_PREF_LABELS[p.schoolOwnershipPreference];
    filledConditions.push(`办学性质偏好：${o}`);
    basis.push(`性质筛选依据：您选择的办学性质偏好（${o}）`);
  }

  // 预算范围（仅用于摘要提示，不进入筛选条件）
  if (
    p.annualBudgetBand !== "unclear" &&
    p.annualBudgetBand !== "prefer_not_to_say"
  ) {
    filledConditions.push(`年度预算范围：${BUDGET_LABELS[p.annualBudgetBand]}`);
    planningFocus.push("根据所选预算范围，可优先补充核实费用字段");
    suggestedVerifications.push("建议向学校核实当前年度收费明细与退费规则");
  }

  // 通勤偏好（仅用于摘要提示，不进入筛选条件）
  if (p.commutePreference !== "unclear") {
    filledConditions.push(`通勤偏好：${COMMUTE_LABELS[p.commutePreference]}`);
    suggestedVerifications.push("建议结合通勤方式实地了解上下学路线");
  }

  // 家长关注重点
  if (p.priorities.length > 0) {
    const names = p.priorities.map((x) => PRIORITY_LABELS[x]);
    filledConditions.push(`家长重点关注：${names.join("、")}`);
    planningFocus.push(
      `可结合关注重点（${names.join("、")}）对比不同机构的公开信息`,
    );
    basis.push(`规划重点依据：您勾选的关注重点（${names.join("、")}）`);
  }

  // 学习与适应观察（描述为「家长提到的关注」，非诊断）
  const observations = p.learningObservations.filter(
    (x) => x !== "no_specific_observation",
  );
  if (observations.length > 0) {
    const obs = observations.map((x) => OBSERVATION_LABELS[x]);
    filledConditions.push(`家长提到以下方面需要更多关注：${obs.join("、")}`);
    planningFocus.push("可在实地考察时关注师资稳定性与家校沟通情况");
  }

  // 补充说明
  const notes = p.notes.trim();
  if (notes.length > 0) {
    filledConditions.push(`补充说明：${notes}`);
  }

  // 通用核实建议（始终保留，强调以官方信息为准）
  suggestedVerifications.push(
    "所有信息以教育主管部门与学校官方公开信息为准",
  );

  const suggestedFilters = deriveSuggestedSchoolFilters(p);
  basis.push(
    "建议筛选仅包含阶段、区域、办学性质，依据您在上方填写的选择生成",
  );

  return {
    filledConditions,
    planningFocus,
    suggestedVerifications,
    suggestedFilters,
    basis,
  };
}

// 资料锁定与模拟次数（方案第五、六节）
// 支付确认后锁定分数/位次/区县/初中/定向学校，localStorage 作为临时缓存；
// 重要资料应同时落库，且权益以后端校验为准（见服务端 /api 权益校验）。
import type { PackageId, ProfileLock } from "./entitlements";

const LOCK_KEY = "ly_profile_locked";
const SIM_PREFIX = "ly_sim_used_";

export function saveProfileLock(lock: ProfileLock): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(LOCK_KEY, JSON.stringify(lock));
}

export function getProfileLock(): ProfileLock | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(LOCK_KEY);
    if (!raw) return null;
    const v = JSON.parse(raw) as ProfileLock;
    if (!v || typeof v.score !== "number") return null;
    return v;
  } catch {
    return null;
  }
}

export function isProfileLocked(): boolean {
  return getProfileLock() !== null;
}

export function clearProfileLock(): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem(LOCK_KEY);
}

// 模拟填报使用次数（按套餐隔离）
export function getSimUsed(packageId: PackageId): number {
  if (typeof window === "undefined") return 0;
  const n = Number(localStorage.getItem(SIM_PREFIX + packageId) || "0");
  return Number.isFinite(n) ? n : 0;
}

export function incSimUsed(packageId: PackageId): number {
  const n = getSimUsed(packageId) + 1;
  if (typeof window !== "undefined") localStorage.setItem(SIM_PREFIX + packageId, String(n));
  return n;
}

export function resetSimUsed(packageId: PackageId): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem(SIM_PREFIX + packageId);
}

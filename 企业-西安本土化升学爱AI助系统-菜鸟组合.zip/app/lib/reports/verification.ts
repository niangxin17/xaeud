// 真实性闸门（Truth Gates）
// 集中所有“能不能显示、怎么标注”的判断，UI 不直接写显示规则。

import type { DirectionalQuota, SourceMeta, VerificationStatus } from "./types";

export const VERIFICATION_LABELS: Record<VerificationStatus, string> = {
  official_verified: "官方已核验",
  school_published: "学校公开",
  historical_verified: "历史核验",
  incomplete: "口径不完整",
  not_published: "尚未发布",
  not_available: "暂无数据",
};

export function getVerificationLabel(status: VerificationStatus): string {
  return VERIFICATION_LABELS[status] ?? "暂无数据";
}

// 来源标签：组合状态 + 年份/更新时间
export function getMetricLabel(source: SourceMeta): string {
  const base = getVerificationLabel(source.status);
  if (source.status === "official_verified" || source.status === "school_published") {
    const when = source.updatedAt || source.publishedAt;
    return when ? `${base} · ${when}` : base;
  }
  if (source.status === "historical_verified") {
    return source.cohort ? `历史核验 · ${source.cohort}` : base;
  }
  return base;
}

// 官方分学校定向生名额：仅当状态为 official_verified 且具备年份、来源、名额、初中名称时才显示具体数字
export function isDisplayableExactQuota(q: DirectionalQuota | null): boolean {
  if (!q) return false;
  return (
    q.source.status === "official_verified" &&
    typeof q.year === "number" &&
    !!q.source.sourceUrl &&
    typeof q.quota === "number" &&
    !!q.middleSchoolName &&
    !!q.highSchoolName
  );
}

// 升学率（985/211）：必须同时具备届次、毕业生分母、统计范围、来源 URL，否则不得显示为确定百分比
export function isDisplayableRate(value: number | null, source: SourceMeta): boolean {
  if (typeof value !== "number") return false;
  return (
    (source.status === "official_verified" || source.status === "school_published") &&
    !!source.cohort &&
    !!source.sourceUrl
  );
}

// 班型：仅当学校官方公开材料可采信时显示具体名称，否则“学校未公开，无法判断”
export function isClassTrackVerified(source: SourceMeta): boolean {
  return source.status === "official_verified" || source.status === "school_published";
}

// 标准缺省来源：本项目真实数据大多为“历史/未发布”，统一用这里生成
export function makeHistoricalSource(cohort: string, notes?: string): SourceMeta {
  return {
    status: "historical_verified",
    sourceUrl: null,
    sourceTitle: null,
    publishedAt: null,
    updatedAt: null,
    cohort,
    notes: notes ?? null,
  };
}

export function makeNotPublishedSource(notes?: string): SourceMeta {
  return {
    status: "not_published",
    sourceUrl: null,
    sourceTitle: null,
    publishedAt: null,
    updatedAt: null,
    cohort: null,
    notes: notes ?? "待官方发布",
  };
}

export function makeIncompleteSource(notes?: string): SourceMeta {
  return {
    status: "incomplete",
    sourceUrl: null,
    sourceTitle: null,
    publishedAt: null,
    updatedAt: null,
    cohort: null,
    notes: notes ?? "口径不完整",
  };
}

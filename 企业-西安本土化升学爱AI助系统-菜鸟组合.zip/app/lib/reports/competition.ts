// 竞争度计算（Truth Gate）
// 只有同时具备本初中符合资格人数、该高中本初中名额和校内位次/历史记录时才计算；
// 缺任一项返回 "unknown"（UI 显示“无法判断”），不显示伪精确百分比。

export type CompetitionInput = {
  eligibleStudentCount: number | null; // 本初中符合资格人数
  quota: number | null; // 该高中本初中名额
  schoolRank: number | null; // 校内位次
  historicalLowestRank: number | null; // 历史最低录取位次
};

export type CompetitionLevel = "low" | "medium" | "high" | "unknown";

export function getCompetitionLevel(input: CompetitionInput): CompetitionLevel {
  const hasCore =
    typeof input.eligibleStudentCount === "number" &&
    typeof input.quota === "number" &&
    (typeof input.schoolRank === "number" || typeof input.historicalLowestRank === "number");
  if (!hasCore) return "unknown";

  const quota = input.quota as number;
  const eligible = input.eligibleStudentCount as number;
  if (quota <= 0 || eligible <= 0) return "unknown";

  const ratio = eligible / quota; // 竞争人数 / 名额
  if (ratio <= 1.5) return "low";
  if (ratio <= 3) return "medium";
  return "high";
}

export const COMPETITION_LABELS: Record<CompetitionLevel, string> = {
  low: "竞争较低",
  medium: "竞争中等",
  high: "竞争较高",
  unknown: "无法判断",
};

// 分析报告数据构建层（纯函数，无 DOM）
// 输入：真实用户的分数/位次/区县/初中 + 校库；输出：四档报告所需结构化数据。
// 所有“数字是否可作为确定结论”都通过 verification / competition 闸门判断，禁止伪精确。

import {
  schools,
  getFreeMatchedSchools,
  classifySchool,
  admissionProbability,
  directionalSchools,
  DIRECTIONAL_DROP,
  estimateRank,
  DISTRICT_TO_DATA,
  type School,
} from "../volunteer-data";
import { getCompetitionLevel, COMPETITION_LABELS } from "./competition";
import {
  isDisplayableExactQuota,
  isDisplayableRate,
  makeHistoricalSource,
  makeNotPublishedSource,
} from "./verification";

export type ReportProfile = {
  score: number;
  rank: string;
  district: string; // 页面 value
  juniorSchool: string;
  packageId: string;
};

export function dataDistrictOf(district: string): string {
  return DISTRICT_TO_DATA[district] || "chengliuqu";
}

export type PlacedSchool = {
  id: string;
  name: string;
  code: string;
  referenceScore: number;
  cat: "冲" | "稳" | "保";
  prob: number; // 录取概率（模型估算，1–99 百分比）
  reason: string;
  ownership: "public" | "private";
  district: string;
};

export type SortScenario = { title: string; badge: "rush" | "steady" | "safe" | "warn"; badgeText: string; text: string };

export type DirectionalRow = {
  name: string;
  ownership: "public" | "private";
  historicalTotal: number | null;
  quotaLabel: string; // 待2026官方分学校计划 / 不适用
  eligibilityLabel: string;
  suggestion: string;
};

export type SortReportData = {
  placed: PlacedSchool[];
  chong: number;
  wen: number;
  bao: number;
  scenarios: SortScenario[];
  directionalRows: DirectionalRow[];
};

export type SchoolFitRow = {
  school: School;
  cat: "冲" | "稳" | "保";
  prob: number; // 录取概率（模型估算，1–99 百分比）
  pressureLevel: "low" | "medium" | "high" | "unknown";
  pressureText: string;
  comfortZone: "below" | "matched" | "challenging" | "overloaded" | "unknown";
  comfortText: string;
  distanceKm: number | null;
  commuteText: string;
  rateLocked: boolean; // 985/211 是否因缺口径而锁定
  rateHistoricalNote: string;
  classTrackText: string; // 班型或“学校未公开”
  classTrackVerified: boolean;
  conclusion: "priority" | "consider" | "caution" | "not_recommended" | "unknown";
  conclusionText: string;
  reasons: string[];
};

export type FitReportData = {
  profileChips: Array<{ label: string; value: string }>;
  profileNote: string;
  rows: SchoolFitRow[];
  priorityNames: string;
  cautionNames: string;
};

export type ReviewFinding = { n: number; title: string; desc: string };
export type ConfirmRow = { item: string; status: "steady" | "warn"; statusText: string; opinion: string; owner: string };

export type ReviewReportData = {
  findings: ReviewFinding[];
  beforeText: string;
  afterText: string;
  beforeStructure: string;
  afterStructure: string;
  finalPlaced: PlacedSchool[];
  confirmRows: ConfirmRow[];
};

const PRESSURE_TEXT: Record<string, string> = { low: "压力较低", medium: "压力适中", high: "压力较高", unknown: "待核验" };
const COMFORT_TEXT: Record<string, string> = {
  below: "低于孩子能力",
  matched: "难度合适",
  challenging: "有挑战",
  overloaded: "超出承受",
  unknown: "待评估",
};
const CONCLUSION_TEXT: Record<string, string> = {
  priority: "优先考虑",
  consider: "可以考虑",
  caution: "谨慎冲刺",
  not_recommended: "不建议",
  unknown: "待核验",
};
const BADGE_OF_CAT: Record<string, string> = { 冲: "rush", 稳: "steady", 保: "safe" };

function reasonFor(cat: "冲" | "稳" | "保", refScore: number, userScore: number): string {
  if (cat === "冲") return `当前分数进入关注区间，作为上限冲刺；录取有运气成分，不作为唯一选择。`;
  if (cat === "保") return `低于当前分数，作为稳妥退路；确保有学上，家庭需提前确认可以接受。`;
  return `与稳定位次接近，是方案核心主选；正常发挥最可能被录取，建议重点比较。`;
}

// ===== 29.9 排序版 =====
export function buildSort(p: ReportProfile): SortReportData {
  const matched = getFreeMatchedSchools(p.score, dataDistrictOf(p.district)).map((s) => ({
    ...s,
    cat: classifySchool(p.score, s.referenceScore) as "冲" | "稳" | "保",
  }));
  const order: ("冲" | "稳" | "保")[] = ["冲", "稳", "保"];
  const placed: PlacedSchool[] = matched
    .slice()
    .sort((a, b) => {
      const ai = order.indexOf(a.cat);
      const bi = order.indexOf(b.cat);
      if (ai !== bi) return ai - bi;
      return b.referenceScore - a.referenceScore;
    })
    .map((s) => ({
      id: s.id,
      name: s.name,
      code: s.code,
      referenceScore: s.referenceScore,
      cat: s.cat,
      prob: admissionProbability(p.score, s.referenceScore),
      reason: reasonFor(s.cat, s.referenceScore, p.score),
      ownership: s.ownership ?? "public",
      district: s.district,
    }));
  const chong = placed.filter((s) => s.cat === "冲").length;
  const wen = placed.filter((s) => s.cat === "稳").length;
  const bao = placed.filter((s) => s.cat === "保").length;

  const scenarios: SortScenario[] = [
    { title: "如果少考 5 分", badge: "warn", badgeText: "降风险", text: "保留一所冲刺，将第二冲刺替换为主选，并把第一保底前移。" },
    { title: "如果维持当前分数", badge: "steady", badgeText: "当前方案", text: `继续采用 ${chong}冲＋${wen}主选＋${bao}保底，重点核验当年计划和资格。` },
    { title: "如果提高 10 分", badge: "rush", badgeText: "抬高上限", text: "可以上调一所冲刺学校，但不删除最后两所可接受退路。" },
    { title: "如果位次明显变化", badge: "safe", badgeText: "重新校准", text: "优先看位次而非绝对分数，重新计算每所学校的风险区间。" },
  ];

  // 定向生名额：本项目无“官方分学校生源计划”，按 truth gate 全部显示待核验
  const dirList = directionalSchools(dataDistrictOf(p.district));
  const directionalRows: DirectionalRow[] = dirList.map((s) => ({
    name: s.name,
    ownership: s.ownership ?? "public",
    historicalTotal: s.directionalQuota ?? null,
    quotaLabel: "待2026官方分学校计划",
    eligibilityLabel: "待确认",
    suggestion: "先核验连续学籍与本校名额",
  }));

  return { placed, chong, wen, bao, scenarios, directionalRows };
}

// ===== 199 适配版 =====
export function buildFit(p: ReportProfile): FitReportData {
  const matched = getFreeMatchedSchools(p.score, dataDistrictOf(p.district))
    .map((s) => ({
      ...s,
      cat: classifySchool(p.score, s.referenceScore) as "冲" | "稳" | "保",
    }))
    .slice(0, 8);

  const rows: SchoolFitRow[] = matched.map((s) => {
    const pr = (s.pressure ?? 0) as number;
    const pressureLevel: SchoolFitRow["pressureLevel"] =
      pr >= 4 ? "high" : pr >= 2 ? "medium" : pr > 0 ? "low" : "unknown";
    const diff = s.referenceScore - p.score;
    const comfortZone: SchoolFitRow["comfortZone"] =
      diff >= 20 ? "below" : diff >= 6 ? "challenging" : diff >= -10 ? "matched" : "overloaded";

    const rateSource = makeHistoricalSource("2023-2024", "校库历史估算，缺届次/分母/来源");
    const rateLocked = !isDisplayableRate(s.g985 ?? null, rateSource);

    const hasKey = !!s.keyClass;
    const classTrackVerified = false; // 无官方招生简章来源，一律标注待核验
    const classTrackText = hasKey ? `${s.keyClass}（待官方材料核验）` : "学校未公开，无法判断";

    let conclusion: SchoolFitRow["conclusion"];
    if (s.cat === "稳" && pressureLevel !== "high") conclusion = "priority";
    else if (s.cat === "稳") conclusion = "consider";
    else if (s.cat === "保") conclusion = "consider";
    else conclusion = "caution"; // 冲

    const reasons: string[] = [];
    if (comfortZone === "matched") reasons.push("学校难度与孩子当前水平匹配，三年节奏较稳。");
    else if (comfortZone === "challenging") reasons.push("有一定挑战，适合孩子再提升后适应。");
    else if (comfortZone === "below") reasons.push("学校难度低于孩子能力，可能缺乏足够挑战。");
    else reasons.push("学校难度偏高，需评估孩子持续状态。");
    if (pressureLevel === "high") reasons.push("学习竞争激烈，适合抗压能力强的孩子。");
    if (pressureLevel === "low") reasons.push("学业压力较小，利于保持自信与兴趣。");
    if (s.distance != null) reasons.push(`直线距离约 ${s.distance} 公里，通勤成本需结合家庭住址确认。`);

    return {
      school: s,
      cat: s.cat,
      prob: admissionProbability(p.score, s.referenceScore),
      pressureLevel,
      pressureText: PRESSURE_TEXT[pressureLevel],
      comfortZone,
      comfortText: COMFORT_TEXT[comfortZone],
      distanceKm: s.distance ?? null,
      commuteText: s.distance != null ? `直线约 ${s.distance} 公里（待家庭地址精算）` : "待家庭地址",
      rateLocked,
      rateHistoricalNote: rateLocked ? "待统一口径数据（缺届次/分母/来源）" : "可显示",
      classTrackText,
      classTrackVerified,
      conclusion,
      conclusionText: CONCLUSION_TEXT[conclusion],
      reasons,
    };
  });

  const { rank, total } = estimateRank(p.score, dataDistrictOf(p.district));
  const percentile = total ? Math.round((1 - rank / total) * 1000) / 10 : 0;
  const profileChips = [
    { label: "分数", value: `${p.score} 分` },
    { label: "估算位次", value: `约 ${rank.toLocaleString()}` },
    { label: "位次百分位", value: `前 ${percentile}%` },
    { label: "就读初中", value: p.juniorSchool || "待确认" },
  ];
  const priorityNames = rows.filter((r) => r.conclusion === "priority").map((r) => r.school.name).join("、") || "暂无";
  const cautionNames = rows.filter((r) => r.conclusion === "caution").map((r) => r.school.name).join("、") || "暂无";

  return {
    profileChips,
    profileNote: "孩子学科特点、抗压倾向、住宿意愿等需在家庭讨论中补充；以下基于分数与学校公开/历史数据给出适配框架。",
    rows,
    priorityNames,
    cautionNames,
  };
}

// ===== 599 老师复核版 =====
export function buildReview(p: ReportProfile): ReviewReportData {
  const sort = buildSort(p);
  const placed = sort.placed;
  const total = placed.length;
  const chong = sort.chong;
  const wen = sort.wen;
  const bao = sort.bao;

  // 风险发现（分析逻辑，非编造数据）
  const findings: ReviewFinding[] = [];
  let n = 1;
  if (wen >= 3) {
    findings.push({ n: n++, title: "主选学校风险区间较为接近", desc: "原方案多所主选风险相近，若当年计划收紧或分数线上浮，可能同时失去主要录取机会。建议主选内部再拉开梯度。" });
  }
  findings.push({ n: n++, title: "保底是否真实可接受尚未确认", desc: "系统无法判断家庭对保底学校的真实接受度。只有家庭明确可接受、不会录取后后悔的学校，才算真正的退路。" });
  findings.push({ n: n++, title: "“本校有指标”不等于“孩子可用”", desc: "定向生还受连续学籍、报考地、最低控制条件和志愿顺序影响；资格未最终确认前，不能依赖定向生结果制定整套方案。" });

  const beforeStructure = `${chong}冲＋${wen}主选＋${bao}保底`;
  // 建议：若主选过多则减一所相近主选补一所保底
  let sugWen = wen;
  let sugBao = bao;
  if (wen >= 4) { sugWen -= 1; sugBao += 1; }
  const afterStructure = `${chong}冲＋${sugWen}主选＋${sugBao}保底`;

  const confirmRows: ConfirmRow[] = [
    { item: "冲稳保梯度", status: "steady", statusText: "已检查", opinion: "风险层次已梳理清楚", owner: "老师完成" },
    { item: "学校适配", status: "steady", statusText: "已检查", opinion: "主选符合孩子与家庭约束", owner: "老师完成" },
    { item: "定向生资格", status: "warn", statusText: "待核验", opinion: "联系班主任确认连续学籍", owner: "家长" },
    { item: "保底接受度", status: "warn", statusText: "待确认", opinion: "需家庭确认是否真能接受", owner: "家庭" },
    { item: "最终位次校准", status: "warn", statusText: "待成绩", opinion: "出分后重新核对一次", owner: "平台＋家长" },
  ];

  return {
    findings,
    beforeText: `原方案 ${beforeStructure}：主选学校风险集中，部分退路未确认家庭接受度。`,
    afterText: `老师修改版 ${afterStructure}：减少一所相近风险主选，补入一所家庭可接受的稳妥学校，方案有上限也有退路。`,
    beforeStructure,
    afterStructure,
    finalPlaced: placed,
    confirmRows,
  };
}

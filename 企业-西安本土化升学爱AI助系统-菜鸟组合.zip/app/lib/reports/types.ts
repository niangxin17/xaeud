// 报告数据契约（handoff 方案 Data Contract）
// 所有进入报告的数字都必须通过 truth gate，缺失数据统一显示“待核验”，禁止用推算值冒充官方名额。

export type VerificationStatus =
  | "official_verified" // 官方已核验
  | "school_published" // 学校公开
  | "historical_verified" // 历史核验
  | "incomplete" // 口径不完整
  | "not_published" // 尚未发布
  | "not_available"; // 暂无数据

export type SourceMeta = {
  status: VerificationStatus;
  sourceUrl: string | null;
  sourceTitle: string | null;
  publishedAt: string | null;
  updatedAt: string | null;
  cohort: string | null; // 届次
  notes: string | null;
};

export type DirectionalQuota = {
  highSchoolId: string;
  highSchoolName: string;
  middleSchoolId: string;
  middleSchoolName: string;
  year: number;
  quota: number | null;
  eligibleStudentCount: number | null; // 本初中符合资格人数
  schoolRank: number | null; // 校内位次
  historicalLowestRank: number | null;
  competitionLevel: "low" | "medium" | "high" | "unknown";
  source: SourceMeta;
};

export type SchoolFit = {
  highSchoolId: string;
  pressureLevel: "low" | "medium" | "high" | "unknown";
  comfortZone: "below" | "matched" | "challenging" | "overloaded" | "unknown";
  commuteMinutes: number | null;
  accommodationRequired: boolean | null;
  gaokaoOutcome985Rate: number | null;
  gaokaoOutcome211Rate: number | null;
  outcomeSource: SourceMeta;
  classTracks: Array<{
    name: string;
    entryRule: string | null;
    dynamicAdjustment: boolean | null;
    source: SourceMeta;
  }>;
  conclusion: "priority" | "consider" | "caution" | "not_recommended" | "unknown";
  reasons: string[];
};

// 报告渲染上下文：来自真实用户
export type ReportContext = {
  studentName: string;
  score: number;
  rank: string;
  districtLabel: string;
  juniorSchool: string;
  dataDistrict: string; // chengliuqu | xixian | changan
  generatedAt: string;
};

// 冲稳保单校
export type PlacedSchool = {
  id: string;
  name: string;
  code: string;
  referenceScore: number;
  cat: "冲" | "稳" | "保";
  reason: string; // 放置理由
  ownership: "public" | "private";
};

// 套餐层级顺序，用于权益判定
export const TIER_ORDER = ["free", "match_29_9", "planning_199", "review_599"] as const;
export type Tier = (typeof TIER_ORDER)[number];

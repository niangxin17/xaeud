"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { track } from "./analytics";
import FreeSchoolsRecommendation from "./components/FreeSchoolsRecommendation";
import ReportModal from "./components/ReportModal";
import { PackageWorkbench } from "./components/package-workbench/PackageWorkbench";
import schoolsData from "../data/schools.json";
import { DISTRICT_TO_DATA, ownershipLabel, estimateRank, type School, searchSchools, DATA_TO_DISTRICT, isVerifiedPlan } from "./lib/volunteer-data";
import { saveProfileLock, getProfileLock } from "./lib/profile-lock";
import { schoolByDistrict } from "./lib/junior-schools";
import { SchoolSelect } from "./components/VolunteerEditor";
import { SchoolNameTag } from "./components/RegionTag";

// 区县：修正原乱码区县名（正确应为「灞桥区」）；西咸新区、长安区为特殊招生区域
const districtList = [
  { value: "xincheng", label: "新城区" },
  { value: "beilin", label: "碑林区" },
  { value: "lianhu", label: "莲湖区" },
  { value: "yanta", label: "雁塔区" },
  { value: "weiyang", label: "未央区" },
  { value: "bashan", label: "灞桥区" },
  { value: "xixian", label: "西咸新区", special: true },
  { value: "changan", label: "长安区", special: true },
  // 五区二县：每个区县为独立招生区域，各自成单元，不混用
  { value: "yanliang", label: "阎良区" },
  { value: "lintong", label: "临潼区" },
  { value: "gaoling", label: "高陵区" },
  { value: "huyi", label: "鄠邑区" },
  { value: "lantian", label: "蓝田县" },
  { value: "zhouzhi", label: "周至县" },
];
const specialDistricts = new Set(["xixian", "changan"]);

const MAX_SCORE = 640; // 2026 西安中考满分，硬性上限
// 输入框支持小数（如体育平时/中考折算出现 0.5 分），最多 1 位小数：
// 允许"520."等输入中间态原样保留；超过 1 位小数实时截断（520.55 → 520.5）；
// 超 640 钳制、负数钳制、非法字符丢弃。
// 取最近一个“非 2026”的历史录取线（用于展示原满分制下的近年线，与 2026 折算参考分区分）
function latestHistoricalLine(cut: Record<string, number>): { year: number; score: number } | null {
  const yrs = Object.keys(cut || {})
    .map(Number)
    .filter((y) => y !== 2026)
    .sort((a, b) => b - a);
  if (!yrs.length) return null;
  return { year: yrs[0], score: cut[String(yrs[0])] };
}

function clampScore(raw: string): string {
  if (raw === "" || raw === null) return "";
  // 仅数字 + 至多一个小数点：保留输入过程（含"520."、"."），不强行转 Number 吞掉小数点
  if (/^\d*\.?\d*$/.test(raw)) {
    const n = Number(raw);
    if (Number.isFinite(n) && n > MAX_SCORE) return String(MAX_SCORE);
    if (n < 0) return "0";
    // 限制最多 1 位小数：截断多余位数（520.55 → 520.5）
    if (/\.\d{2,}$/.test(raw)) {
      return raw.replace(/(\.\d)\d+$/, "$1");
    }
    return raw;
  }
  return "";
}

// 定向生初中：官方初中名录（2025 核验版，合并既有样例兜底），见 app/lib/junior-schools.ts

const strategies = ["平衡推荐", "稳妥优先", "适当冲刺"];

type Stage = "input" | "report" | "plan";

function Star() {
  return (
    <svg className="special-ic h-4 w-4 text-[#b94f38]" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M12 2l2.9 6.26L21.6 9.27l-4.8 4.68 1.13 6.6L12 17.6 5.07 21.15 6.2 14.55 1.4 9.27l6.7-1.01L12 2z" />
    </svg>
  );
}

const HIGH_SCHOOL_LINE = 492; // 2026 城六区普高录取控制线（官方 2026-07-17 公布：普高 492.0 / 特长生 295.2 / 综合高中班 465.0）
const LOW_SCORE_THRESHOLD = HIGH_SCHOOL_LINE; // 低于普高线触发鼓励/风险提示
const COMFORT_MESSAGES = [
  "分数不是人生的全部，但螺丝刀可以是。换个赛道照样发光！",
  "上清华和上螺丝之间，只差一个努力的你。别灰心，再来一年也很酷。",
  "这次没考好，下次考得更好。中考只是人生一站。",
  "别灰心，条条大路通罗马，有的路需要扳手。",
  "人生很长，螺丝也能拧成大师傅。",
  "没关系，职业技术学院也是广阔天地。",
  "640 分不是终点，但 492 分确实是中转站。",
  "分数低不要紧，心态不能低。阳光总在风雨后。",
  "这次考场失意，下次人生得意。厚积薄发！",
  "考砸了说明还有进步空间，未来可期。",
  "成绩只是张纸，你的价值不止这些。",
  "乾坤未定，你我皆是黑马；若真已定，黑马也能换赛道。",
];
function randomComfort() {
  return COMFORT_MESSAGES[Math.floor(Math.random() * COMFORT_MESSAGES.length)];
}

/* ---------------- Hero（首页首屏） ---------------- */
// 是否已解锁核心查询能力（升学会员/冲稳保/AI规划/老师复审均视为已解锁）
function hasUnlock(): boolean {
  try {
    const arr = JSON.parse(localStorage.getItem("ly_paid_plans") || "[]");
    if (!Array.isArray(arr)) return false;
    return arr.some(
      (e: any) =>
        e && ["upgrade_99", "match_29_9", "planning_199", "review_599"].includes(e.planId)
    );
  } catch {
    return false;
  }
}
// 付费墙总开关：true=拦截未付费用户弹 ¥99 墙；false=暂时关闭，所有人可免费生成（2026-07-19 临时关闭）
const PAYWALL_ENABLED = false;
// 读取上次填写的资料草稿（付费墙/表单复用，付完回首页自动恢复并出结果）
function readProfileDraft(): {
  score?: number;
  rank?: string;
  district?: string;
  juniorSchool?: string;
  directionalSchool?: string;
} {
  try {
    return JSON.parse(localStorage.getItem("ly_profile_draft") || "{}");
  } catch {
    return {};
  }
}

function Hero({ onGenerate }: { onGenerate: (score: string, district: string, school: string, rank: string, isDirectional: boolean, directionalSchool: string) => void }) {
  const router = useRouter();
  const _d0 = readProfileDraft();
  const [score, setScore] = useState(_d0.score != null ? String(_d0.score) : "");
  const [district, setDistrict] = useState(_d0.district || "");
  const [school, setSchool] = useState("");
  const [schoolInput, setSchoolInput] = useState("");
  const [rank, setRank] = useState("");
  const [rankEdited, setRankEdited] = useState(false);
  const [districtOpen, setDistrictOpen] = useState(false);
  const [schoolOpen, setSchoolOpen] = useState(false);
  const [isDirectional, setIsDirectional] = useState(false);
  const [directionalSchool, setDirectionalSchool] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogMsg, setDialogMsg] = useState("");
  // 付费墙：未付费用户点击「生成」时拦截并弹出升级套餐
  const [paywallOpen, setPaywallOpen] = useState(false);
  const [paywallErr, setPaywallErr] = useState("");

  // 高中分数/位次查询弹窗
  const [scoreQueryOpen, setScoreQueryOpen] = useState(false);
  const [queryDistrict, setQueryDistrict] = useState("yanta");
  const [querySchool, setQuerySchool] = useState<School | null>(null);
  const [headerSearchOpen, setHeaderSearchOpen] = useState(false);
  const [headerSearchQ, setHeaderSearchQ] = useState("");
  const searchBoxRef = useRef<HTMLDivElement>(null);

  const scoreValid = score.trim() !== "" && Number(score) >= 0;
  const canGenerate = scoreValid && district !== "";

  useEffect(() => {
    if (!score || rankEdited) return;
    const n = Number(score);
    if (!Number.isFinite(n)) return;
    const dataDistrict = DISTRICT_TO_DATA[district] || "chengliuqu";
    const { rank: est } = estimateRank(n, dataDistrict);
    setRank(String(est));
  }, [score, district, rankEdited]);

  // 点击弹窗外部时关闭头部搜索下拉
  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (searchBoxRef.current && !searchBoxRef.current.contains(e.target as Node)) {
        setHeaderSearchOpen(false);
      }
    }
    if (headerSearchOpen) {
      document.addEventListener("mousedown", onDoc);
      return () => document.removeEventListener("mousedown", onDoc);
    }
  }, [headerSearchOpen]);

  const headerSearchResults = useMemo(() => searchSchools(headerSearchQ), [headerSearchQ]);

  function pickDistrict(v: string) {
    setDistrict(v);
    setSchool(""); // 切换区县重置已选初中，避免跨区错配
    setSchoolInput("");
    setDistrictOpen(false);
  }
  function pickSchool(label: string) {
    setSchool(label);
    setSchoolInput(label);
    setSchoolOpen(false);
  }
  // 渲染期是否已解锁（用于按钮可点/文案）
  const unlocked = hasUnlock();
  // 付费墙是否处于拦截态（开关关闭时恒为 false）
  const paywallBlocked = PAYWALL_ENABLED && !unlocked;

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    // 付费墙（PAYWALL_ENABLED=true 时拦截未付费用户；当前已临时关闭）
    if (PAYWALL_ENABLED && !hasUnlock()) {
      setPaywallOpen(true);
      setPaywallErr("");
      return;
    }
    if (!canGenerate) return;
    const n = Number(score);
    if (Number.isFinite(n) && n < LOW_SCORE_THRESHOLD) {
      setDialogMsg(randomComfort());
      setDialogOpen(true);
      return;
    }
    onGenerate(score.trim(), district, school, rank, isDirectional, directionalSchool);
  }

  const schools = district ? schoolByDistrict[district] || [] : [];
  const filteredSchools = schools.filter((s) => s.toLowerCase().includes(schoolInput.trim().toLowerCase()));
  const dataDistrict = DISTRICT_TO_DATA[district] || "chengliuqu";
  const highSchools = district
    ? (schoolsData as unknown as Array<{ name: string; code: string; district: string; ownership?: "public" | "private" }>).filter((s) => s.district === dataDistrict).map((s) => ({ name: s.name, code: s.code, ownership: s.ownership }))
    : [];
  const districtLabel = (v: string) => districtList.find((d) => d.value === v)?.label || "";

  return (
    <section className="bg-[#f7f3ec]">
      <div className="mx-auto max-w-[1040px] px-6 pb-10 pt-5 text-center">
        <h1 className="mx-auto max-w-[820px] text-[1.625rem] font-bold leading-[1.35] tracking-[-0.02em] text-[#10233d] sm:text-[2.625rem]">
          <span className="block">苦哈哈的上了9年学，</span>
          <span className="block">
            <span>志愿填对</span>
            <span className="text-[#059669]">上清华</span>
            <span>，</span>
          </span>
          <span className="block">
            <span>填错了</span>
            <span className="text-[#9ca3af] line-through decoration-[#b94f38]">上螺丝</span>
          </span>
        </h1>
        <p className="mx-auto mt-6 max-w-[640px] text-[1.0625rem] leading-[1.7] text-[#4b5563]">
          查分免费获取匹配学校
        </p>

        <form onSubmit={handleSubmit} className="mx-auto mt-6 max-w-[640px] rounded-[20px] border border-[#ede8e0] bg-white/95 backdrop-blur-sm p-8 text-left shadow-[0_2px_24px_rgba(16,35,61,.06)]">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-medium text-[#4b5563]" htmlFor="hero-score">中考分数</label>
              <input
                id="hero-score"
                type="text"
                inputMode="decimal"
                value={score}
                onChange={(e) => setScore(clampScore(e.target.value))}
                placeholder="输入中考分数（如 520.5）"
                className="w-full rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-4 py-3 text-base text-[#10233d] outline-none transition focus:border-[#b94f38] focus:ring-4 focus:ring-[#b94f38]/10 placeholder:text-[#9ca3af]"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-[#4b5563]">所在区县</label>
              <div className="relative">
                {districtOpen && <div className="fixed inset-0 z-[55]" onClick={() => setDistrictOpen(false)} />}
                <button
                  type="button"
                  onClick={() => setDistrictOpen((o) => !o)}
                  className="relative z-50 flex w-full items-center justify-between rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-4 py-3 text-base outline-none transition focus:border-[#b94f38] focus:ring-4 focus:ring-[#b94f38]/10"
                >
                  <span className={(district ? "text-[#10233d]" : "text-[#9ca3af]") + " truncate"}>{district ? districtLabel(district) : "请选择所在区县"}</span>
                  <svg className={"shrink-0 transition-transform " + (districtOpen ? "rotate-180" : "")} width="12" height="8" viewBox="0 0 12 8" fill="none">
                    <path d="M1 1.5L6 6.5L11 1.5" stroke="#9CA3AF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                {districtOpen && (
                  <ul className="absolute left-0 right-0 z-[60] mt-1.5 max-h-72 overflow-y-auto rounded-xl border border-[#ede8e0] bg-white p-1.5 shadow-[0_12px_32px_rgba(16,35,61,.14)]">
                    {districtList.map((d) => (
                      <li
                        key={d.value}
                        onClick={() => pickDistrict(d.value)}
                        className={"flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2.5 text-[0.95rem] text-[#10233d] hover:bg-[#f3f4f6] " + (district === d.value ? "bg-[#fdf2ee] font-semibold text-[#b94f38]" : "")}
                      >
                        {d.special && <Star />}
                        <span className="flex-1">{d.label}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-[1.4fr_1fr]">
            <div>
              <label className="mb-2 block text-sm font-medium text-[#4b5563]">
                就读初中（定向生）<span className="ml-1 font-normal text-[#6b7280]">名额按初中分配，选了才准</span>
              </label>
              <div className="relative">
                {schoolOpen && <div className="fixed inset-0 z-[55]" onClick={() => setSchoolOpen(false)} />}
                <div
                  className="relative z-50 flex w-full items-center rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-1 outline-none transition focus-within:border-[#b94f38] focus-within:ring-4 focus-within:ring-[#b94f38]/10 disabled:cursor-not-allowed disabled:bg-[#f3f4f6]"
                >
                  <input
                    type="text"
                    value={schoolInput}
                    onChange={(e) => {
                      const v = e.target.value;
                      setSchoolInput(v);
                      setSchool(v); // 允许直接填写学校名称
                      setSchoolOpen(true);
                    }}
                    onFocus={() => setSchoolOpen(true)}
                    disabled={!district}
                    placeholder={district ? "请选择或输入就读初中（定向生）" : "请先选择所在区县"}
                    className="min-w-0 flex-1 bg-transparent px-3 py-3 text-base text-[#10233d] outline-none placeholder:text-[#9ca3af] disabled:bg-transparent"
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={() => setSchoolOpen((o) => !o)}
                    disabled={!district}
                    className="shrink-0 px-3 py-3 outline-none disabled:opacity-50"
                  >
                    <svg className={"transition-transform " + (schoolOpen ? "rotate-180" : "")} width="12" height="8" viewBox="0 0 12 8" fill="none">
                      <path d="M1 1.5L6 6.5L11 1.5" stroke="#9CA3AF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </button>
                </div>
                {schoolOpen && district && (
                  <ul className="absolute left-0 right-0 z-[60] mt-1.5 max-h-72 overflow-y-auto rounded-xl border border-[#ede8e0] bg-white p-1.5 shadow-[0_12px_32px_rgba(16,35,61,.14)]">
                    {specialDistricts.has(district) && (
                      <li className="px-3 pb-1 pt-2 text-xs font-semibold tracking-[0.02em] text-[#6b7280]">{districtLabel(district)}（特殊招生区域）</li>
                    )}
                    {filteredSchools.length === 0 ? (
                      <li className="px-3 py-2.5 text-sm text-[#9ca3af]">未找到匹配学校，将使用您输入的内容</li>
                    ) : (
                      filteredSchools.map((s) => (
                        <li
                          key={s}
                          onClick={() => pickSchool(s)}
                          className={"flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2.5 text-[0.95rem] text-[#10233d] hover:bg-[#f3f4f6] " + (school === s ? "bg-[#fdf2ee] font-semibold text-[#b94f38]" : "")}
                        >
                          {specialDistricts.has(district) && <Star />}
                          <span className="flex-1">{s}</span>
                        </li>
                      ))
                    )}
                  </ul>
                )}
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-[#4b5563]" htmlFor="hero-rank">中考位次</label>
              <input
                id="hero-rank"
                type="number"
                inputMode="numeric"
                min={1}
                value={rank}
                onChange={(e) => {
                  const v = e.target.value;
                  setRank(v);
                  setRankEdited(v !== "" && v !== "0");
                }}
                placeholder="留空将由系统根据区县自动估算位次"
                className="w-full rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-4 py-3 text-base text-[#10233d] outline-none transition focus:border-[#b94f38] focus:ring-4 focus:ring-[#b94f38]/10 placeholder:text-[#9ca3af]"
              />
              <p className="mt-1.5 text-xs leading-snug text-[#9ca3af]">
                位次按官方公布的 2026 考生人数估算（城六区 8.2 万 · 长安 2.4 万 · 西咸约 1.2 万）
              </p>
            </div>
          </div>

          {/* 是否选择定向生 + 定向学校（高中） */}
          <div className="mt-4">
            <label className="flex cursor-pointer items-center gap-2.5 text-sm font-medium text-[#4b5563]">
              <input
                type="checkbox"
                checked={isDirectional}
                onChange={(e) => {
                  setIsDirectional(e.target.checked);
                  if (!e.target.checked) setDirectionalSchool("");
                }}
                className="h-4 w-4 rounded border-[#cbb3aa] text-[#b94f38] accent-[#b94f38]"
              />
              是否选择定向生（走定向生名额录取）
            </label>
            {isDirectional && (
              <div className="mt-3">
                <label className="mb-2 block text-sm font-medium text-[#4b5563]">定向学校（高中）</label>
                <select
                  value={directionalSchool}
                  onChange={(e) => setDirectionalSchool(e.target.value)}
                  className="w-full rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-4 py-3 text-base outline-none focus:border-[#b94f38]"
                >
                  <option value="">请选择定向高中</option>
                  {highSchools.map((h) => (
                    <option key={h.code + h.name} value={h.name}>
                      {ownershipLabel(h.ownership)} {h.name}（{h.code}）
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={paywallBlocked ? false : !canGenerate}
            className={
              "mt-5 w-full rounded-[12px] bg-gradient-to-br from-[#b94f38] to-[#d4654a] px-8 py-4 text-base font-semibold tracking-[.02em] text-white shadow-[0_4px_14px_rgba(185,79,56,.25)] transition-all duration-200 hover:-translate-y-[2px] hover:shadow-[0_8px_20px_rgba(185,79,56,.32)] active:scale-[0.96] active:shadow-[0_2px_6px_rgba(185,79,56,.25)] " +
              ((paywallBlocked ? false : !canGenerate) ? "cursor-not-allowed from-[#cbb3aa] to-[#cbb3aa] shadow-none hover:translate-y-0 hover:shadow-none active:scale-100" : "")
            }
          >
            {paywallBlocked ? "查看志愿匹配 · ¥99 解锁" : "免费生成基础报告"}
          </button>

          <div className="mt-4 flex items-center justify-center gap-1.5 text-[0.8125rem] text-[#6b7280]">
            {paywallBlocked ? (
              <span>付费 ¥99 后即可填写分数与区县，查看为你匹配的学校</span>
            ) : (
              <>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><path d="M9 12l2 2 4-4" />
                </svg>
                免费生成 · 无需手机号 · 不会收到推销电话
              </>
            )}
          </div>
          <div className="mt-3 text-center text-xs text-[#9ca3af]">
            提交即代表同意我们的<Link href="/privacy" className="ml-0.5 underline transition hover:text-[#b94f38]">隐私政策</Link>
          </div>
        </form>

        <div className="mx-auto mt-5 flex max-w-[720px] flex-wrap items-center justify-center gap-3">
          <a
            href="https://222.91.162.190:7070/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-[#ede8e0] bg-white px-4 py-2.5 text-sm font-medium text-[#b94f38] shadow-sm hover:bg-[#fff7f2]"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
            中考查分
          </a>
          <span className="inline-flex items-center gap-2 rounded-full border border-[#ede8e0] bg-white px-4 py-2.5 text-sm font-medium text-[#4b5563] shadow-sm">
            <svg className="text-[#059669]" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5" /></svg>
            官方招生计划
          </span>
          <span className="inline-flex items-center gap-2 rounded-full border border-[#ede8e0] bg-white px-4 py-2.5 text-sm font-medium text-[#4b5563] shadow-sm">
            <svg className="text-[#059669]" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2 2 7l10 5 10-5-10-5z" /><path d="m2 17 10 5 10-5" /><path d="m2 12 10 5 10-5" /></svg>
            批次规则
          </span>
          <span className="inline-flex items-center gap-2 rounded-full border border-[#ede8e0] bg-white px-4 py-2.5 text-sm font-medium text-[#4b5563] shadow-sm">
            <svg className="text-[#2563eb]" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" /></svg>
            定向生计划
          </span>
          <button
            type="button"
            onClick={() => setScoreQueryOpen(true)}
            className="inline-flex items-center gap-2 rounded-full border border-[#ede8e0] bg-white px-4 py-2.5 text-sm font-medium text-[#b94f38] shadow-sm hover:bg-[#fff7f2]"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
            查询高中分数
          </button>
        </div>

        {/* 低分鼓励弹窗 */}
        {dialogOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-[#10233d]/40 backdrop-blur-sm" onClick={() => setDialogOpen(false)} />
            <div className="relative z-10 w-full max-w-[420px] overflow-hidden rounded-[24px] bg-white p-8 text-center shadow-[0_24px_60px_rgba(16,35,61,.2)]">
              <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full bg-[#fdf2ee] text-3xl">
                🛠️
              </div>
              <h3 className="text-xl font-bold text-[#10233d]">先别急着看志愿</h3>
              <p className="mt-3 text-base leading-relaxed text-[#4b5563]">
                {dialogMsg}
              </p>
              <div className="mt-6 text-sm text-[#9ca3af]">
                当前分数 <span className="font-bold text-[#b94f38]">{score}</span> 分，距高中录取线还有一段距离。
              </div>
              <button
                type="button"
                onClick={() => router.push("/vocational")}
                className="mt-6 w-full rounded-xl bg-[#b94f38] px-5 py-3 text-base font-bold text-white transition hover:bg-[#a23f29]"
              >
                去看看职高和职校
              </button>
              <button
                type="button"
                onClick={() => setDialogOpen(false)}
                className="mt-3 w-full rounded-xl border border-[#d1d5db] bg-white px-5 py-3 text-base font-semibold text-[#4b5563] transition hover:bg-[#f3f4f6]"
              >
                知道了，我再想想
              </button>
            </div>
          </div>
        )}

        {/* 高中分数/位次查询弹窗 */}
        {scoreQueryOpen && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <div
              className="absolute inset-0 bg-[#10233d]/40 backdrop-blur-sm"
              onClick={() => setScoreQueryOpen(false)}
            />
            <div className="relative z-10 w-full max-w-[460px] rounded-[24px] bg-white p-6 shadow-[0_24px_60px_rgba(16,35,61,.2)]">
              <div className="mb-5 flex items-center justify-between gap-3" ref={searchBoxRef}>
                {!headerSearchOpen ? (
                  <h3 className="text-lg font-bold text-[#10233d]">查询高中分数与位次</h3>
                ) : (
                  <div className="relative flex-1">
                    <div className="flex items-center gap-2 rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-3 py-2 focus-within:border-[#b94f38]">
                      <svg className="h-4 w-4 shrink-0 text-[#9ca3af]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></svg>
                      <input
                        autoFocus
                        value={headerSearchQ}
                        onChange={(e) => setHeaderSearchQ(e.target.value)}
                        placeholder="输入学校简称或全称"
                        className="min-w-0 flex-1 bg-transparent text-sm text-[#10233d] outline-none placeholder:text-[#9ca3af]"
                      />
                    </div>
                    {headerSearchResults.length > 0 && (
                      <div className="absolute left-0 right-0 top-full z-30 mt-1 max-h-60 overflow-auto rounded-xl border border-[#ede8e0] bg-white py-1 shadow-[0_12px_32px_rgba(16,35,61,.12)]">
                        {headerSearchResults.map((s) => (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => {
                              setQueryDistrict(DATA_TO_DISTRICT[s.district] || "yanta");
                              setQuerySchool(s);
                              setHeaderSearchOpen(false);
                              setHeaderSearchQ("");
                            }}
                            className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-xs hover:bg-[#f7f3ec]"
                          >
                            <span className="flex min-w-0 items-center gap-1.5">
                              <SchoolNameTag name={s.name} district={s.district} className="truncate" />
                              {!isVerifiedPlan(s) && (
                                <span className="shrink-0 rounded bg-[#f3f4f6] px-1.5 py-0.5 text-[10px] font-bold text-[#9ca3af]">待核验</span>
                              )}
                            </span>
                            <span className="shrink-0 font-mono text-[#9ca3af]">
                              {s.code || "—"} · {s.referenceScore > 0 ? `${s.referenceScore}分` : "暂无"}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                    {headerSearchQ && headerSearchResults.length === 0 && (
                      <div className="absolute left-0 right-0 top-full z-30 mt-1 rounded-xl border border-[#ede8e0] bg-white px-3 py-2 text-xs text-[#9ca3af] shadow-[0_12px_32px_rgba(16,35,61,.12)]">
                        未找到匹配学校
                      </div>
                    )}
                  </div>
                )}
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    aria-label={headerSearchOpen ? "关闭搜索" : "搜索学校"}
                    onClick={() => {
                      setHeaderSearchOpen((v) => !v);
                      if (headerSearchOpen) setHeaderSearchQ("");
                    }}
                    className={`rounded-full p-1 text-[#9ca3af] hover:bg-[#f3f4f6] hover:text-[#4b5563] ${headerSearchOpen ? "text-[#b94f38]" : ""}`}
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></svg>
                  </button>
                  <button
                    type="button"
                    aria-label="关闭"
                    onClick={() => setScoreQueryOpen(false)}
                    className="rounded-full p-1 text-[#9ca3af] hover:bg-[#f3f4f6] hover:text-[#4b5563]"
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>
                  </button>
                </div>
              </div>

              <div className="space-y-4 text-left">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-[#4b5563]">招生单元</label>
                  <select
                    value={queryDistrict}
                    onChange={(e) => {
                      setQueryDistrict(e.target.value);
                      setQuerySchool(null);
                    }}
                    className="w-full rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-4 py-3 text-base text-[#10233d] outline-none focus:border-[#b94f38]"
                  >
                    {districtList.map((d) => (
                      <option key={d.value} value={d.value}>
                        {d.label}
                      </option>
                    ))}
                  </select>
                  <p className="mt-1 text-xs text-[#9ca3af]">
                    城六区（新城/碑林/莲湖/雁塔/未央/灞桥）共享同一分数段位次表；长安、西咸为独立单元；五区二县（阎良/临潼/高陵/鄠邑/蓝田/周至）每个区县各自独立成单元。
                  </p>
                </div>

                <div>
                  <label className="mb-1.5 block text-sm font-medium text-[#4b5563]">高中学校</label>
                  <SchoolSelect
                    value={querySchool?.name || ""}
                    onInput={(v) => {
                      if (!v) setQuerySchool(null);
                    }}
                    onPick={(s) => setQuerySchool(s)}
                    dataDistrict={DISTRICT_TO_DATA[queryDistrict] || "chengliuqu"}
                  />
                </div>

                {querySchool && (
                  <div className="rounded-xl border border-[#ede8e0] bg-[#fdfbf8] p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <SchoolNameTag name={querySchool.name} district={querySchool.district} className="text-base font-bold text-[#10233d]" />
                        <div className="mt-1 text-xs text-[#6b7280]">
                          {ownershipLabel(querySchool.ownership)} · 代码 {querySchool.code || "—"}
                          {(() => {
                            const h = latestHistoricalLine(querySchool.cut);
                            return h ? <span className="ml-1">· 近年线 {h.year}年 {h.score}分（原满分制）</span> : null;
                          })()}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-black text-[#b94f38]">{querySchool.referenceScore > 0 ? querySchool.referenceScore : "—"}</div>
                        <div className="text-xs text-[#6b7280]">
                          {querySchool.referenceScore > 0
                            ? querySchool.est2026 != null
                              ? "2026预估分"
                              : querySchool.ref2026 != null
                                ? "2026折算参考分"
                                : "参考分/预估分"
                            : "暂无录取线"}
                        </div>
                      </div>
                    </div>
                    {querySchool.referenceScore > 0 ? (
                      (() => {
                        const r = estimateRank(querySchool.referenceScore, DISTRICT_TO_DATA[queryDistrict] || "chengliuqu");
                        return (
                          <div className="mt-3 grid grid-cols-2 gap-3 border-t border-[#ede8e0] pt-3 text-sm">
                            <div>
                              <div className="text-xs text-[#6b7280]">估算位次</div>
                              <div className="font-semibold text-[#10233d]">
                                约 {r.rank.toLocaleString()} / {r.total.toLocaleString()}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-[#6b7280]">百分位</div>
                              <div className="font-semibold text-[#10233d]">前 {r.percentile}%</div>
                            </div>
                            <div>
                              <div className="text-xs text-[#6b7280]">数据来源</div>
                              <div className="font-semibold text-[#10233d]">
                                {r.source === "band" ? "2026 官方一分一段" : r.source === "extrapolated" ? "表外外推" : "模型估算"}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-[#6b7280]">匹配精度</div>
                              <div className="font-semibold text-[#10233d]">
                                {r.exact ? "精准" : "估算"}
                              </div>
                            </div>
                          </div>
                        );
                      })()
                    ) : (
                      <p className="mt-3 border-t border-[#ede8e0] pt-3 text-xs text-[#9ca3af]">
                        该校近年录取线未收录，位次暂无法估算；请关注本区县官方公布的录取分数线。
                      </p>
                    )}
                  </div>
                )}

                {!querySchool && (
                  <p className="rounded-lg bg-[#f3f4f6] p-3 text-xs text-[#6b7280]">
                    选择招生单元后搜索学校，即可查看该校 2026 预估/参考分数线与对应位次。城六区 511–633 分使用官方一分一段表精确换算；五区二县暂无 2026 官方线，按近年线折算为 2026 参考分并模型估算位次，待官方公布后以官方为准。
                  </p>
                )}
              </div>

              <button
                type="button"
                onClick={() => setScoreQueryOpen(false)}
                className="mt-5 w-full rounded-xl bg-[#b94f38] px-5 py-3 text-base font-bold text-white transition hover:bg-[#a23f29]"
              >
                关闭
              </button>
            </div>
          </div>
        )}

        {/* 付费墙：未付费用户点击「生成」时弹出 ¥99 升级套餐 */}
        {paywallOpen && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-[#10233d]/50 backdrop-blur-sm" onClick={() => setPaywallOpen(false)} />
            <div className="relative z-10 w-full max-w-[440px] overflow-hidden rounded-[24px] bg-white p-7 shadow-[0_24px_60px_rgba(16,35,61,.25)]">
              <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-full bg-[#fff7f2] text-3xl">🔓</div>
              <h3 className="text-center text-xl font-bold text-[#10233d]">解锁参考学校推荐</h3>
              <p className="mt-3 rounded-xl bg-[#f7f3ec] p-4 text-[0.95rem] leading-relaxed text-[#4b5563]">
                由于免费用户太多，付费的用户太少，开发费用太大，所以只对付费用户开放使用。
              </p>
              <ul className="mt-4 space-y-2 text-sm text-[#4b5563]">
                {[
                  "精准匹配你分数段的参考学校",
                  "生成冲刺 / 稳妥 / 保底志愿方案",
                  "位次、升学概率与风险分析",
                ].map((t) => (
                  <li key={t} className="flex items-center gap-2">
                    <svg className="shrink-0 text-[#059669]" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5" /></svg>
                    {t}
                  </li>
                ))}
              </ul>
              <div className="mt-4 space-y-2">
                <input
                  value={score}
                  onChange={(e) => setScore(clampScore(e.target.value))}
                  inputMode="numeric"
                  placeholder="输入中考分数"
                  className="w-full rounded-xl border border-[#e5e7eb] bg-white px-3.5 py-2.5 text-sm text-[#10233d] outline-none focus:border-[#b94f38]"
                />
                <select
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full rounded-xl border border-[#e5e7eb] bg-white px-3.5 py-2.5 text-sm text-[#10233d] outline-none focus:border-[#b94f38]"
                >
                  <option value="">选择所在区县</option>
                  {districtList.map((d) => (
                    <option key={d.value} value={d.value}>{d.label}</option>
                  ))}
                </select>
              </div>
              {paywallErr && (
                <p className="mt-2 text-center text-xs text-[#dc2626]">{paywallErr}</p>
              )}
              <div className="mt-5 flex items-baseline justify-center gap-1.5">
                <span className="text-sm text-[#6b7280]">升级套餐</span>
                <span className="text-3xl font-black text-[#b94f38]">¥99</span>
                <span className="text-xs text-[#9ca3af]">一次解锁，长期可用</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (!score.trim() || !district) {
                    setPaywallErr("请先填写中考分数和所在区县");
                    return;
                  }
                  try {
                    localStorage.setItem(
                      "ly_profile_draft",
                      JSON.stringify({
                        score: Number(score) || 0,
                        rank,
                        district,
                        juniorSchool: school,
                        directionalSchool: directionalSchool || undefined,
                      })
                    );
                  } catch {}
                  setPaywallOpen(false);
                  window.location.href = "/checkout?plan=upgrade_99";
                }}
                className="mt-5 w-full rounded-xl bg-gradient-to-br from-[#b94f38] to-[#d4654a] px-5 py-3.5 text-base font-bold text-white shadow-[0_4px_14px_rgba(185,79,56,.25)] transition-all duration-200 hover:-translate-y-[2px] hover:shadow-[0_8px_20px_rgba(185,79,56,.32)] active:scale-[0.96]"
              >
                立即支付 ¥99 解锁
              </button>
              <button
                type="button"
                onClick={() => setPaywallOpen(false)}
                className="mt-3 w-full rounded-xl border border-[#d1d5db] bg-white px-5 py-3 text-base font-semibold text-[#4b5563] transition hover:bg-[#f3f4f6]"
              >
                暂不开通
              </button>
              <p className="mt-3 text-center text-xs text-[#9ca3af]">支持微信 / 支付宝 · 支付后立即可用</p>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}

/* ---------------- 主页 ---------------- */

export default function Home() {
  const _d0 = readProfileDraft();
  const [score, setScore] = useState(_d0.score != null ? String(_d0.score) : ""); // 初始为空或从草稿恢复
  const [district, setDistrict] = useState(_d0.district || "");
  const [middleSchool, setMiddleSchool] = useState("");
  const [directionalSchool, setDirectionalSchool] = useState("");
  const [rank, setRank] = useState("");
  const [strategy, setStrategy] = useState("");
  const [stage, setStage] = useState<Stage>("input");
  const [revealed, setRevealed] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogMsg, setDialogMsg] = useState("");
  const [reportOpen, setReportOpen] = useState(false);
  const workbenchRef = useRef<HTMLElement>(null);

  // 邀请关系：捕获 ?ref（分享链接带来），生成本次会话编号；好友完成查分后才上报有效转化
  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    const ref = params.get("ref");
    if (ref) sessionStorage.setItem("ly_ref", ref);
    if (!sessionStorage.getItem("ly_friend_session")) {
      sessionStorage.setItem("ly_friend_session", "fs-" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36));
    }
  }, []);

  // 好友完成查分后的有效转化上报（仅一次；不允许自己邀请自己）
  function reportReferral(s?: string, d?: string) {
    if (typeof window === "undefined") return;
    const ref = sessionStorage.getItem("ly_ref");
    if (!ref) return;
    const myRef = typeof localStorage !== "undefined" ? localStorage.getItem("ly_share_id") : null;
    if (ref === myRef) return; // 自己点自己的链接不算
    if (sessionStorage.getItem("ly_ref_converted") === "1") return;
    const friendSessionId = sessionStorage.getItem("ly_friend_session") || "";
    const scoreNum = Number(s != null ? s : score) || 0;
    const districtVal = d != null ? d : district;
    sessionStorage.setItem("ly_ref_converted", "1");
    fetch("/api/referrals/convert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ref, friendSessionId, score: scoreNum, district: districtVal }),
    })
      .then(async (res) => {
        if (!res.ok) return;
        const data = await res.json();
        if (data.valid && typeof window !== "undefined") {
          // 仅用于调试可见性，不影响计数逻辑
          (window as any).__lastReferral = data;
        }
      })
      .catch(() => {});
  }

  // 免费报告生成时写入 profile lock（使 /downloads 可访问免费报告，不覆盖已付费锁）
  useEffect(() => {
    if (!reportOpen || !score || !district) return;
    const existing = getProfileLock();
    if (existing && existing.packageId !== "free") return; // 不覆盖付费锁
    saveProfileLock({
      score: Number(score) || 0,
      rank,
      district,
      juniorSchool: middleSchool,
      directionalSchool: directionalSchool || undefined,
      packageId: "free",
      lockedAt: new Date().toISOString(),
    });
  }, [reportOpen, score, district, rank, middleSchool, directionalSchool]);

  // Hero 提交 → 带数据揭示下方三栏工作台
  function handleGenerate(s: string, d: string, sch: string, r: string, isDir: boolean, dirSchool: string) {
    setScore(s);
    setDistrict(d);
    setMiddleSchool(sch);
    setRank(r);
    setDirectionalSchool(dirSchool || "");
    setStage("report");
    setRevealed(true);
    // 持久化资料草稿，供结算确认页核对并锁定（支付后写入 ly_profile_locked）
    if (typeof window !== "undefined") {
      localStorage.setItem(
        "ly_profile_draft",
        JSON.stringify({
          score: Number(s) || 0,
          rank: r,
          district: d,
          juniorSchool: sch,
          directionalSchool: dirSchool || undefined,
        })
      );
    }
    reportReferral(s, d);
  }

  useEffect(() => {
    if (revealed && workbenchRef.current) {
      workbenchRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [revealed]);

  // 已付费且已有分数/区县：自动展开结果，无需再点按钮（付完回首页即出）
  useEffect(() => {
    if (hasUnlock() && score && district && !revealed) {
      setRevealed(true);
    }
  }, [score, district, revealed]);

  function openPlan(id: string) {
    track("plan_selected", { planId: id, score: Number(score), district, middleSchool, rank: Number(rank) || undefined });
    window.location.href = "/checkout?plan=" + id;
  }

  function stepStatus(id: number): "done" | "current" | "upcoming" {
    if (stage === "input") return id === 1 ? "current" : "upcoming";
    if (stage === "report") {
      if (id <= 2) return "done";
      return id === 3 ? "current" : "upcoming";
    }
    return id <= 3 ? "done" : "current";
  }

  return (
    <main className="min-h-screen bg-[#f7f3ec] text-[#10233d]">
      {/* 轻量返回长安成长地图入口（成长地图家庭档案不会恢复，属预期隐私行为） */}
      <div className="mx-auto max-w-[1040px] px-6 pt-4">
        <Link
          href="/growth"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-[#4b5563] transition hover:text-[#b94f38]"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
          返回长安成长地图
        </Link>
        <span className="ml-2 text-xs text-[#9ca3af]">返回后成长地图的家庭档案不会恢复，这是预期隐私行为。</span>
      </div>

      <div id="top">
        <Hero onGenerate={handleGenerate} />
      </div>

      {/* 工作台：默认隐藏，Hero 提交后展开 */}
      <section
        ref={workbenchRef}
        id="workbench"
        className={revealed ? "mx-auto max-w-6xl px-5 pb-10 pt-1 lg:px-8" : "hidden"}
      >
        {revealed && Number(score) > 0 && district && (
          <div id="free-schools">
            <FreeSchoolsRecommendation score={Number(score)} district={district} />
          </div>
        )}

        <PackageWorkbench
          score={score}
          rank={rank}
          district={district}
          districtLabel={district ? districtList.find((d) => d.value === district)?.label || "待选择" : "待选择"}
          middleSchool={middleSchool}
          strategy={strategy}
          stepStatus={stepStatus}
          onFree={() => setReportOpen(true)}
          onPlan={openPlan}
        />
      </section>

      <ReportModal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        score={Number(score) || 0}
        district={district}
        middleSchool={middleSchool}
        rank={rank}
        directionalSchool={directionalSchool}
      />

      {/* 低分鼓励弹窗（工作台） */}
      {dialogOpen && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-[#10233d]/40 backdrop-blur-sm" onClick={() => setDialogOpen(false)} />
          <div className="relative z-10 w-full max-w-[420px] overflow-hidden rounded-[24px] bg-white p-8 text-center shadow-[0_24px_60px_rgba(16,35,61,.2)]">
            <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full bg-[#fdf2ee] text-3xl">🛠️</div>
            <h3 className="text-xl font-bold text-[#10233d]">先别急着看志愿</h3>
            <p className="mt-3 text-base leading-relaxed text-[#4b5563]">{dialogMsg}</p>
            <div className="mt-6 text-sm text-[#9ca3af]">
              当前分数 <span className="font-bold text-[#b94f38]">{score}</span> 分，距高中录取线还有一段距离。
            </div>
            <div className="mt-6 flex flex-col gap-3">
              <button
                type="button"
                onClick={() => {
                  setDialogOpen(false);
                  router.push("/vocational");
                }}
                className="w-full rounded-xl bg-[#b94f38] px-5 py-3 text-base font-bold text-white transition hover:bg-[#9c3f2b]"
              >
                去看看职高和职校
              </button>
              <button
                type="button"
                onClick={() => setDialogOpen(false)}
                className="w-full rounded-xl border border-[#d1d5db] px-5 py-3 text-base font-bold text-[#4b5563] transition hover:bg-[#f3f4f6]"
              >
                知道了，我再想想
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

// 动态玩偶 + 气泡：「分享同学，拿抵扣券。」
// 进入 Step 04 时自动出现一次；用户关闭后，本次访问（sessionStorage）不再重复出现。
function ShareMascot() {
  const [closed, setClosed] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem("ly_mascot_closed") === "1") setClosed(true);
  }, []);

  if (closed) return null;

  function dismiss() {
    setClosed(true);
    if (typeof window !== "undefined") sessionStorage.setItem("ly_mascot_closed", "1");
  }

  return (
    <div className="relative my-4 flex flex-col items-center justify-center sm:flex-row sm:gap-3">
      <button
        type="button"
        onClick={dismiss}
        aria-label="关闭"
        className="absolute right-0 top-0 z-20 grid h-7 w-7 place-items-center rounded-full bg-white/15 text-base text-white/80 transition hover:bg-white/25"
      >
        ×
      </button>
      <div className="relative z-10 mb-2 animate-bounce rounded-2xl border border-white/15 bg-white px-5 py-2.5 shadow-md sm:mb-0">
        <span className="text-sm font-bold text-[#b94f38]">分享同学，拿抵扣券。</span>
        <span className="absolute -bottom-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rotate-45 border-b border-r border-white/15 bg-white" />
      </div>
      <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-[#f3c766] to-[#d4a574] text-3xl shadow-lg ring-4 ring-white">
        🧸
      </div>
    </div>
  );
}


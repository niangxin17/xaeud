"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { VOCATIONAL_SCHOOLS, VOCATIONAL_DISTRICTS, PATHS, type VocationalType } from "../lib/vocational-data";

const typeOptions: { value: VocationalType | "all"; label: string }[] = [
  { value: "all", label: "全部类型" },
  { value: "综合高中班", label: "综合高中班" },
  { value: "职高", label: "职高" },
  { value: "中专", label: "中专" },
  { value: "技校", label: "技校" },
];
const natureOptions = [
  { value: "all", label: "全部性质" },
  { value: "公办", label: "公办" },
  { value: "民办", label: "民办" },
];

function Badge({ children, color = "blue" }: { children: React.ReactNode; color?: "blue" | "orange" | "green" | "purple" }) {
  const map = {
    blue: "bg-[#eef4ff] text-[#2563eb]",
    orange: "bg-[#fdf2ee] text-[#b94f38]",
    green: "bg-[#ecfdf5] text-[#059669]",
    purple: "bg-[#f3e8ff] text-[#7c3aed]",
  };
  return <span className={"inline-flex rounded-full px-2.5 py-1 text-xs font-semibold " + map[color]}>{children}</span>;
}

function StatCard({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-2xl border border-[#ede8e0] bg-white p-5 text-center shadow-sm">
      <div className="text-2xl font-black text-[#10233d]">{value}</div>
      <div className="mt-1 text-sm text-[#6b7280]">{label}</div>
    </div>
  );
}

function SchoolCard({ school }: { school: (typeof VOCATIONAL_SCHOOLS)[0] }) {
  const [expanded, setExpanded] = useState(false);
  const typeColor = school.type === "综合高中班" ? "purple" : school.type === "技校" ? "orange" : school.type === "中专" ? "blue" : "green";
  return (
    <div className="rounded-2xl border border-[#ede8e0] bg-white p-5 shadow-sm transition hover:shadow-md">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-bold text-[#10233d]">{school.name}</h3>
          <div className="mt-2 flex flex-wrap gap-2">
            <Badge color={school.nature === "公办" ? "blue" : "orange"}>{school.nature}</Badge>
            <Badge color={typeColor}>{school.type}</Badge>
            <Badge color="green">{school.district}</Badge>
          </div>
        </div>
        <div className="text-right">
          <div className="text-xl font-black text-[#b94f38]">{school.plan}</div>
          <div className="text-xs text-[#9ca3af]">计划</div>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {school.majors.map((m) => (
          <span key={m} className="rounded-lg bg-[#f7f3ec] px-2.5 py-1 text-xs font-medium text-[#4b5563]">
            {m}
          </span>
        ))}
      </div>

      {(school.address || school.phone) && (
        <div className="mt-3 space-y-1 border-t border-dashed border-[#ece5da] pt-3 text-sm text-[#4b5563]">
          {school.address && (
            <div className="flex items-start gap-1.5">
              <span className="mt-0.5 shrink-0 text-[#b94f38]">📍</span>
              <span>{school.address}</span>
            </div>
          )}
          {school.phone && (
            <div className="flex items-center gap-1.5">
              <span className="shrink-0 text-[#b94f38]">📞</span>
              <a href={`tel:${school.phone.replace(/[^0-9]/g, "")}`} className="font-medium text-[#10233d] hover:underline">
                {school.phone}
              </a>
            </div>
          )}
        </div>
      )}

      <button
        type="button"
        onClick={() => setExpanded((e) => !e)}
        className="mt-4 w-full rounded-xl border border-[#ede8e0] bg-[#fdfbf8] py-2 text-sm font-semibold text-[#4b5563] transition hover:bg-[#f3f4f6]"
      >
        {expanded ? "收起详情" : "查看招生亮点与录取方式"}
      </button>

      {expanded && (
        <div className="mt-4 space-y-3 rounded-xl bg-[#f7f3ec] p-4 text-sm">
          <div>
            <span className="font-semibold text-[#10233d]">招生亮点：</span>
            <ul className="mt-1 list-disc pl-4 text-[#4b5563]">
              {school.highlights.map((h, i) => (
                <li key={i}>{h}</li>
              ))}
            </ul>
          </div>
          <div>
            <span className="font-semibold text-[#10233d]">录取方式：</span>
            <p className="mt-1 text-[#4b5563]">{school.admission}</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default function VocationalPage() {
  const [type, setType] = useState<VocationalType | "all">("all");
  const [nature, setNature] = useState<"all" | "公办" | "民办">("all");
  const [district, setDistrict] = useState("all");
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    return VOCATIONAL_SCHOOLS.filter((s) => {
      if (type !== "all" && s.type !== type) return false;
      if (nature !== "all" && s.nature !== nature) return false;
      if (district !== "all" && s.district !== district) return false;
      if (search.trim() && !s.name.includes(search.trim())) return false;
      return true;
    });
  }, [type, nature, district, search]);

  const totalPlan = useMemo(() => filtered.reduce((sum, s) => sum + s.plan, 0), [filtered]);
  const comprehensiveCount = VOCATIONAL_SCHOOLS.filter((s) => s.type === "综合高中班").length;

  return (
    <main className="min-h-screen bg-[#f7f3ec]">
      {/* Hero */}
      <section className="bg-[#10233d] px-5 py-12 text-white">
        <div className="mx-auto max-w-[1080px]">
          <Link href="/" className="inline-flex items-center gap-2 text-sm text-white/70 transition hover:text-white">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
            返回首页
          </Link>
          <h1 className="mt-6 text-3xl font-black tracking-tight sm:text-4xl">
            分数不是终点，选对赛道照样能升学
          </h1>
          <p className="mt-4 max-w-2xl text-lg leading-relaxed text-white/80">
            如果当前分数距离普通高中录取线还有一段距离，职业教育、综合高中班同样是正规升学路径。这里整理了西安 2026 年具有招生资格的中职、技工和综合高中班学校，帮你快速找到适合孩子的出路。
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="px-5 py-8">
        <div className="mx-auto grid max-w-[1080px] grid-cols-2 gap-4 sm:grid-cols-4">
          <StatCard value={String(VOCATIONAL_SCHOOLS.length)} label="收录学校" />
          <StatCard value={String(VOCATIONAL_SCHOOLS.filter((s) => s.type === "综合高中班").length)} label="综合高中班" />
          <StatCard value={String(totalPlan)} label="当前筛选计划数" />
          <StatCard value={String(VOCATIONAL_SCHOOLS.filter((s) => s.nature === "公办").length)} label="公办学校" />
        </div>
      </section>

      {/* 4 paths */}
      <section className="px-5 py-8">
        <div className="mx-auto max-w-[1080px]">
          <h2 className="text-2xl font-black text-[#10233d]">中职毕业后的 4 条出路</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {PATHS.map((p) => (
              <div key={p.title} className="rounded-2xl border border-[#ede8e0] bg-white p-5 shadow-sm">
                <div className="text-3xl">{p.icon}</div>
                <h3 className="mt-3 text-lg font-bold text-[#10233d]">{p.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-[#4b5563]">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 综合高中班重点说明 */}
      <section className="px-5 py-8">
        <div className="mx-auto max-w-[1080px] rounded-2xl border border-[#ede8e0] bg-white p-6 shadow-sm sm:p-8">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-start">
            <div className="text-4xl">🎓</div>
            <div>
              <h2 className="text-xl font-black text-[#10233d]">什么是「综合高中班」？</h2>
              <p className="mt-3 leading-relaxed text-[#4b5563]">
                综合高中班是低分段考生最接近普通高中的选择。学生注册<strong>普通高中学籍</strong>，高一学习普通高中课程；高一结束后根据学业成绩和意愿，可选择继续走普通高考方向，或转为中职学籍走职教高考/高职单招方向。适合分数在普高线附近、仍希望保留高考可能性的家庭重点关注。
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Badge color="purple">普通高中学籍</Badge>
                <Badge color="blue">可参加普通高考</Badge>
                <Badge color="green">高一后分流</Badge>
                <Badge color="orange">{comprehensiveCount} 所试点校</Badge>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters + Schools */}
      <section className="px-5 pb-16 pt-4">
        <div className="mx-auto max-w-[1080px]">
          <h2 className="text-2xl font-black text-[#10233d]">学校名录</h2>

          <div className="mt-5 grid gap-3 rounded-2xl border border-[#ede8e0] bg-white p-4 shadow-sm sm:grid-cols-4">
            <select
              value={type}
              onChange={(e) => setType(e.target.value as VocationalType | "all")}
              className="rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-3 py-2.5 text-sm outline-none focus:border-[#b94f38]"
            >
              {typeOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
            <select
              value={nature}
              onChange={(e) => setNature(e.target.value as "all" | "公办" | "民办")}
              className="rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-3 py-2.5 text-sm outline-none focus:border-[#b94f38]"
            >
              {natureOptions.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
            <select
              value={district}
              onChange={(e) => setDistrict(e.target.value)}
              className="rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-3 py-2.5 text-sm outline-none focus:border-[#b94f38]"
            >
              <option value="all">全部区县</option>
              {VOCATIONAL_DISTRICTS.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="搜索学校名称"
              className="rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-3 py-2.5 text-sm outline-none focus:border-[#b94f38]"
            />
          </div>

          <div className="mt-4 text-sm text-[#6b7280]">
            共找到 <strong className="text-[#10233d]">{filtered.length}</strong> 所学校，招生计划合计 <strong className="text-[#10233d]">{totalPlan}</strong> 人
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((s) => (
              <SchoolCard key={s.name} school={s} />
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="mt-12 rounded-2xl border border-[#ede8e0] bg-white p-10 text-center">
              <div className="text-4xl">🔍</div>
              <p className="mt-3 text-[#6b7280]">没有符合条件的学校，试试调整筛选条件</p>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}

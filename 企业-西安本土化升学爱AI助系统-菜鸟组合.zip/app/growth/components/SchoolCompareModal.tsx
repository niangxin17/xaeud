"use client";

import { useEffect, useMemo, useRef } from "react";
import type { GrowthSchool } from "../../lib/growth-schools";
import { buildCompareRows, MAX_COMPARE } from "../../lib/school-compare";

// 学校对比弹窗。
// 布局策略：
//  - 手机端（默认）按「维度」纵向分组，每个维度一张卡片，卡片内逐校纵向列出，长文本自动换行；
//  - 桌面端（md 及以上）用表格横向对齐，维度列 sticky 固定，表格容器可横向滚动；
// 两种布局都不使用任何截断样式，确保内容始终可完整查看。
export default function SchoolCompareModal({
  schools,
  open,
  onClose,
  onRemove,
}: {
  schools: GrowthSchool[];
  open: boolean;
  onClose: () => void;
  onRemove: (id: string) => void;
}) {
  const closeBtnRef = useRef<HTMLButtonElement | null>(null);
  const prevFocusRef = useRef<HTMLElement | null>(null);

  const rows = useMemo(() => buildCompareRows(schools), [schools]);

  // 滚动锁定 + 焦点管理
  useEffect(() => {
    if (!open) return;
    prevFocusRef.current = document.activeElement as HTMLElement | null;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeBtnRef.current?.focus();
    return () => {
      document.body.style.overflow = prevOverflow;
      prevFocusRef.current?.focus?.();
    };
  }, [open]);

  // Escape 关闭
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open || schools.length === 0) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-0 sm:items-center sm:p-4"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="flex max-h-[94vh] w-full flex-col rounded-t-2xl bg-white shadow-xl md:max-w-5xl md:rounded-2xl"
        role="dialog"
        aria-modal="true"
        aria-labelledby="school-compare-title"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 头部 */}
        <header className="flex items-start justify-between gap-3 border-b border-[#ede8e0] px-5 py-4">
          <div className="min-w-0">
            <h2
              id="school-compare-title"
              className="text-lg font-bold text-[#10233d]"
            >
              学校对比
            </h2>
            <p className="mt-1 text-xs text-[#6b7280]">
              当前对比 {schools.length} 所（最多 {MAX_COMPARE} 所）。所有字段按采集口径原样呈现，缺失显示「暂未核实」。
            </p>
          </div>
          <button
            ref={closeBtnRef}
            type="button"
            onClick={onClose}
            className="shrink-0 rounded-lg px-3 py-1.5 text-sm font-semibold text-[#6b7280] hover:bg-[#f3f4f6]"
            aria-label="关闭对比"
          >
            ✕
          </button>
        </header>

        {/* 内容区：纵向可滚动，任何超长内容都能查看 */}
        <div className="overflow-y-auto px-4 py-4 md:px-5">
          {/* ===== 手机端：按维度纵向分组 ===== */}
          <div className="md:hidden">
            <ul className="mb-4 flex flex-wrap gap-2">
              {schools.map((s, i) => (
                <li
                  key={s.id}
                  className="inline-flex items-center gap-1 rounded-full border border-[#f0d9cc] bg-[#fdf2ee] py-1 pl-3 pr-1 text-xs text-[#10233d]"
                >
                  <span className="break-words">
                    {i + 1}. {s.name}
                  </span>
                  <button
                    type="button"
                    onClick={() => onRemove(s.id)}
                    aria-label={`将 ${s.name} 移出对比`}
                    className="rounded-full px-1.5 py-0.5 text-[#b94f38] hover:bg-[#f6e2da]"
                  >
                    ✕
                  </button>
                </li>
              ))}
            </ul>

            <div className="space-y-3">
              {rows.map((row) => (
                <section
                  key={row.key}
                  className="rounded-xl border border-[#ede8e0] bg-[#faf8f4] p-3"
                >
                  <h3 className="mb-2 text-xs font-semibold tracking-wide text-[#b94f38]">
                    {row.label}
                  </h3>
                  <dl className="space-y-2">
                    {row.cells.map((cell, i) => (
                      <div
                        key={cell.schoolId}
                        className="rounded-lg bg-white px-3 py-2"
                      >
                        <dt className="text-[11px] break-words whitespace-normal text-[#9ca3af]">
                          {i + 1}. {schools[i]?.name}
                        </dt>
                        <dd className="mt-0.5 text-sm leading-6 break-words whitespace-normal text-[#4b5563]">
                          {cell.text}
                        </dd>
                      </div>
                    ))}
                  </dl>
                </section>
              ))}
            </div>
          </div>

          {/* ===== 桌面端：横向表格，维度列固定，可横向滚动 ===== */}
          <div className="hidden md:block">
            <div className="overflow-x-auto rounded-xl border border-[#ede8e0]">
              <table className="w-full min-w-[40rem] border-collapse text-left align-top">
                <caption className="sr-only">
                  已选学校在各对比维度上的信息，缺失字段显示暂未核实
                </caption>
                <thead>
                  <tr className="bg-[#faf8f4]">
                    <th
                      scope="col"
                      className="sticky left-0 z-10 w-32 border-b border-[#ede8e0] bg-[#faf8f4] px-3 py-3 text-xs font-semibold text-[#9ca3af]"
                    >
                      对比维度
                    </th>
                    {schools.map((s) => (
                      <th
                        key={s.id}
                        scope="col"
                        className="min-w-[12rem] border-b border-l border-[#ede8e0] px-3 py-3 align-top"
                      >
                        <span className="block text-sm font-bold break-words whitespace-normal text-[#10233d]">
                          {s.name}
                        </span>
                        <span className="mt-1 flex items-center gap-2">
                          {s.isDemo ? (
                            <span className="rounded-full bg-[#f3f4f6] px-2 py-0.5 text-[10px] font-semibold text-[#9ca3af]">
                              演示数据
                            </span>
                          ) : null}
                          <button
                            type="button"
                            onClick={() => onRemove(s.id)}
                            className="text-[11px] font-semibold text-[#b94f38] underline underline-offset-2"
                          >
                            移出
                          </button>
                        </span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, ri) => (
                    <tr
                      key={row.key}
                      className={ri % 2 === 1 ? "bg-[#fcfbf8]" : "bg-white"}
                    >
                      <th
                        scope="row"
                        className={`sticky left-0 z-10 border-b border-[#f1efe9] px-3 py-3 text-xs font-semibold text-[#6b7280] ${
                          ri % 2 === 1 ? "bg-[#fcfbf8]" : "bg-white"
                        }`}
                      >
                        {row.label}
                      </th>
                      {row.cells.map((cell) => (
                        <td
                          key={cell.schoolId}
                          className="border-b border-l border-[#f1efe9] px-3 py-3 text-sm leading-6 break-words whitespace-normal text-[#4b5563]"
                        >
                          {cell.text}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* 固定声明（原文，不得改写） */}
        <footer className="border-t border-[#ede8e0] bg-[#faf8f4] px-5 py-3 text-xs leading-5 text-[#9ca3af]">
          对比结果仅用于整理公开信息，不代表学校排名或录取建议。
        </footer>
      </div>
    </div>
  );
}

import type { GrowthSchool } from "../../lib/growth-schools";
import {
  formatEmpty,
  formatVerification,
  formatAdmissionLine,
  isSeniorSchool,
  STAGE_LABELS,
  OWNERSHIP_LABELS,
} from "../../lib/growth-schools";
import { MAX_COMPARE } from "../../lib/school-compare";

// 可信度标签样式：UNVERIFIED 使用中性灰色；A/B/C/D 采用柔和陶土色，不暗示「已认证真实」。
function verificationStyle(level: GrowthSchool["verificationLevel"]): string {
  if (level === "UNVERIFIED") {
    return "bg-[#f3f4f6] text-[#6b7280] border border-[#e5e7eb]";
  }
  return "bg-[#fbf3e7] text-[#b94f38] border border-[#f0d9cc]";
}

export default function SchoolCard({
  school,
  onViewDetails,
  inCompare,
  compareFull,
  onToggleCompare,
}: {
  school: GrowthSchool;
  onViewDetails: (s: GrowthSchool) => void;
  // 该校是否已在对比列表中
  inCompare: boolean;
  // 对比列表是否已达上限（用于隐藏加入入口）
  compareFull: boolean;
  onToggleCompare: (s: GrowthSchool) => void;
}) {
  return (
    <article className="flex flex-col rounded-2xl border border-[#ede8e0] bg-white p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-bold text-[#10233d]">{school.name}</h3>
          <p className="mt-1 text-xs text-[#6b7280]">
            {STAGE_LABELS[school.stage]} · {formatEmpty(school.district)} ·{" "}
            {OWNERSHIP_LABELS[school.ownership]}
          </p>
        </div>
        {school.isDemo ? (
          <span className="shrink-0 rounded-full bg-[#f3f4f6] px-2.5 py-0.5 text-[11px] font-semibold text-[#9ca3af]">
            演示数据
          </span>
        ) : null}
      </div>

      {/* 精简字段：仅保留名称、学段/区域/性质、招生范围状态、可信等级、来源日期；
          学费/餐食/课程特色等「暂未核实」字段统一移至详情弹窗（SchoolDetailModal）。 */}
      <dl className="mt-4 space-y-2 text-sm">
        {isSeniorSchool(school) ? (
          <div className="flex gap-2">
            <dt className="w-20 shrink-0 text-[#9ca3af]">2026录取线</dt>
            <dd className="text-[#4b5563]">{formatAdmissionLine(school)}</dd>
          </div>
        ) : (
          <div className="flex gap-2">
            <dt className="w-20 shrink-0 text-[#9ca3af]">招生范围</dt>
            <dd className="text-[#4b5563]">{formatEmpty(school.enrollmentScope)}</dd>
          </div>
        )}
        <div className="flex gap-2">
          <dt className="w-20 shrink-0 text-[#9ca3af]">可信等级</dt>
          <dd>
            <span
              className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${verificationStyle(
                school.verificationLevel,
              )}`}
            >
              {formatVerification(school.verificationLevel)}
            </span>
          </dd>
        </div>
        <div className="flex gap-2">
          <dt className="w-20 shrink-0 text-[#9ca3af]">来源日期</dt>
          <dd className="text-[#4b5563]">{formatEmpty(school.sourceUpdatedAt)}</dd>
        </div>
      </dl>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#f1efe9] pt-3">
        <span className="text-[11px] text-[#9ca3af]">资料以官方来源为准</span>
        <div className="flex items-center gap-2">
          {/* 对比入口：已加入可移出；未加入且已达上限时不再提供加入按钮，仅显示提示 */}
          {inCompare ? (
            <button
              type="button"
              onClick={() => onToggleCompare(school)}
              className="rounded-lg border border-[#b94f38] px-3 py-1.5 text-xs font-semibold text-[#b94f38] hover:bg-[#fdf2ee]"
            >
              移出对比
            </button>
          ) : compareFull ? (
            <span
              className="rounded-lg border border-[#e5e7eb] px-3 py-1.5 text-xs font-semibold text-[#9ca3af]"
              title={`最多同时对比 ${MAX_COMPARE} 所`}
            >
              已选满 {MAX_COMPARE} 所
            </span>
          ) : (
            <button
              type="button"
              onClick={() => onToggleCompare(school)}
              className="rounded-lg border border-[#e5e7eb] px-3 py-1.5 text-xs font-semibold text-[#4b5563] hover:bg-[#f9fafb]"
            >
              加入对比
            </button>
          )}
          <button
            type="button"
            onClick={() => onViewDetails(school)}
            className="rounded-lg bg-[#b94f38] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#a4422f]"
          >
            查看详情
          </button>
        </div>
      </div>
    </article>
  );
}

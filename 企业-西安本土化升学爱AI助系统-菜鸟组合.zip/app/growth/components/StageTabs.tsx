"use client";

import type { GrowthStage } from "../../lib/growth-schools";
import { STAGE_LABELS } from "../../lib/growth-schools";

type StageValue = GrowthStage | "all";

const TABS: { key: StageValue; label: string }[] = [
  { key: "all", label: "全部" },
  { key: "kindergarten", label: STAGE_LABELS.kindergarten },
  { key: "primary", label: STAGE_LABELS.primary },
  { key: "junior", label: STAGE_LABELS.junior },
  { key: "senior", label: STAGE_LABELS.senior },
];

export default function StageTabs({
  value,
  onChange,
}: {
  value: StageValue;
  onChange: (v: StageValue) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {TABS.map((t) => {
        const active = t.key === value;
        return (
          <button
            key={t.key}
            type="button"
            onClick={() => onChange(t.key)}
            className={
              active
                ? "rounded-full bg-[#b94f38] px-4 py-2 text-sm font-semibold text-white"
                : "rounded-full border border-[#e5e7eb] bg-white px-4 py-2 text-sm font-medium text-[#4b5563] hover:border-[#b94f38]"
            }
          >
            {t.label}
          </button>
        );
      })}
    </div>
  );
}

"use client";

import { useMemo } from "react";
import {
  type FamilyProfile,
  type Priority,
  type LearningObservation,
  type FamilyDistrict,
  CHILD_STAGE_LABELS,
  CHILD_AGE_BAND_LABELS,
  RESIDENCE_LABELS,
  OWNERSHIP_PREF_LABELS,
  BUDGET_LABELS,
  COMMUTE_LABELS,
  PRIORITY_LABELS,
  OBSERVATION_LABELS,
  MAX_MULTI_CHOICE,
  NOTES_MAX_LENGTH,
  toggleLimitedChoice,
  sanitizeFamilyNotes,
  validateFamilyProfile,
  type PlanningSummary,
  type SuggestedFilters,
} from "../../lib/growth-family-profile.ts";
import FamilyProfileSummary from "./FamilyProfileSummary";

const inputCls =
  "w-full rounded-lg border border-[#e5e7eb] bg-white px-3 py-2 text-sm text-[#10233d] outline-none focus:border-[#b94f38]";
const labelCls = "mb-1 block text-xs font-medium text-[#6b7280]";

const CHILD_STAGE_OPTIONS: { value: FamilyProfile["childStage"]; label: string }[] =
  [
    { value: "unknown", label: CHILD_STAGE_LABELS.unknown },
    { value: "kindergarten", label: CHILD_STAGE_LABELS.kindergarten },
    { value: "primary_lower", label: CHILD_STAGE_LABELS.primary_lower },
    { value: "primary_upper", label: CHILD_STAGE_LABELS.primary_upper },
    { value: "junior", label: CHILD_STAGE_LABELS.junior },
  ];

const CHILD_AGE_OPTIONS: { value: FamilyProfile["childAgeBand"]; label: string }[] =
  [
    { value: "prefer_not_to_say", label: CHILD_AGE_BAND_LABELS.prefer_not_to_say },
    { value: "age_3_5", label: CHILD_AGE_BAND_LABELS.age_3_5 },
    { value: "age_6_8", label: CHILD_AGE_BAND_LABELS.age_6_8 },
    { value: "age_9_12", label: CHILD_AGE_BAND_LABELS.age_9_12 },
    { value: "age_13_15", label: CHILD_AGE_BAND_LABELS.age_13_15 },
  ];

const DISTRICT_OPTIONS: { value: FamilyDistrict; label: string }[] = [
  { value: "undecided", label: "暂未决定" },
  { value: "新城区", label: "新城区" },
  { value: "碑林区", label: "碑林区" },
  { value: "莲湖区", label: "莲湖区" },
  { value: "雁塔区", label: "雁塔区" },
  { value: "灞桥区", label: "灞桥区" },
  { value: "未央区", label: "未央区" },
  { value: "阎良区", label: "阎良区" },
  { value: "临潼区", label: "临潼区" },
  { value: "长安区", label: "长安区" },
  { value: "高陵区", label: "高陵区" },
  { value: "鄠邑区", label: "鄠邑区" },
  { value: "蓝田县", label: "蓝田县" },
  { value: "周至县", label: "周至县" },
  { value: "outside_xian", label: "西安以外" },
];

const RESIDENCE_OPTIONS: { value: FamilyProfile["residenceSituation"]; label: string }[] =
  [
    { value: "unclear", label: RESIDENCE_LABELS.unclear },
    { value: "local_household", label: RESIDENCE_LABELS.local_household },
    {
      value: "nonlocal_with_residence",
      label: RESIDENCE_LABELS.nonlocal_with_residence,
    },
    { value: "nonlocal_other", label: RESIDENCE_LABELS.nonlocal_other },
    { value: "prefer_not_to_say", label: RESIDENCE_LABELS.prefer_not_to_say },
  ];

const OWNERSHIP_OPTIONS: {
  value: FamilyProfile["schoolOwnershipPreference"];
  label: string;
}[] = [
  { value: "no_preference", label: OWNERSHIP_PREF_LABELS.no_preference },
  { value: "public", label: OWNERSHIP_PREF_LABELS.public },
  { value: "private", label: OWNERSHIP_PREF_LABELS.private },
  { value: "inclusive", label: OWNERSHIP_PREF_LABELS.inclusive },
];

const BUDGET_OPTIONS: { value: FamilyProfile["annualBudgetBand"]; label: string }[] =
  [
    { value: "unclear", label: BUDGET_LABELS.unclear },
    { value: "under_1w", label: BUDGET_LABELS.under_1w },
    { value: "1w_3w", label: BUDGET_LABELS["1w_3w"] },
    { value: "3w_6w", label: BUDGET_LABELS["3w_6w"] },
    { value: "over_6w", label: BUDGET_LABELS.over_6w },
    { value: "prefer_not_to_say", label: BUDGET_LABELS.prefer_not_to_say },
  ];

const COMMUTE_OPTIONS: { value: FamilyProfile["commutePreference"]; label: string }[] =
  [
    { value: "unclear", label: COMMUTE_LABELS.unclear },
    { value: "under_30m", label: COMMUTE_LABELS.under_30m },
    { value: "30m_60m", label: COMMUTE_LABELS["30m_60m"] },
    { value: "over_60m", label: COMMUTE_LABELS.over_60m },
    { value: "boarding_possible", label: COMMUTE_LABELS.boarding_possible },
  ];

const PRIORITY_OPTIONS: { value: Priority; label: string }[] = (
  Object.keys(PRIORITY_LABELS) as Priority[]
).map((k) => ({ value: k, label: PRIORITY_LABELS[k] }));

const OBSERVATION_OPTIONS: { value: LearningObservation; label: string }[] = (
  Object.keys(OBSERVATION_LABELS) as LearningObservation[]
).map((k) => ({ value: k, label: OBSERVATION_LABELS[k] }));

function SelectField({
  id,
  label,
  value,
  options,
  onChange,
}: {
  id: string;
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}) {
  return (
    <div className="sm:col-span-1">
      <label className={labelCls} htmlFor={id}>
        {label}
      </label>
      <select
        id={id}
        className={inputCls}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}

export default function FamilyProfilePanel({
  profile,
  onChange,
  onGenerate,
  summary,
  onClear,
  onApplyFilters,
  appliedFilterNote,
}: {
  profile: FamilyProfile;
  onChange: (p: FamilyProfile) => void;
  onGenerate: (p: FamilyProfile) => void;
  summary: PlanningSummary | null;
  onClear: () => void;
  onApplyFilters: (f: SuggestedFilters) => void;
  appliedFilterNote: boolean;
}) {
  // 校验：UI 已禁止超限，这里仅做兜底展示。
  const validation = useMemo(() => validateFamilyProfile(profile), [profile]);
  const errorList = validation.errors;

  const set = <K extends keyof FamilyProfile>(key: K, value: FamilyProfile[K]) => {
    onChange({ ...profile, [key]: value });
  };

  const togglePriority = (value: Priority) => {
    onChange({
      ...profile,
      priorities: toggleLimitedChoice(profile.priorities, value, {
        max: MAX_MULTI_CHOICE,
      }),
    });
  };

  const toggleObservation = (value: LearningObservation) => {
    onChange({
      ...profile,
      learningObservations: toggleLimitedChoice(
        profile.learningObservations,
        value,
        { max: MAX_MULTI_CHOICE, exclusive: "no_specific_observation" },
      ),
    });
  };

  const onNotesChange = (raw: string) => {
    onChange({ ...profile, notes: sanitizeFamilyNotes(raw) });
  };

  return (
    <div className="mt-6 rounded-2xl border border-[#ede8e0] bg-[#fbfaf7] p-5">
      {/* 隐私声明（显著） */}
      <div className="mb-4 rounded-xl border border-[#e5e7eb] bg-white px-4 py-3 text-sm leading-relaxed text-[#4b5563]">
        家庭档案仅在当前页面会话中使用，刷新或关闭页面后不会保留。请勿填写姓名、证件号码、联系方式等个人信息。
      </div>

      {/* 分组表单 */}
      <form
        // 阻止回车误提交；所有操作通过按钮显式触发。
        onSubmit={(e) => e.preventDefault()}
        className="space-y-5"
      >
        {/* 当前阶段 */}
        <fieldset className="rounded-xl border border-[#e5e7eb] bg-white p-4">
          <legend className="px-1 text-sm font-semibold text-[#10233d]">
            当前阶段
          </legend>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <SelectField
              id="fp-child-stage"
              label="孩子当前教育阶段"
              value={profile.childStage}
              options={CHILD_STAGE_OPTIONS}
              onChange={(v) => set("childStage", v as FamilyProfile["childStage"])}
            />
            <SelectField
              id="fp-child-age"
              label="孩子年龄区间"
              value={profile.childAgeBand}
              options={CHILD_AGE_OPTIONS}
              onChange={(v) =>
                set("childAgeBand", v as FamilyProfile["childAgeBand"])
              }
            />
          </div>
        </fieldset>

        {/* 家庭所在区域与入学情况 */}
        <fieldset className="rounded-xl border border-[#e5e7eb] bg-white p-4">
          <legend className="px-1 text-sm font-semibold text-[#10233d]">
            家庭所在区域与入学情况
          </legend>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <SelectField
              id="fp-district"
              label="家庭所在区县"
              value={profile.familyDistrict}
              options={DISTRICT_OPTIONS}
              onChange={(v) =>
                set("familyDistrict", v as FamilyProfile["familyDistrict"])
              }
            />
            <SelectField
              id="fp-residence"
              label="户籍 / 居住情况"
              value={profile.residenceSituation}
              options={RESIDENCE_OPTIONS}
              onChange={(v) =>
                set("residenceSituation", v as FamilyProfile["residenceSituation"])
              }
            />
            <SelectField
              id="fp-ownership"
              label="办学性质偏好"
              value={profile.schoolOwnershipPreference}
              options={OWNERSHIP_OPTIONS}
              onChange={(v) =>
                set(
                  "schoolOwnershipPreference",
                  v as FamilyProfile["schoolOwnershipPreference"],
                )
              }
            />
          </div>
        </fieldset>

        {/* 预算与通勤 */}
        <fieldset className="rounded-xl border border-[#e5e7eb] bg-white p-4">
          <legend className="px-1 text-sm font-semibold text-[#10233d]">
            预算与通勤
          </legend>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <SelectField
              id="fp-budget"
              label="年度预算范围"
              value={profile.annualBudgetBand}
              options={BUDGET_OPTIONS}
              onChange={(v) =>
                set("annualBudgetBand", v as FamilyProfile["annualBudgetBand"])
              }
            />
            <SelectField
              id="fp-commute"
              label="通勤可接受范围"
              value={profile.commutePreference}
              options={COMMUTE_OPTIONS}
              onChange={(v) =>
                set("commutePreference", v as FamilyProfile["commutePreference"])
              }
            />
          </div>
        </fieldset>

        {/* 家长关注重点 */}
        <fieldset className="rounded-xl border border-[#e5e7eb] bg-white p-4">
          <legend className="px-1 text-sm font-semibold text-[#10233d]">
            家长关注重点（最多 {MAX_MULTI_CHOICE} 项）
          </legend>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {PRIORITY_OPTIONS.map((o) => {
              const id = `fp-priority-${o.value}`;
              const checked = profile.priorities.includes(o.value);
              return (
                <label
                  key={o.value}
                  htmlFor={id}
                  className="flex items-center gap-2 text-sm text-[#4b5563]"
                >
                  <input
                    id={id}
                    type="checkbox"
                    className="h-4 w-4 accent-[#b94f38]"
                    checked={checked}
                    onChange={() => togglePriority(o.value)}
                  />
                  {o.label}
                </label>
              );
            })}
          </div>
        </fieldset>

        {/* 学习与适应观察 */}
        <fieldset className="rounded-xl border border-[#e5e7eb] bg-white p-4">
          <legend className="px-1 text-sm font-semibold text-[#10233d]">
            学习与适应观察（最多 {MAX_MULTI_CHOICE} 项；「暂无具体观察」不可与其余项同选）
          </legend>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {OBSERVATION_OPTIONS.map((o) => {
              const id = `fp-obs-${o.value}`;
              const checked = profile.learningObservations.includes(o.value);
              return (
                <label
                  key={o.value}
                  htmlFor={id}
                  className="flex items-center gap-2 text-sm text-[#4b5563]"
                >
                  <input
                    id={id}
                    type="checkbox"
                    className="h-4 w-4 accent-[#b94f38]"
                    checked={checked}
                    onChange={() => toggleObservation(o.value)}
                  />
                  {o.label}
                </label>
              );
            })}
          </div>
        </fieldset>

        {/* 补充说明 */}
        <div className="rounded-xl border border-[#e5e7eb] bg-white p-4">
          <label className={labelCls} htmlFor="fp-notes">
            补充说明（最多 {NOTES_MAX_LENGTH} 字，仅填写非识别性需求说明）
          </label>
          <textarea
            id="fp-notes"
            className={`${inputCls} min-h-[80px] resize-y`}
            value={profile.notes}
            maxLength={NOTES_MAX_LENGTH}
            placeholder="例如：希望学校重视家校沟通、有稳定的师资团队等"
            onChange={(e) => onNotesChange(e.target.value)}
          />
          <p className="mt-1 text-xs text-[#9ca3af]">
            {profile.notes.length} / {NOTES_MAX_LENGTH}
          </p>
        </div>

        {/* 监护人确认 */}
        <div className="rounded-xl border border-[#f0d9cc] bg-[#fdf2ee] p-4">
          <label
            htmlFor="fp-guardian"
            className="flex items-start gap-2 text-sm text-[#4b5563]"
          >
            <input
              id="fp-guardian"
              type="checkbox"
              className="mt-0.5 h-4 w-4 accent-[#b94f38]"
              checked={profile.guardianConfirmed}
              onChange={(e) => set("guardianConfirmed", e.target.checked)}
            />
            <span>
              我是孩子的监护人或已获得监护人授权，并理解本功能不构成教育、心理或录取结论。
            </span>
          </label>
        </div>

        {/* 错误提示 */}
        {errorList.length > 0 ? (
          <div role="alert" className="space-y-1">
            {errorList.map((err) => (
              <p
                key={err.code}
                className="rounded-lg border border-[#f0d9cc] bg-[#fdf2ee] px-3 py-2 text-sm text-[#b94f38]"
              >
                {err.message}
              </p>
            ))}
          </div>
        ) : null}

        {/* 操作按钮 */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={!profile.guardianConfirmed}
            onClick={() => onGenerate(profile)}
            className="rounded-lg bg-[#b94f38] px-4 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:bg-[#d8c3bb]"
          >
            生成规划重点
          </button>
          <button
            type="button"
            onClick={onClear}
            className="rounded-lg border border-[#e5e7eb] bg-white px-4 py-2 text-sm font-medium text-[#4b5563] hover:border-[#b94f38]"
          >
            清空档案
          </button>
        </div>

        {/* 非诊断 / 非录取结论声明 */}
        <p className="text-xs leading-relaxed text-[#9ca3af]">
          本功能仅整理您填写的关注点，不构成教育诊断、心理评估或录取结论；不预测录取概率，不生成学校排名。结果仍需结合官方政策和实地了解判断。
        </p>
      </form>

      {/* 规划摘要（生成后展示） */}
      {summary ? (
        <FamilyProfileSummary
          summary={summary}
          onApplyFilters={onApplyFilters}
          appliedFilterNote={appliedFilterNote}
        />
      ) : null}
    </div>
  );
}

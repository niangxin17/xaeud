"use client";

import type {
  GrowthStage,
  SchoolOwnership,
  VerificationLevel,
} from "../../lib/growth-schools";
import {
  OWNERSHIP_LABELS,
  VERIFICATION_LABELS,
  VERIFICATION_LEVELS,
} from "../../lib/growth-schools";

export interface FilterState {
  stage: GrowthStage | "all";
  keyword: string;
  district: string; // "all" 表示不限
  ownership: SchoolOwnership | "all";
  verification: VerificationLevel | "all";
}

export default function SchoolFilters({
  state,
  districts,
  onKeywordChange,
  onDistrictChange,
  onOwnershipChange,
  onVerificationChange,
  onClear,
}: {
  state: FilterState;
  districts: string[];
  onKeywordChange: (v: string) => void;
  onDistrictChange: (v: string) => void;
  onOwnershipChange: (v: SchoolOwnership | "all") => void;
  onVerificationChange: (v: VerificationLevel | "all") => void;
  onClear: () => void;
}) {
  const inputCls =
    "w-full rounded-lg border border-[#e5e7eb] bg-white px-3 py-2 text-sm text-[#10233d] outline-none focus:border-[#b94f38]";
  const labelCls = "mb-1 block text-xs font-medium text-[#6b7280]";

  return (
    <div className="rounded-2xl border border-[#ede8e0] bg-[#fbfaf7] p-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="lg:col-span-1">
          <label className={labelCls}>关键词</label>
          <input
            className={inputCls}
            type="text"
            value={state.keyword}
            placeholder="机构名称 / 区域 / 特色"
            onChange={(e) => onKeywordChange(e.target.value)}
          />
        </div>

        <div>
          <label className={labelCls}>所在区</label>
          <select
            className={inputCls}
            value={state.district}
            onChange={(e) => onDistrictChange(e.target.value)}
          >
            <option value="all">全部</option>
            {districts.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className={labelCls}>办学性质</label>
          <select
            className={inputCls}
            value={state.ownership}
            onChange={(e) =>
              onOwnershipChange(e.target.value as SchoolOwnership | "all")
            }
          >
            <option value="all">全部</option>
            {(Object.keys(OWNERSHIP_LABELS) as SchoolOwnership[]).map((o) => (
              <option key={o} value={o}>
                {OWNERSHIP_LABELS[o]}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className={labelCls}>可信度</label>
          <select
            className={inputCls}
            value={state.verification}
            onChange={(e) =>
              onVerificationChange(e.target.value as VerificationLevel | "all")
            }
          >
            <option value="all">全部</option>
            {VERIFICATION_LEVELS.map((v) => (
              <option key={v} value={v}>
                {VERIFICATION_LABELS[v]}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-3 flex justify-end">
        <button
          type="button"
          onClick={onClear}
          className="rounded-lg border border-[#e5e7eb] bg-white px-3 py-1.5 text-xs font-medium text-[#4b5563] hover:border-[#b94f38]"
        >
          清空筛选
        </button>
      </div>
    </div>
  );
}

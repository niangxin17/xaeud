"use client";

import type { GrowthSchool } from "../../lib/growth-schools";
import {
  MIN_COMPARE,
  MAX_COMPARE,
  canOpenCompare,
} from "../../lib/school-compare";

// 底部对比栏：仅在已选至少 1 所时出现，展示已选学校、支持逐个移出与一键清空。
// 「开始对比」按钮在不足 MIN_COMPARE 所时禁用，避免出现只有单校的"对比"。
export default function SchoolCompareBar({
  selected,
  onRemove,
  onClear,
  onOpen,
}: {
  selected: GrowthSchool[];
  onRemove: (id: string) => void;
  onClear: () => void;
  onOpen: () => void;
}) {
  if (selected.length === 0) return null;

  const ids = selected.map((s) => s.id);
  const ready = canOpenCompare(ids);
  const remaining = MIN_COMPARE - selected.length;

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-[#ede8e0] bg-white/95 px-4 py-3 shadow-[0_-2px_12px_rgba(16,35,61,0.08)] backdrop-blur">
      <div className="mx-auto flex max-w-5xl flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        {/* 已选学校列表：每个都能单独移出 */}
        <div className="min-w-0 flex-1">
          <p className="text-xs text-[#6b7280]">
            已选 <span className="font-semibold text-[#10233d]">{selected.length}</span>/{MAX_COMPARE}
            {ready ? null : (
              <span className="ml-1 text-[#b94f38]">
                （再选择 {remaining} 所开始对比）
              </span>
            )}
          </p>
          <ul className="mt-1.5 flex flex-wrap gap-2">
            {selected.map((s) => (
              <li key={s.id}>
                <span className="inline-flex items-center gap-1 rounded-full border border-[#f0d9cc] bg-[#fdf2ee] py-1 pl-3 pr-1 text-xs text-[#10233d]">
                  <span className="max-w-[9rem] break-words">{s.name}</span>
                  <button
                    type="button"
                    onClick={() => onRemove(s.id)}
                    aria-label={`将 ${s.name} 移出对比`}
                    className="rounded-full px-1.5 py-0.5 text-[#b94f38] hover:bg-[#f6e2da]"
                  >
                    ✕
                  </button>
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <button
            type="button"
            onClick={onClear}
            className="rounded-lg border border-[#e5e7eb] px-3 py-2 text-xs font-semibold text-[#6b7280] hover:bg-[#f9fafb]"
          >
            清空
          </button>
          <button
            type="button"
            onClick={onOpen}
            disabled={!ready}
            aria-disabled={!ready}
            title={ready ? "打开对比" : `至少选择 ${MIN_COMPARE} 所才能对比`}
            className={
              ready
                ? "rounded-lg bg-[#b94f38] px-4 py-2 text-sm font-semibold text-white hover:bg-[#a4422f]"
                : "cursor-not-allowed rounded-lg bg-[#e5e7eb] px-4 py-2 text-sm font-semibold text-[#9ca3af]"
            }
          >
            开始对比
          </button>
        </div>
      </div>
    </div>
  );
}

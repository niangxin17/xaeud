// 全周期教育路线图（成长地图 → 中考志愿系统）。
//
// 纯展示组件（无 "use client"、无状态、无数据读写、无跳转副作用）。
// 仅以真实路由链接到现有中考系统，不复制也不改写任何中考算法。
//
// 边界约束：
// - “规划中”阶段不渲染任何 <a>/<Link>，不链接到不存在的页面。
// - 不写“即将上线”日期，不假装已有大学/考研/博士/职业数据库。
// - 中考规划阶段只链接到现有真实入口：中考测算(/)、志愿填报(/filing)、我的报告(/downloads)。
// - 报告/复盘类需权限的内容只链接到权限入口(/downloads)，不直达受保护数据。

import Link from "next/link";
import EducationStageBridge from "../../components/EducationStageBridge";

// 已开放：当前成长地图覆盖的阶段（本工具内，无外部链接）。
const OPEN_STAGES = [
  { label: "幼儿园", note: "园所查询与入园准备" },
  { label: "小学", note: "学区与入学衔接" },
  { label: "初中择校与衔接", note: "升学与适应支持" },
];

// 规划中：尚未开放，不提供任何链接，不写上线时间。
const PLANNED_STAGES = [
  "高中成长规划",
  "大学专业与院校规划",
  "考研规划",
  "博士发展规划",
  "职业发展规划",
];

const EXAM_ENTRIES = [
  {
    href: "/",
    title: "开始中考测算",
    desc: "输入分数与区县，定位可报学校区间。",
  },
  {
    href: "/filing",
    title: "进入志愿填报",
    desc: "按批次模拟、核对并准备正式填报。",
  },
  {
    href: "/downloads",
    title: "查看我的报告",
    desc: "在已生成报告后查看对应档位内容（需先在中考系统测分）。",
  },
];

export default function EducationJourney() {
  return (
    <div className="space-y-4">
      {/* 全周期路线：横向阶段导航（压缩为单行胶囊，去掉大段说明） */}
      <nav
        aria-label="全周期教育路线"
        className="rounded-2xl border border-[#ede8e0] bg-white p-5"
      >
        <h2 className="text-lg font-bold text-[#10233d]">全周期教育路线</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {OPEN_STAGES.map((s) => (
            <span
              key={s.label}
              className="inline-flex items-center gap-1.5 rounded-full border border-[#e5e7eb] bg-[#fdfbf8] px-3 py-1.5 text-sm font-medium text-[#10233d]"
            >
              {s.label}
              <span className="rounded-full bg-[#eef3f7] px-2 py-0.5 text-[11px] font-semibold text-[#087f8c]">
                已开放
              </span>
            </span>
          ))}

          {/* 中考规划：当前阶段，高亮 + 真实入口 */}
          <span className="inline-flex items-center gap-1.5 rounded-full border border-[#b94f38]/40 bg-[#fdf2ee] px-3 py-1.5 text-sm font-semibold text-[#b94f38]">
            中考规划
            <span className="rounded-full bg-[#b94f38] px-2 py-0.5 text-[11px] font-semibold text-white">
              已开放
            </span>
          </span>

          {PLANNED_STAGES.map((label) => (
            <span
              key={label}
              className="inline-flex items-center gap-1.5 rounded-full border border-dashed border-[#d1d5db] bg-[#f9fafb] px-3 py-1.5 text-sm font-medium text-[#9ca3af]"
            >
              {label}
              <span className="rounded-full bg-[#f3f4f6] px-2 py-0.5 text-[11px] font-semibold text-[#9ca3af]">
                规划中
              </span>
            </span>
          ))}
        </div>
        <p className="mt-3 text-xs text-[#6b7280]">
          不同阶段使用独立的规划工具，家庭档案不会自动传入中考测算系统。
        </p>
      </nav>

      {/* 中考规划真实入口（横向卡片） */}
      <div className="rounded-2xl border border-[#ede8e0] bg-white p-5">
        <h3 className="text-sm font-bold text-[#10233d]">中考规划入口</h3>
        <ul className="mt-3 grid gap-2 sm:grid-cols-3">
          {EXAM_ENTRIES.map((e) => (
            <li key={e.href}>
              <Link
                href={e.href}
                className="block rounded-xl border border-[#ede8e0] bg-white px-3 py-3 text-left transition hover:border-[#b94f38] hover:bg-[#fff7f2]"
              >
                <span className="block text-sm font-bold text-[#10233d]">{e.title}</span>
                <span className="mt-1 block text-xs leading-snug text-[#6b7280]">{e.desc}</span>
              </Link>
            </li>
          ))}
        </ul>
        <p className="mt-3 rounded-lg bg-[#fff7f2] px-3 py-2 text-xs leading-relaxed text-[#b94f38]">
          进入中考系统后，将按中考成绩、位次与志愿规则独立测算；成长地图家庭档案不会自动带入。
        </p>
      </div>

      {/* 阶段交接说明（共享说明卡） */}
      <EducationStageBridge />
    </div>
  );
}

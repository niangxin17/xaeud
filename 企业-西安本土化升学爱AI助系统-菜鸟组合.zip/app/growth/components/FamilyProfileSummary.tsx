"use client";

import {
  type PlanningSummary,
  type SuggestedFilters,
} from "../../lib/growth-family-profile.ts";
import { STAGE_LABELS, OWNERSHIP_LABELS } from "../../lib/growth-schools.ts";

function describeFilters(f: SuggestedFilters): string {
  const stageText =
    f.stage === "all" ? "不限阶段" : STAGE_LABELS[f.stage];
  const districtText = f.district === "all" ? "不限区域" : f.district;
  const ownershipText =
    f.ownership === "all" ? "不限性质" : OWNERSHIP_LABELS[f.ownership];
  return `阶段：${stageText}；区域：${districtText}；办学性质：${ownershipText}`;
}

export default function FamilyProfileSummary({
  summary,
  onApplyFilters,
  appliedFilterNote,
}: {
  summary: PlanningSummary;
  onApplyFilters: (f: SuggestedFilters) => void;
  appliedFilterNote: boolean;
}) {
  return (
    <div
      aria-live="polite"
      className="mt-5 rounded-xl border border-[#ede8e0] bg-white p-5"
    >
      <h3 className="text-base font-bold text-[#10233d]">当前规划重点摘要</h3>

      {/* 已填写条件摘要 */}
      <section className="mt-4">
        <h4 className="text-sm font-semibold text-[#10233d]">已填写条件</h4>
        {summary.filledConditions.length > 0 ? (
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-[#4b5563]">
            {summary.filledConditions.map((t, i) => (
              <li key={i}>{t}</li>
            ))}
          </ul>
        ) : (
          <p className="mt-2 text-sm text-[#9ca3af]">尚未填写具体条件。</p>
        )}
      </section>

      {/* 当前规划重点 */}
      <section className="mt-4">
        <h4 className="text-sm font-semibold text-[#10233d]">当前规划重点</h4>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-[#4b5563]">
          {summary.planningFocus.map((t, i) => (
            <li key={i}>{t}</li>
          ))}
        </ul>
      </section>

      {/* 建议优先核实的信息 */}
      <section className="mt-4">
        <h4 className="text-sm font-semibold text-[#10233d]">
          建议优先核实的信息
        </h4>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-[#4b5563]">
          {summary.suggestedVerifications.map((t, i) => (
            <li key={i}>{t}</li>
          ))}
        </ul>
      </section>

      {/* 建议筛选条件 */}
      <section className="mt-4">
        <h4 className="text-sm font-semibold text-[#10233d]">建议筛选条件</h4>
        <p className="mt-2 rounded-lg bg-[#f7f3ec] px-3 py-2 text-sm text-[#4b5563]">
          {describeFilters(summary.suggestedFilters)}
        </p>
        <p className="mt-1 text-xs text-[#9ca3af]">
          建议筛选仅包含阶段、区域、办学性质；预算、通勤与关注点用于上方摘要，不直接参与筛选。
        </p>
      </section>

      {/* 生成依据 */}
      <section className="mt-4">
        <h4 className="text-sm font-semibold text-[#10233d]">生成依据</h4>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-xs text-[#9ca3af]">
          {summary.basis.map((t, i) => (
            <li key={i}>{t}</li>
          ))}
        </ul>
      </section>

      {/* 应用建议筛选 */}
      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={() => onApplyFilters(summary.suggestedFilters)}
          className="rounded-lg bg-[#10233d] px-4 py-2 text-sm font-semibold text-white hover:bg-[#1f3a5f]"
        >
          应用建议筛选
        </button>
      </div>

      {appliedFilterNote ? (
        <p
          role="status"
          className="mt-3 rounded-lg border border-[#e5e7eb] bg-[#f7f3ec] px-3 py-2 text-sm text-[#4b5563]"
        >
          已根据家庭档案更新基础筛选条件，结果仍需结合官方政策和实地了解判断。
        </p>
      ) : null}
    </div>
  );
}

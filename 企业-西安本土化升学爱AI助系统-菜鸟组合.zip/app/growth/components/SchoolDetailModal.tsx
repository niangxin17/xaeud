"use client";

import { useEffect, useRef } from "react";
import type { GrowthSchool } from "../../lib/growth-schools";
import {
  formatEmpty,
  formatSource,
  formatVerification,
  formatAdmissionLine,
  formatCutHistory,
  isSeniorSchool,
  STAGE_LABELS,
  OWNERSHIP_LABELS,
} from "../../lib/growth-schools";

// 字段分组小标题
function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-[#b94f38]">
      {children}
    </h3>
  );
}

// 一行信息：空字段统一显示「暂未核实」，不隐藏成已知事实。
function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-2 text-sm leading-6">
      <dt className="w-24 shrink-0 text-[#9ca3af]">{label}</dt>
      <dd className="text-[#4b5563]">{formatEmpty(value)}</dd>
    </div>
  );
}

// 标签列表：空数组显示「暂未核实」。
function TagBlock({ tags }: { tags: string[] }) {
  return (
    <dd className="text-[#4b5563]">
      {tags.length > 0 ? tags.join("、") : "暂未核实"}
    </dd>
  );
}

export default function SchoolDetailModal({
  school,
  open,
  onClose,
}: {
  school: GrowthSchool | null;
  open: boolean;
  onClose: () => void;
}) {
  const closeBtnRef = useRef<HTMLButtonElement | null>(null);
  const prevFocusRef = useRef<HTMLElement | null>(null);

  // 滚动锁定 + 焦点管理（打开锁定页面滚动、聚焦关闭按钮；关闭恢复滚动与触发焦点）。
  useEffect(() => {
    if (!open) return;
    prevFocusRef.current = document.activeElement as HTMLElement | null;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeBtnRef.current?.focus();
    return () => {
      document.body.style.overflow = prevOverflow;
      prevFocusRef.current?.focus?.();
    };
  }, [open]);

  // Escape 键关闭
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open || !school) return null;

  const source = formatSource(school.sourceName, school.sourceUrl);
  const isUnverified = school.verificationLevel === "UNVERIFIED";

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-0 sm:items-center sm:p-4"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-2xl bg-white shadow-xl sm:max-w-2xl sm:rounded-2xl"
        role="dialog"
        aria-modal="true"
        aria-labelledby="school-detail-title"
        // 点击弹窗内容本身不触发遮罩关闭
        onClick={(e) => e.stopPropagation()}
      >
        {/* 头部：名称 + 演示标识 + 关闭按钮 */}
        <header className="flex items-start justify-between gap-3 border-b border-[#ede8e0] px-5 py-4">
          <div>
            <h2
              id="school-detail-title"
              className="text-lg font-bold text-[#10233d]"
            >
              {school.name}
            </h2>
            {school.isDemo ? (
              <span className="mt-1 inline-block rounded-full bg-[#f3f4f6] px-2 py-0.5 text-[11px] font-semibold text-[#9ca3af]">
                演示数据
              </span>
            ) : null}
          </div>
          <button
            ref={closeBtnRef}
            type="button"
            onClick={onClose}
            className="rounded-lg px-3 py-1.5 text-sm font-semibold text-[#6b7280] hover:bg-[#f3f4f6]"
            aria-label="关闭详情"
          >
            ✕
          </button>
        </header>

        {/* 可滚动内容区 */}
        <div className="overflow-y-auto px-5 py-4">
          {/* 基本信息 */}
          <section className="mb-5">
            <SectionTitle>基本信息</SectionTitle>
            <dl className="space-y-1.5">
              <InfoRow label="学段" value={STAGE_LABELS[school.stage]} />
              <InfoRow label="所在区" value={school.district} />
              <InfoRow label="办学性质" value={OWNERSHIP_LABELS[school.ownership]} />
              <InfoRow label="地址" value={school.address} />
            </dl>
          </section>

          {/* 费用与餐食 */}
          <section className="mb-5">
            <SectionTitle>费用与餐食</SectionTitle>
            <dl className="space-y-1.5">
              <InfoRow label="学费" value={school.tuitionText} />
              <InfoRow label="餐食" value={school.mealText} />
            </dl>
          </section>

          {/* 课程与特色 */}
          <section className="mb-5">
            <SectionTitle>课程与特色</SectionTitle>
            <dl className="space-y-1.5">
              <div className="flex gap-2 text-sm leading-6">
                <dt className="w-24 shrink-0 text-[#9ca3af]">课程标签</dt>
                <TagBlock tags={school.curriculumTags} />
              </div>
              <div className="flex gap-2 text-sm leading-6">
                <dt className="w-24 shrink-0 text-[#9ca3af]">特色标签</dt>
                <TagBlock tags={school.featureTags} />
              </div>
            </dl>
          </section>

          {/* 招生与报名 / 中考录取信息 */}
          <section className="mb-5">
            <SectionTitle>招生与报名</SectionTitle>
            <dl className="space-y-1.5">
              {isSeniorSchool(school) ? (
                <>
                  <InfoRow label="2026录取线" value={formatAdmissionLine(school)} />
                  <InfoRow label="办学层次" value={school.admissionTier ?? ""} />
                  <InfoRow
                    label="录取批次"
                    value={school.admissionBatch != null ? `第${school.admissionBatch}批` : ""}
                  />
                  <InfoRow label="招生单元" value={school.admissionUnit ?? ""} />
                  <InfoRow
                    label="招生计划"
                    value={school.enrollmentPlan != null ? `${school.enrollmentPlan} 人` : ""}
                  />
                  <InfoRow
                    label="定向计划"
                    value={school.directionalPlan != null ? `${school.directionalPlan} 人` : ""}
                  />
                  <InfoRow label="历年分数线" value={formatCutHistory(school)} />
                  <InfoRow label="重点班" value={school.keyClassInfo ?? ""} />
                </>
              ) : (
                <>
                  <InfoRow label="招生范围" value={school.enrollmentScope} />
                  <InfoRow label="报名材料" value={school.registrationMaterials} />
                </>
              )}
              {/* 过渡招生政策：仅高新等民转公过渡校赋值；政策已核实 ≠ 招生范围已核实。
                  当前 12 条预览数据均无此字段，故不展示；保留为后端真实数据接入后的统一渲染位。 */}
              {school.enrollmentPolicyStatus ? (
                <>
                  <InfoRow
                    label="过渡招生政策"
                    value={
                      school.enrollmentPolicyStatus === "transition_policy_verified"
                        ? "政策已核实（继续沿用原政策）"
                        : formatEmpty(school.enrollmentPolicyStatus)
                    }
                  />
                  <InfoRow
                    label="政策说明"
                    value={school.enrollmentPolicyNote ?? ""}
                  />
                </>
              ) : null}
            </dl>
          </section>

          {/* 数据来源与可信度 */}
          <section className="mb-2">
            <SectionTitle>数据来源与可信度</SectionTitle>
            <dl className="space-y-1.5">
              <div className="flex gap-2 text-sm leading-6">
                <dt className="w-24 shrink-0 text-[#9ca3af]">信息来源</dt>
                <dd className="text-[#4b5563]">
                  {source.url ? (
                    <a
                      href={source.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#b94f38] underline underline-offset-2"
                    >
                      {source.label}
                    </a>
                  ) : (
                    "来源待补充"
                  )}
                </dd>
              </div>
              <InfoRow label="来源更新" value={school.sourceUpdatedAt} />
              <div className="flex gap-2 text-sm leading-6">
                <dt className="w-24 shrink-0 text-[#9ca3af]">可信度</dt>
                <dd>
                  <span
                    className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${
                      isUnverified
                        ? "bg-[#f3f4f6] text-[#6b7280] border border-[#e5e7eb]"
                        : "bg-[#fbf3e7] text-[#b94f38] border border-[#f0d9cc]"
                    }`}
                  >
                    {formatVerification(school.verificationLevel)}
                    {isUnverified ? "" : `（${school.verificationLevel}）`}
                  </span>
                </dd>
              </div>
              <InfoRow label="可信度说明" value={school.verificationNote} />
            </dl>
          </section>
        </div>

        {/* 固定声明：本页仅用于信息整理与家庭决策参考，不构成任何入学或择校承诺。 */}
        <footer className="border-t border-[#ede8e0] bg-[#faf8f4] px-5 py-3 text-xs leading-5 text-[#9ca3af]">
          此页面用于信息整理与家庭决策参考，不构成录取、入学或择校承诺。
        </footer>
      </div>
    </div>
  );
}

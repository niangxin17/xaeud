"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { GrowthSchool } from "../../lib/growth-schools";
import {
  filterSchools,
  emptyFilter,
  distinctDistricts,
  getVisibleGrowthSchools,
} from "../../lib/growth-schools";
// 步骤19 全量官方库快照（AUTO-GENERATED，414 条：4 区 2026 学区划分 PDF + 西安市 2026 普通高中招生计划）。
// 全部为 A 级官方公开、来源可复核；步骤18《18-人工发布审批.md》签核的 12 所预览候选为其中 A 级子集。
// 数据恒由本组件装载（预览开关仅控制内部声明文案，演示开关仍独立拦截演示数据）。
import { VERIFIED_SCHOOLS_PREVIEW } from "../../lib/growth-verified-schools";
import {
  MAX_COMPARE,
  canOpenCompare,
  compareLockedStage,
  isCompareFull,
  isInCompare,
  removeFromCompare,
  resolveCompareSchools,
  toggleCompare,
} from "../../lib/school-compare";
import StageTabs from "./StageTabs";
import SchoolFilters, { FilterState } from "./SchoolFilters";
import SchoolCard from "./SchoolCard";
import SchoolDetailModal from "./SchoolDetailModal";
import SchoolCompareBar from "./SchoolCompareBar";
import SchoolCompareModal from "./SchoolCompareModal";
import FamilyProfilePanel from "./FamilyProfilePanel";
import {
  type FamilyProfile,
  type PlanningSummary,
  type SuggestedFilters,
  createEmptyFamilyProfile,
  buildPlanningSummary,
} from "../../lib/growth-family-profile.ts";

export default function GrowthExplorer({
  verifiedSchools,
}: {
  verifiedSchools: GrowthSchool[];
}) {
  // 显式演示开关：仅 NEXT_PUBLIC_GROWTH_DEMO_MODE=1 时允许加载演示机构。
  // 默认、生产构建、变量缺失均为 false —— 绝不展示演示数据（安全默认值）。
  // 来源证据：同框架 client 组件 app/official/page.tsx 以 process.env.NEXT_PUBLIC_* 读取公开环境变量。
  const demoMode = process.env.NEXT_PUBLIC_GROWTH_DEMO_MODE === "1";

  // 预览开关（隔离）：仅 NEXT_PUBLIC_GROWTH_PREVIEW=1 时装载 12 条已通过《18-人工发布清单》人工审批的预览数据；
  // 默认、生产构建、变量缺失均为 false —— 绝不公开（安全默认值）。与演示开关互相独立，二者可叠加但不可互相替代。
  const previewMode = process.env.NEXT_PUBLIC_GROWTH_PREVIEW === "1";

  // 构建版本（公开可追溯）：构建时由 NEXT_PUBLIC_COMMIT_SHA 注入；缺失则不展示。
  const buildVersion = process.env.NEXT_PUBLIC_COMMIT_SHA ?? "";

  // 正式公开（已获单独明确授权）：已审批预览学校默认公开，不再依赖预览开关；
  // 演示闸门仍由 demoMode 拦截，演示数据永不进入正式页面。
  const effectiveVerified = VERIFIED_SCHOOLS_PREVIEW;

  // 生产展示闸门：演示模式返回 DEMO_SCHOOLS；否则仅返回通过发布闸门的真实数据（预览关则为空）。
  const visible = useMemo(
    () => getVisibleGrowthSchools({ demoMode, verifiedSchools: effectiveVerified }),
    [demoMode, effectiveVerified],
  );

  const [filter, setFilter] = useState<FilterState>(emptyFilter());
  const [selectedSchool, setSelectedSchool] = useState<GrowthSchool | null>(null);
  // 用户是否请求打开详情 / 对比；真正是否可见由下方派生计算，避免在 effect 里改状态。
  const [detailRequested, setDetailRequested] = useState(false);
  const [compareRequested, setCompareRequested] = useState(false);

  // 对比选择：仅存在于当前页面内存；刷新即清空，不读写任何浏览器存储、不序列化学校对象。
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [compareMessage, setCompareMessage] = useState("");

  // 家庭成长档案：仅存在于当前页面会话的内存中；刷新即清空，不读写任何浏览器存储、不序列化。
  const [showProfilePanel, setShowProfilePanel] = useState(false);
  const [familyProfile, setFamilyProfile] = useState<FamilyProfile>(
    createEmptyFamilyProfile(),
  );
  const [generatedSummary, setGeneratedSummary] = useState<PlanningSummary | null>(
    null,
  );
  const [appliedFilterNote, setAppliedFilterNote] = useState(false);

  // 生成规划摘要：仅在监护人确认后由用户主动点击触发；未确认时摘要为 null。
  const handleGenerateSummary = useCallback((p: FamilyProfile) => {
    setGeneratedSummary(buildPlanningSummary(p));
  }, []);

  // 清空档案：档案、摘要、应用提示一并清除；对比与筛选条件不受影响（不自动改动）。
  const handleClearProfile = useCallback(() => {
    setFamilyProfile(createEmptyFamilyProfile());
    setGeneratedSummary(null);
    setAppliedFilterNote(false);
  }, []);

  // 应用建议筛选：仅更新 stage / district / ownership（基础筛选），不自动选学校、
  // 不加入对比、不打开详情；区域若不在示例数据中仍可应用，但由真实数据决定结果。
  const handleApplySuggestedFilters = useCallback(
    (f: SuggestedFilters) => {
      setFilter((prev) => ({
        ...prev,
        stage: f.stage,
        district: f.district,
        ownership: f.ownership,
      }));
      setAppliedFilterNote(true);
    },
    [],
  );

  const districts = useMemo(() => distinctDistricts(visible), [visible]);
  const results = useMemo(() => filterSchools(visible, filter), [visible, filter]);

  // 是否存在激活的筛选条件（阶段 / 关键词 / 区 / 性质 / 可信度）。
  const isFilterActive = useMemo(
    () =>
      filter.stage !== "all" ||
      filter.keyword.trim() !== "" ||
      filter.district !== "all" ||
      filter.ownership !== "all" ||
      filter.verification !== "all",
    [filter],
  );

  // 学段查询表：用于在纯逻辑层判定同学段约束。
  const stageById = useMemo(
    () =>
      Object.fromEntries(
        visible.map((s) => [s.id, s.stage]),
      ) as Record<string, GrowthSchool["stage"]>,
    [visible],
  );
  // 当前已锁定的对比学段（空列表时为 null，表示可重新选择任意学段）。
  const lockedStage = useMemo(
    () => compareLockedStage(compareIds, stageById),
    [compareIds, stageById],
  );

  // 提示语几秒后自动消失。
  useEffect(() => {
    if (!compareMessage) return;
    const t = setTimeout(() => setCompareMessage(""), 2600);
    return () => clearTimeout(t);
  }, [compareMessage]);

  // 打开详情：同一时间只能打开一个学校，并关闭对比弹窗。
  const openDetail = (s: GrowthSchool) => {
    setSelectedSchool(s);
    setDetailRequested(true);
    setCompareRequested(false);
  };
  // 关闭详情：清空选中，不涉及对比存储。
  const closeDetail = () => {
    setDetailRequested(false);
    setSelectedSchool(null);
  };

  // 加入 / 移出对比：由纯逻辑函数保证去重、4 所上限与同学段约束。
  const onToggleCompare = useCallback(
    (s: GrowthSchool) => {
      setCompareIds((prev) => {
        const r = toggleCompare(prev, s.id, {
          stage: s.stage,
          lockedStage,
        });
        if (r.reason === "full") {
          setCompareMessage(`最多同时对比 ${MAX_COMPARE} 所，请先移出一所再添加。`);
        } else if (r.reason === "stage_mismatch") {
          setCompareMessage("请只对比同一学段的学校。");
        } else {
          setCompareMessage("");
        }
        return r.ids;
      });
    },
    [lockedStage],
  );

  const onRemoveCompare = useCallback((id: string) => {
    setCompareIds((prev) => removeFromCompare(prev, id));
  }, []);

  const onClearCompare = useCallback(() => {
    setCompareIds([]);
    setCompareRequested(false);
  }, []);

  // 已选学校对象：按加入顺序，未知 ID 自动忽略。
  const compareSchools = useMemo(
    () => resolveCompareSchools(visible, compareIds),
    [visible, compareIds],
  );
  const compareFull = isCompareFull(compareIds);

  // 派生可见性，避免在 effect 里回写状态：
  // 1) 对比视图必须至少 2 所，移出到 1 所时自动收起；
  // 2) 详情弹窗仅在所选学校仍命中当前筛选结果时展示。
  const compareOpen = compareRequested && canOpenCompare(compareIds);
  const modalOpen =
    detailRequested &&
    selectedSchool !== null &&
    results.some((r) => r.id === selectedSchool.id);

  return (
    <section className="mt-8">
      {/* 演示数据声明（仅在显式演示模式展示） */}
      {demoMode ? (
        <div className="mb-4 rounded-xl border border-[#f0d9cc] bg-[#fdf2ee] px-5 py-3 text-sm text-[#b94f38]">
          当前为功能演示数据，不代表真实学校信息。正式版将仅接入教育主管部门与学校官方公开资料。
        </div>
      ) : null}

      {/* 正式公开发布声明（非演示模式：官方公开数据） */}
      {!demoMode ? (
        <div className="mb-4 rounded-xl border border-[#cfe3f3] bg-[#f0f7fd] px-5 py-3 text-sm text-[#2b6cb0]">
          本页学校资料已正式公开发布：资料以教育主管部门与学校官方公开信息为准，持续核验中，不构成录取或择校建议。{previewMode ? "（内部预览开关仍开启）" : ""}
        </div>
      ) : null}

      <StageTabs
        value={filter.stage}
        onChange={(v) => setFilter((f) => ({ ...f, stage: v }))}
      />

      {/* 学校查询模块（上移，先于档案，聚焦首屏查询） */}
      <div className="mt-4">
        <SchoolFilters
          state={filter}
          districts={districts}
          onKeywordChange={(v) => setFilter((f) => ({ ...f, keyword: v }))}
          onDistrictChange={(v) => setFilter((f) => ({ ...f, district: v }))}
          onOwnershipChange={(v) => setFilter((f) => ({ ...f, ownership: v }))}
          onVerificationChange={(v) =>
            setFilter((f) => ({ ...f, verification: v }))
          }
          onClear={() => setFilter(emptyFilter())}
        />
      </div>

      {/* 学校列表上方：内部预览说明（P0 明确标注） */}
      <div className="mt-4 rounded-xl border border-[#ede8e0] bg-[#f7f3ec] px-5 py-3 text-sm leading-relaxed text-[#4b5563]">
        <p className="font-semibold text-[#10233d]">当前展示西安市多区义务教育阶段官方学区划分与中考录取公开数据，持续核验中，不代表西安市完整学校名单。</p>
        <p className="mt-1">资料以官方公开来源为准，不构成录取或择校建议。</p>
      </div>

      {/* 结果计数 + 一键清除筛选 */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-[#6b7280]">
          {isFilterActive ? (
            <>
              已筛选出{" "}
              <span className="font-semibold text-[#10233d]">{results.length}</span>{" "}
              所预览学校
            </>
          ) : (
            <>
              已核验{" "}
              <span className="font-semibold text-[#10233d]">{results.length}</span>{" "}
              所预览学校
            </>
          )}
        </p>
        {isFilterActive ? (
          <button
            type="button"
            onClick={() => setFilter(emptyFilter())}
            className="rounded-lg border border-[#e5e7eb] bg-white px-3 py-1.5 text-xs font-medium text-[#b94f38] hover:border-[#b94f38]"
          >
            一键清除筛选
          </button>
        ) : null}
      </div>

      {compareMessage ? (
        <p
          role="status"
          aria-live="polite"
          className="mt-2 rounded-lg border border-[#f0d9cc] bg-[#fdf2ee] px-4 py-2 text-sm text-[#b94f38]"
        >
          {compareMessage}
        </p>
      ) : null}

      {results.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-[#e5e7eb] bg-white px-6 py-12 text-center">
          {demoMode ? (
            <>
              <p className="text-base font-semibold text-[#10233d]">没有符合条件的机构</p>
              <p className="mt-2 text-sm text-[#6b7280]">
                试着调整阶段、区域或关键词，或点击「清空筛选」重新查看示例数据。
              </p>
            </>
          ) : (
            <p className="text-base font-semibold text-[#10233d]">
              学校资料正在核验中，暂未开放公开查询。
            </p>
          )}
        </div>
      ) : (
        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
          {results.map((s) => (
            <SchoolCard
              key={s.id}
              school={s}
              onViewDetails={openDetail}
              inCompare={isInCompare(compareIds, s.id)}
              compareFull={compareFull}
              onToggleCompare={onToggleCompare}
            />
          ))}
        </div>
      )}

      {/* 家庭成长档案（后置，默认收起，减少首屏说明文字） */}
      <div className="mt-8">
        <button
          type="button"
          onClick={() => setShowProfilePanel((v) => !v)}
          aria-expanded={showProfilePanel}
          className="rounded-lg border border-[#b94f38] bg-[#fdf2ee] px-4 py-2 text-sm font-semibold text-[#b94f38] hover:shadow-sm"
        >
          {showProfilePanel ? "收起家庭成长档案" : "建立家庭成长档案"}
        </button>
      </div>

      {showProfilePanel ? (
        <FamilyProfilePanel
          profile={familyProfile}
          onChange={setFamilyProfile}
          onGenerate={handleGenerateSummary}
          summary={generatedSummary}
          onClear={handleClearProfile}
          onApplyFilters={handleApplySuggestedFilters}
          appliedFilterNote={appliedFilterNote}
        />
      ) : null}

      {/* 底部占位：避免对比栏遮挡最后一张卡片 */}
      {compareSchools.length > 0 ? <div className="h-32" /> : null}

      <SchoolDetailModal
        school={selectedSchool}
        open={modalOpen}
        onClose={closeDetail}
      />

      <SchoolCompareBar
        selected={compareSchools}
        onRemove={onRemoveCompare}
        onClear={onClearCompare}
        // 打开对比时关闭详情弹窗（同一时刻只开一个弹窗）。
        onOpen={() => {
          setCompareRequested(true);
          setDetailRequested(false);
          setSelectedSchool(null);
        }}
      />

      <SchoolCompareModal
        schools={compareSchools}
        open={compareOpen}
        onClose={() => setCompareRequested(false)}
        onRemove={onRemoveCompare}
      />

      {/* 构建版本可追溯（正式公开审计要求） */}
      {buildVersion ? (
        <p className="mt-8 text-center text-xs text-[#9ca3af]">
          构建版本 {buildVersion}
        </p>
      ) : null}
    </section>
  );
}

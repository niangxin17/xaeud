import type { Metadata } from "next";
import type { GrowthSchool } from "../lib/growth-schools";
import GrowthExplorer from "./components/GrowthExplorer";
import EducationJourney from "./components/EducationJourney";

export const metadata: Metadata = {
  title: "长安成长地图｜西安幼儿园/小学/初中学校信息查询",
  description:
    "从幼儿园到升学，为西安家庭建立可持续更新的成长规划。学校、招生与政策信息以教育主管部门和学校最新公开信息为准。",
};

export default function GrowthPage() {
  return (
    <main className="mx-auto max-w-[1080px] px-5 py-10">
      {/* Hero */}
      <section className="rounded-2xl border border-[#ede8e0] bg-white px-6 py-9 sm:px-10 sm:py-12">
        <p className="mb-3 text-sm font-semibold text-[#b94f38]">成长规划</p>
        <h1 className="text-3xl font-bold text-[#10233d] sm:text-4xl">
          长安成长地图
        </h1>
        <p className="mt-3 max-w-2xl text-base leading-relaxed text-[#4b5563]">
          从幼儿园到升学，为西安家庭建立可持续更新的成长规划。
        </p>
      </section>

      {/* 全周期教育路线 + 中考系统真实入口（不复制中考算法） */}
      <section className="mt-6">
        <EducationJourney />
      </section>

      {/* 学校发现（生产展示闸门） */}
      {/*
        真实数据源尚未正式接入公开页面：
        - 生产（默认）：verifiedSchools=[]，GrowthExplorer 经 getVisibleGrowthSchools 展示「未公开」空状态，绝不展示演示机构。
        - 预览开关：NEXT_PUBLIC_GROWTH_PREVIEW=1 时，GrowthExplorer 内部装载 12 条已通过
          《18-人工发布清单》人工审批的预览数据（growth-verified-schools.ts）并标注「预览数据」横幅；
          关闭开关即恢复「未公开」。该开关独立于演示开关（NEXT_PUBLIC_GROWTH_DEMO_MODE），二者不可互相替代。
        - 演示机构：仅 NEXT_PUBLIC_GROWTH_DEMO_MODE=1 时由 GrowthExplorer 内部加载。
      */}
      <GrowthExplorer verifiedSchools={[] as GrowthSchool[]} />

      {/* 真实性声明 */}
      <section className="mt-10">
        <div className="rounded-xl border border-[#ede8e0] bg-[#f7f3ec] p-5">
          <h2 className="text-sm font-bold text-[#10233d]">真实性声明</h2>
          <p className="mt-2 text-sm leading-relaxed text-[#4b5563]">
            学校、招生与政策信息以教育主管部门和学校最新公开信息为准；平台不承诺录取结果。本页正式展示的为官方公开学校资料；演示机构仅在演示模式下出现，不代表任何真实学校。
          </p>
        </div>
      </section>
    </main>
  );
}

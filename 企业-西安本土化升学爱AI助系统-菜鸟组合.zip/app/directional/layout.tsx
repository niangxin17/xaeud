import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "定向生计划",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

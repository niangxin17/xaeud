"use client";

import { useRef, useState } from "react";
import Link from "next/link";
import {
  DIRECTIONAL_DISTRICTS,
  DIRECTIONAL_TOTAL_SCHOOLS,
  type DirectionalDistrict,
} from "../lib/directional-schools";

// 官方通知（西安市教育局 2026-07-16 发布）
const NOTICE_URL =
  "https://edu.xa.gov.cn/xwzx/tzgg/2077570654019817474.html";

const STEPS = [
  {
    n: 1,
    title: "找到孩子就读的初中",
    desc: "在计划表的「生源初中」一列里，找到孩子目前就读的初中学校。定向生名额是按初中分校分配的，不是按全区平均。",
  },
  {
    n: 2,
    title: "横向看对应的高中",
    desc: "从你初中所在行向右看，哪些高中对这一初中有定向名额——不同初中对应的高中和名额数通常不一样。",
  },
  {
    n: 3,
    title: "读名额数，结合分数判断",
    desc: "记下名额数，再结合孩子的预估分数判断「冲 / 稳 / 保」，决定把唯一的一所定向志愿报给哪所高中。",
  },
];

export default function DirectionalPage() {
  // 默认选中雁塔区，避免首屏空状态、重点不突出
  const [active, setActive] = useState("yanta");
  const current: DirectionalDistrict =
    DIRECTIONAL_DISTRICTS.find((d) => d.value === active) ||
    DIRECTIONAL_DISTRICTS[3];

  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const openSearch = () => {
    setSearchOpen(true);
    setTimeout(() => inputRef.current?.focus(), 60);
  };
  const onSearchBlur = () => {
    if (!query.trim()) setSearchOpen(false);
  };

  const list = current.schools.filter(
    (s) =>
      !query.trim() ||
      s.name.includes(query.trim()) ||
      s.code.includes(query.trim())
  );
  const withQuota = current.schools.filter((s) => s.quota != null).length;

  return (
    <main className="min-h-screen bg-[#faf7f2] text-[#1f2a37]">
      {/* ============ 首屏：家长决策引导（重设计色） ============ */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#0f2742] via-[#163a5f] to-[#1d4a6b] px-5 pb-16 pt-12 text-white sm:pt-16">
        {/* 装饰：右上角石榴色光晕 */}
        <div
          aria-hidden
          className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-[#e2683f]/20 blur-3xl"
        />
        {/* 装饰：底部城墙垛口剪影 */}
        <svg
          aria-hidden
          className="absolute bottom-0 left-0 w-full text-white/10"
          height="28"
          viewBox="0 0 1200 28"
          preserveAspectRatio="none"
        >
          <path
            fill="currentColor"
            d="M0 28V14h40v14h40V14h40v14h40V14h40v14h40V14h40v14h40V14h40v14h40V14h40v14h40V14h40v14h40V14h40v14h40V14h40v14h40V14h40v14h40V14h40v14h40V14h40v14H0z"
          />
        </svg>

        <div className="relative mx-auto max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full bg-[#e2683f] px-3 py-1 text-xs font-bold tracking-wide text-white">
            2026 西安中考 · 定向生计划
          </span>
          <h1 className="mt-4 text-[30px] font-black leading-[1.2] sm:text-[40px]">
            定向生怎么填？
            <span className="mt-1 block text-[#f0b96b]">
              先找到初中，再看能报哪所高中
            </span>
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-[#cdd8e6] sm:text-base">
            定向生名额按孩子就读的初中分配，不同初中对应的高中和计划数不一样。
            志愿每名考生限报 1 所。下面按区县查看「有定向计划的高中」，
            并打开教育局官方计划表，找到你初中对应的名额。
          </p>

          {/* 三条核心事实 */}
          <div className="mt-7 grid gap-3 sm:grid-cols-3">
            {[
              { k: "按初中分配", d: "名额分校到就读初中，不是全区平均" },
              { k: "限报 1 所", d: "定向生志愿每名考生只能填 1 所学校" },
              { k: "以官方为准", d: "资格、计划、录取结果以官方系统为准" },
            ].map((f) => (
              <div
                key={f.k}
                className="rounded-2xl bg-white/10 p-4 ring-1 ring-white/15 backdrop-blur"
              >
                <div className="text-lg font-black text-[#f0b96b]">{f.k}</div>
                <div className="mt-1 text-xs text-[#bcc8d8]">{f.d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-3xl px-5 py-8">
        {/* 重点提示 */}
        <div className="rounded-2xl border-l-4 border-[#e2683f] bg-[#fdeee9] px-5 py-4">
          <div className="text-base font-black text-[#c0432a]">
            先看资格，再看名额，只能选一所
          </div>
          <p className="mt-1.5 text-sm leading-relaxed text-[#8a4a3c]">
            定向生有资格要求（如连续学籍等），先确认孩子是否具备资格；再看对应初中的定向名额；
            最终只能填报 1 所定向志愿。资格与名额以就读初中公布、教育局审核为准。
          </p>
        </div>

        {/* ============ 各区县有定向计划的高中 ============ */}
        <section className="mt-8">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-xl font-black">各区县有定向计划的高中</h2>
              <p className="mt-1 text-sm text-[#6b7280]">
                选择区县，查看该区县参与定向招生的高中（共 {DIRECTIONAL_TOTAL_SCHOOLS} 所·全市城六区）。
              </p>
            </div>

            {/* 放大镜搜索：点开输入变长 */}
            <div
              className={
                "flex items-center overflow-hidden rounded-full bg-white ring-1 ring-[#e7ddcf] transition-all duration-300 " +
                (searchOpen ? " w-full sm:w-64" : " w-11")
              }
            >
              <button
                type="button"
                onClick={openSearch}
                aria-label="搜索高中"
                className="flex h-11 w-11 shrink-0 items-center justify-center text-[#9b8579]"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                  <circle cx="11" cy="11" r="7" />
                  <path d="M21 21l-4.3-4.3" />
                </svg>
              </button>
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onBlur={onSearchBlur}
                placeholder="搜索高中名称 / 代码"
                className="h-11 w-full bg-transparent pr-4 text-sm text-[#1f2a37] outline-none placeholder:text-[#b6a89a]"
              />
            </div>
          </div>

          {/* 7 个区县切换 */}
          <div className="mt-4 flex flex-wrap gap-2">
            {DIRECTIONAL_DISTRICTS.map((d) => (
              <button
                key={d.value}
                type="button"
                onClick={() => {
                  setActive(d.value);
                  setQuery("");
                }}
                className={
                  "rounded-full px-4 py-2 text-sm font-bold transition " +
                  (active === d.value
                    ? "bg-[#163a5f] text-white shadow-sm"
                    : "bg-white text-[#1f2a37] ring-1 ring-[#e7ddcf] hover:bg-[#f3ece1]")
                }
              >
                {d.label}
              </button>
            ))}
          </div>

          {/* 当前区县卡片 + 高中名单 */}
          <div className="mt-4 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-lg font-black">{current.label}</div>
                <div className="mt-0.5 text-xs text-[#8a93a3]">
                  {current.label}省级标准化高中定向生分校生源计划
                </div>
              </div>
              <div className="flex gap-2">
                <a
                  href={current.pdf}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-xl bg-[#e2683f] px-4 py-2.5 text-sm font-bold text-white transition hover:bg-[#cf5535]"
                >
                  查看官方计划表（PDF）
                </a>
                <Link
                  href="/checkout?plan=match_29_9"
                  className="rounded-xl bg-[#163a5f] px-4 py-2.5 text-sm font-bold text-white transition hover:bg-[#0f2742]"
                >
                  解锁初中定向招生高中名单
                </Link>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between">
              <div className="text-sm font-bold text-[#1f2a37]">
                有定向计划的高中
                <span className="ml-1 text-[#e2683f]">{current.schools.length}</span> 所
                <span className="ml-1 font-normal text-[#9b8579]">
                  · 已公布名额 {withQuota} 所
                </span>
                {query.trim() && (
                  <span className="ml-1 font-normal text-[#9b8579]">
                    · 匹配 {list.length} 所
                  </span>
                )}
              </div>
            </div>

            {list.length === 0 ? (
              <div className="mt-4 rounded-xl bg-[#faf7f2] px-4 py-6 text-center text-sm text-[#9b8579]">
                没有匹配「{query}」的高中，换个关键词试试。
              </div>
            ) : (
              <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
                {list.map((s) => (
                  <div
                    key={s.code}
                    className="flex flex-col rounded-xl border border-[#efe7da] bg-[#faf7f2] px-3 py-2.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="text-sm font-semibold leading-snug text-[#1f2a37]">
                        {s.name ? (
                          s.name
                        ) : (
                          <span className="text-[#b08a7d]">校名待核验</span>
                        )}
                      </div>
                      {s.quota != null ? (
                        <span className="shrink-0 rounded-md bg-[#163a5f] px-1.5 py-0.5 text-[11px] font-bold text-white">
                          定向 {s.quota} 人
                        </span>
                      ) : (
                        <span className="shrink-0 rounded-md bg-[#ece3d6] px-1.5 py-0.5 text-[11px] font-medium text-[#9b8579]">
                          名额待更新
                        </span>
                      )}
                    </div>
                    <div className="mt-1 text-[11px] text-[#a89a8c]">代码 {s.code}</div>
                  </div>
                ))}
              </div>
            )}
            <p className="mt-3 text-[11px] leading-relaxed text-[#b0a89c]">
              名单取自官方计划表列头中的学校代码（即该区县参与定向招生的高中）；校名依同体系官方代码表映射。
              定向名额直接套用数据库（2026 最新抓取），为该校定向总计划；各初中分校具体名额以官方计划表（PDF）为准。最终以官方系统为准。
            </p>
          </div>
        </section>

        {/* 家长如何阅读官方计划矩阵表：3 步 */}
        <section className="mt-10">
          <h2 className="text-xl font-black">家长如何看懂这份计划表（3 步）</h2>
          <p className="mt-1 text-sm text-[#6b7280]">
            官方计划表是一张「初中 × 高中」的矩阵，照这 3 步读就不会乱。
          </p>
          <div className="mt-4 space-y-3">
            {STEPS.map((s) => (
              <div
                key={s.n}
                className="flex gap-4 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#163a5f] text-sm font-black text-white">
                  {s.n}
                </div>
                <div>
                  <div className="text-base font-bold">{s.title}</div>
                  <p className="mt-1 text-sm leading-relaxed text-[#4b5563]">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs text-[#9ca3af]">
            提醒：名额是分校到初中的，不能把「全区计划」当成「你初中的名额」。
          </p>
        </section>

        {/* 看完之后下一步 */}
        <section className="mt-10">
          <h2 className="text-xl font-black">看完计划表，下一步做什么</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Link
              href="/"
              className="block rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)] transition hover:-translate-y-0.5 hover:shadow-[0_18px_40px_rgba(16,35,61,.1)]"
            >
              <div className="text-base font-bold">① 先做分数定位</div>
              <p className="mt-1.5 text-sm leading-relaxed text-[#4b5563]">
                输入成绩，预估能上哪些高中，再拿它和计划表里的定向名额对照，判断冲 / 稳 / 保。
              </p>
              <div className="mt-3 text-sm font-bold text-[#e2683f]">去首页做志愿模拟 →</div>
            </Link>
            <Link
              href="/filing"
              className="block rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)] transition hover:-translate-y-0.5 hover:shadow-[0_18px_40px_rgba(16,35,61,.1)]"
            >
              <div className="text-base font-bold">② 准备官方填报</div>
              <p className="mt-1.5 text-sm leading-relaxed text-[#4b5563]">
                熟悉西安市中考官方填报系统的界面与流程，把想报的定向志愿提前想清楚。
              </p>
              <div className="mt-3 text-sm font-bold text-[#e2683f]">看官方填报准备 →</div>
            </Link>
          </div>
        </section>

        {/* 数据来源与声明 */}
        <p className="mt-10 border-t border-[#e7ddcf] pt-5 text-xs leading-relaxed text-[#9ca3af]">
          数据来源：西安市教育局 2026-07-16《关于印发 2026 年城六区省级标准化高中定向生分学校生源计划的通知》。
          本页列出各区县「有定向计划的高中」名单（取自官方计划表列头学校代码，校名依官方代码表映射），
          不展示未经人工核验的名额数字；最终资格、计划与录取结果以官方系统为准。
        </p>
      </div>
    </main>
  );
}

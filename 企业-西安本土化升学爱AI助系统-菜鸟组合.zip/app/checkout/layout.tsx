import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "升级套餐",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

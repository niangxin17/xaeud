"use client";

import { Suspense, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { track } from "../analytics";
import { saveProfileLock, resetSimUsed } from "../lib/profile-lock";
import type { PackageId } from "../lib/entitlements";

import { SharePanel } from "../components/SharePanel";

// 付费套餐（方案第九/十六节）：99 / 29.9 / 199 / 599 四档；价格权威以服务端 PLAN_PRICES 为准
const PLAN_META: Record<string, { name: string; price: number; tag: string; desc: string }> = {
  upgrade_99: { name: "升学会员", price: 99, tag: "入门推荐", desc: "解锁参考学校推荐 + 志愿方案生成 + 位次/概率分析（核心查询能力）" },
  match_29_9: { name: "冲稳保分析", price: 29.9, tag: "最受欢迎", desc: "冲刺/稳妥/保底推荐 + 升学概率 + 3 次模拟填报" },
  planning_199: { name: "AI 志愿规划", price: 199, tag: "不限次", desc: "不限次模拟 + 匹配度/压力/三年规划/985·211 预测" },
  review_599: { name: "老师复审", price: 599, tag: "含人工", desc: "199 全部权益 + 老师人工复审与最终方案确认" },
};

// 区县值 → 中文标签（用于确认页展示锁定资料）
const DISTRICT_LABELS: Record<string, string> = {
  xincheng: "新城区", beilin: "碑林区", lianhu: "莲湖区", yanta: "雁塔区",
  weiyang: "未央区", bashan: "灞桥区", xixian: "西咸新区", changan: "长安区",
};

function getSharePricing(friendCount: number) {
  const count = Math.max(0, Math.floor(friendCount));
  if (count >= 10) {
    return { price: 0, discount: 29.9, nextTarget: null, milestone: "已助力 10 人，完整方案已免费" };
  }
  if (count >= 3) {
    return { price: 9.9, discount: 20, nextTarget: 10 - count, milestone: "已助力 3 人，立减 20 元" };
  }
  if (count >= 1) {
    return { price: 19.9, discount: 10, nextTarget: 3 - count, milestone: `已助力 1 人，再邀 ${3 - count} 位同学，立减 20 元` };
  }
  return { price: 29.9, discount: 0, nextTarget: 1, milestone: "邀请 1 位同学，立减 10 元" };
}

// 支付成功后锁定资料 + 初始化模拟次数（方案第五、六节）
function lockProfile(packageId: string, draft: any) {
  if (!draft) return;
  saveProfileLock({
    score: Number(draft.score) || 0,
    rank: String(draft.rank || ""),
    district: draft.district || "",
    juniorSchool: draft.juniorSchool || "",
    directionalSchool: draft.directionalSchool || undefined,
    packageId: packageId as PackageId,
    lockedAt: new Date().toISOString(),
  });
  resetSimUsed(packageId as PackageId);
}

function isWechatBrowser() {
  return typeof navigator !== "undefined" && /micromessenger/i.test(navigator.userAgent);
}
// 支付宝按钮显示条件：仅「手机浏览器 且 非微信内」才同时出现微信+支付宝。
// - 微信内（手机）：只能微信（JSAPI）
// - 手机浏览器：微信 + 支付宝（手机网站支付）
// - PC 端（含 PC 桌面微信、普通 PC 浏览器）：只能微信（扫码支付）
function showAlipay() {
  return isMobile() && !isWechatBrowser();
}
function isMobile() {
  return typeof navigator !== "undefined" && /mobile|android|iphone|ipod|harmony/i.test(navigator.userAgent);
}
function getCookie(name: string) {
  if (typeof document === "undefined") return "";
  const m = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
  return m ? decodeURIComponent(m[2]) : "";
}
// 把权益以 {orderId, planId, ts} 形式持久化，报告页会回服务端校验 orderId 是否真已支付
function grantEntitlement(orderId: string, planId: string) {
  try {
    const arr = JSON.parse(localStorage.getItem("ly_paid_plans") || "[]");
    const exists = Array.isArray(arr) && arr.find((e: any) => e && e.orderId === orderId);
    if (!exists) arr.push({ orderId, planId, ts: Date.now() });
    localStorage.setItem("ly_paid_plans", JSON.stringify(arr));
  } catch {}
}

// 付费成功后自动跳回首页（首页会在已付费且有分数/区县草稿时自动展开结果）
function scheduleGoHome(delay = 1600) {
  window.setTimeout(() => {
    window.location.href = "/";
  }, delay);
}

function LockRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-[#10233d]/10 pb-2 last:border-0 last:pb-0">
      <dt className="text-xs text-[#778494]">{label}</dt>
      <dd className="text-sm font-bold text-[#10233d]">{value}</dd>
    </div>
  );
}

function invokeWxPay(payParams: any): Promise<void> {
  return new Promise((resolve, reject) => {
    const doIt = () => {
      // @ts-ignore
      if (typeof WeixinJSBridge !== "undefined") {
        // @ts-ignore
        WeixinJSBridge.invoke(
          "getBrandWCPayRequest",
          {
            appId: payParams.appId,
            timeStamp: payParams.timeStamp,
            nonceStr: payParams.nonceStr,
            package: payParams.package,
            signType: payParams.signType,
            paySign: payParams.paySign,
          },
          (r: any) => {
            if (r.err_msg === "get_brand_wcpay_request:ok") resolve();
            else reject(new Error(r.err_msg || "支付取消"));
          }
        );
      } else if (typeof (window as any).wx !== "undefined" && (window as any).wx.chooseWXPay) {
        (window as any).wx.chooseWXPay({ ...payParams, success: () => resolve(), cancel: () => reject(new Error("cancel")), fail: (e: any) => reject(new Error(e.errMsg || "fail")) });
      } else {
        reject(new Error("当前环境不支持微信内支付，请截图反馈"));
      }
    };
    // @ts-ignore
    if (typeof WeixinJSBridge === "undefined") {
      document.addEventListener("WeixinJSBridgeReady", doIt, false);
    } else doIt();
  });
}

function CheckoutInner() {
  const params = useSearchParams();
  const [id, setId] = useState("match_29_9");
  const [channel, setChannel] = useState<"wechat" | "alipay">(showAlipay() ? "alipay" : "wechat");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [qr, setQr] = useState("");
  const [paid, setPaid] = useState(false);
  const [sandbox, setSandbox] = useState(false);
  const [shareFriends, setShareFriends] = useState(0);
  const [draft, setDraft] = useState<any>(null);
  const [confirmed, setConfirmed] = useState(false);
  const pollRef = useRef<number | null>(null);
  const plan = PLAN_META[id] || PLAN_META.match_29_9;

  useEffect(() => {
    setShareFriends(Number(window.localStorage.getItem("ly_share_friends") || 0));
    try {
      const raw = localStorage.getItem("ly_profile_draft");
      if (raw) setDraft(JSON.parse(raw));
    } catch {}
    // 静态导出下 useSearchParams 预渲染时为空，需从真实 URL 同步套餐（避免下错单）
    try {
      const p = new URLSearchParams(window.location.search).get("plan");
      if (p && p !== id) setId(p);
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 微信内浏览器下单前确保拿到 openid（OAuth 跳转回来后带上 cookie）
  useEffect(() => {
    if (isWechatBrowser() && !getCookie("ly_wx_openid")) {
      window.location.href = "/api/wechat/oauth/start?redirect=" + encodeURIComponent(window.location.href);
    }
  }, []);

  // 支付宝/微信 return 回来后轮询订单
  useEffect(() => {
    const oid = params.get("orderId");
    if (params.get("paid") === "1" && oid) {
      setOrderId(oid);
      pollOrder(oid);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const sharing = getSharePricing(shareFriends);
  const hasShareBenefit = id === "match_29_9";
  const checkoutPrice = hasShareBenefit ? sharing.price : plan.price;
  const displayPrice = hasShareBenefit
    ? checkoutPrice === 0
      ? "免费"
      : `${checkoutPrice.toFixed(1)} 元`
    : `${plan.price.toFixed(1)} 元`;

  function pollOrder(oid: string) {
    if (pollRef.current) window.clearInterval(pollRef.current);
    pollRef.current = window.setInterval(async () => {
      try {
        // 主动查单：直接问微信/支付宝，不依赖回调是否准时到达，2 秒内自动识别付款
        const r = await fetch("/api/orders/" + oid + "/query", { method: "POST" });
        const d = await r.json();
        if (d.ok && d.status === "paid") {
          if (pollRef.current) window.clearInterval(pollRef.current);
          lockProfile(id, draft);
          grantEntitlement(oid, id);
          setPaid(true);
          setMessage("支付成功，已解锁！");
          scheduleGoHome();
        }
      } catch {}
    }, 2000);
    window.setTimeout(() => {
      if (pollRef.current) window.clearInterval(pollRef.current);
    }, 120000);
  }

  async function createOrder() {
    if (!draft || !confirmed) {
      setMessage("请先核对锁定资料并勾选确认框后再支付。");
      return;
    }
    setBusy(true);
    setMessage("正在创建订单…");
    // 非「手机浏览器+非微信」环境只有微信支付通道可用，强制锁定
    if (!showAlipay() && channel !== "wechat") setChannel("wechat");
    const payChannel = !showAlipay() ? "wechat" : channel;
    track("order_created", { planId: id, channel: payChannel, shareFriends });
    try {
      const sessionId = localStorage.getItem("ly_sid") || undefined;
        const openid = isWechatBrowser() ? getCookie("ly_wx_openid") : "";
        const response = await fetch("/api/orders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ planId: id, channel: payChannel, sessionId, shareFriends, amount: checkoutPrice, openid, mobile: isMobile() }),
        });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "订单创建失败");
      setOrderId(data.orderId);

      if (data.free) {
        lockProfile(id, draft);
        grantEntitlement(data.orderId, id);
        setPaid(true);
        setMessage("免费解锁成功！");
        return;
      }
      if (!data.paymentReady) {
        setSandbox(true);
        setMessage("支付通道尚未配置（沙盒模式）：" + (data.reason || "") + "。订单已创建，配置凭证后即可正式收款。");
        return;
      }

      if (data.channel === "wechat" && data.method === "jsapi") {
        pollOrder(data.orderId); // 唤起前先开轮询，支付完成回到页面即自动识别
        try {
          await invokeWxPay(data.payParams);
          setMessage("已在微信中唤起支付，请完成支付…");
        } catch (e: any) {
          setMessage("唤起微信支付失败：" + (e.message || "") + "（可改用扫码支付）");
        }
        return;
      }
      if (data.channel === "wechat" && data.method === "native") {
        setQr(data.qrDataUrl);
        pollOrder(data.orderId);
        setMessage("请使用微信扫码完成支付，支付成功后自动解锁。");
        return;
      }
      if (data.channel === "alipay" && data.redirectUrl) {
        window.location.href = data.redirectUrl;
        return;
      }
      setMessage("订单已创建，请按提示完成支付。");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "订单创建失败");
    } finally {
      setBusy(false);
    }
  }

  function sandboxUnlock() {
    try { sessionStorage.setItem("ly_demo_unlock", "1"); } catch {}
    lockProfile(id, draft);
    setPaid(true);
    setMessage("（沙盒演示）已本地解锁，配置真实支付凭证后将由服务器确认。");
  }

  // 用户已支付但状态未刷新时，手动向服务端确认一次
  async function recheckNow() {
    if (!orderId) return;
    setMessage("正在向服务器确认支付状态…");
    try {
      const r = await fetch("/api/orders/" + orderId + "/query", { method: "POST" });
      const d = await r.json();
      if (d.ok && d.status === "paid") {
        if (pollRef.current) window.clearInterval(pollRef.current);
        lockProfile(id, draft);
        grantEntitlement(orderId, id);
        setPaid(true);
        setMessage("支付成功，已解锁！");
        scheduleGoHome();
        return;
      }
      setMessage("服务器暂未收到支付成功通知：" + (d.detail || d.error || "请稍后再试"));
      pollOrder(orderId);
    } catch (e: any) {
      setMessage("查询失败：" + (e.message || "网络异常"));
      pollOrder(orderId);
    }
  }

  return (
    <main className="min-h-screen bg-[#f7f3ec] px-5 py-8 text-[#10233d]">
      <div className="mx-auto max-w-2xl">
        <Link href="/" className="text-sm font-bold">← 返回首页</Link>
        <section className="mt-8 rounded-3xl bg-white p-7 shadow-[0_18px_50px_rgba(16,35,61,.08)]">
          <span className="text-xs font-bold tracking-[.16em] text-[#b94f38]">ORDER YOUR PLAN</span>
          <h1 className="mt-3 text-3xl font-black">确认你的升学服务</h1>

          {!paid && (
            <div className="mt-6 grid grid-cols-2 gap-2 md:grid-cols-4">
              {Object.entries(PLAN_META).map(([pid, m]) => (
                <button
                  key={pid}
                  type="button"
                  onClick={() => { setId(pid); setConfirmed(false); }}
                  className={id === pid ? "rounded-2xl border-2 border-[#b94f38] bg-[#fff7f2] p-3 text-left transition" : "rounded-2xl border border-[#10233d]/15 p-3 text-left transition hover:border-[#10233d]/30"}
                >
                  <span className="block text-[0.65rem] font-bold text-[#b94f38]">{m.tag}</span>
                  <span className="mt-1 block text-sm font-black text-[#10233d]">{m.name}</span>
                  <span className="mt-1 block text-sm font-bold text-[#b94f38]">¥{m.price}</span>
                </button>
              ))}
            </div>
          )}

          <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-2">
            <div className="rounded-2xl border border-[#ede8e0] bg-white p-5">
              <div className="text-xs font-bold tracking-[.16em] text-[#b94f38]">已选择</div>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <h2 className="text-2xl font-black text-[#10233d]">{plan.name}</h2>
                {id === "match_29_9" && (
                  <span className="rounded-full bg-[#e5f0ee] px-2.5 py-1 text-xs font-bold text-[#1f4a44]">
                    定向生匹配
                  </span>
                )}
              </div>
              <p className="mt-2 text-sm leading-relaxed text-[#667487]">{plan.desc}</p>
              <div className="mt-4 flex items-end gap-2">
                <strong className="text-3xl font-black text-[#b94f38]">{displayPrice}</strong>
                {hasShareBenefit && sharing.discount > 0 && (
                  <span className="mb-1 rounded-full bg-[#fff7f2] px-2 py-0.5 text-xs font-bold text-[#b94f38]">
                    已省 ¥{sharing.discount.toFixed(1)}
                  </span>
                )}
              </div>
              {hasShareBenefit && (
                <p className="mt-3 text-xs text-[#4e8b84]">已邀请 {shareFriends} 位同学，{sharing.milestone}</p>
              )}
            </div>
            {hasShareBenefit && (
              <div className="rounded-2xl border border-[#ede8e0] bg-white p-5">
                <SharePanel
                  originalPrice={plan.price}
                  score={draft?.score}
                  district={draft?.district}
                  category="平衡推荐"
                  onCountChange={setShareFriends}
                />
              </div>
            )}
          </div>

          {!paid && draft && (
            <div className="mt-6 rounded-2xl border border-[#10233d]/15 bg-[#f7f3ec] p-5">
              <div className="text-xs font-bold tracking-[.16em] text-[#b94f38]">支付前资料锁定</div>
              <p className="mt-2 text-sm text-[#667487]">以下信息将随本套餐锁定，支付后本套餐内不可修改，请核对无误。</p>
              <dl className="mt-3 space-y-2">
                <LockRow label="中考分数" value={`${draft.score ?? 0} 分`} />
                <LockRow label="中考位次" value={draft.rank ? `${draft.rank} 名` : "未填"} />
                <LockRow label="所在区县" value={DISTRICT_LABELS[draft.district] || draft.district || "未填"} />
                <LockRow label="所在初中" value={draft.juniorSchool || "未填"} />
                <LockRow label="定向高中" value={draft.directionalSchool || "未选择定向生"} />
              </dl>
              <label className="mt-4 flex cursor-pointer items-start gap-2.5 text-sm text-[#10233d]">
                <input
                  type="checkbox"
                  checked={confirmed}
                  onChange={(e) => setConfirmed(e.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded border-[#cbb3aa] accent-[#b94f38]"
                />
                <span>我已核对以上信息，确认支付后本套餐内不可修改。</span>
              </label>
            </div>
          )}

          {!paid && !draft && (
            <div className="mt-6 rounded-2xl bg-[#fff7f2] p-5 text-sm leading-6 text-[#b94f38]">
              请先返回首页填写分数与区县资料，再选择套餐购买。
              <Link href="/" className="ml-1 font-bold underline">返回首页填写</Link>
            </div>
          )}

          {!paid && (
            <div className="mt-6">
              <div className="mb-3 text-sm font-bold">选择支付方式</div>
              <div className={showAlipay() ? "grid grid-cols-2 gap-3" : "grid grid-cols-1 gap-3"}>
                <button type="button" onClick={() => setChannel("wechat")} className={channel === "wechat" ? "rounded-2xl border border-[#4e8b84] bg-[#eef7f5] p-4 text-left" : "rounded-2xl border border-[#10233d]/15 p-4 text-left"}>
                  <b>微信支付</b>
                  <span className="mt-1 block text-xs text-[#667487]">{isWechatBrowser() ? "微信内直接调起" : "扫码支付"}</span>
                </button>
                {showAlipay() && (
                  <button type="button" onClick={() => setChannel("alipay")} className={channel === "alipay" ? "rounded-2xl border border-[#4e8b84] bg-[#eef7f5] p-4 text-left" : "rounded-2xl border border-[#10233d]/15 p-4 text-left"}>
                    <b>支付宝</b>
                    <span className="mt-1 block text-xs text-[#667487]">{isMobile() ? "手机网站支付" : "电脑网站支付"}</span>
                  </button>
                )}
              </div>
              {!showAlipay() && (
                <p className="mt-2 text-xs text-[#778494]">当前环境仅支持微信支付（扫码支付）。</p>
              )}
            </div>
          )}

          {!paid && (
            <button type="button" onClick={createOrder} disabled={busy || !draft || !confirmed} className="mt-7 w-full rounded-2xl bg-gradient-to-br from-[#b94f38] to-[#d4654a] px-5 py-4 font-bold text-white shadow-[0_4px_14px_rgba(185,79,56,.25)] transition-all duration-200 hover:-translate-y-[2px] hover:shadow-[0_8px_20px_rgba(185,79,56,.32)] active:scale-[0.96] disabled:translate-y-0 disabled:scale-100 disabled:cursor-not-allowed disabled:opacity-60 disabled:shadow-none">
              {busy
                ? "处理中…"
                : checkoutPrice === 0
                  ? "免费解锁"
                  : id === "upgrade_99"
                    ? "解锁会员 99元 查看推荐"
                    : id === "planning_199"
                      ? "志愿精准匹配 199元直接查看"
                      : id === "review_599"
                        ? "老师复核稳一点 599元联系老师"
                        : `不想分享，${checkoutPrice.toFixed(1)}元 直接查看`}
            </button>
          )}

          {qr && (
            <div className="mt-6 flex flex-col items-center rounded-2xl bg-[#f7f3ec] p-5">
              <div className="text-sm font-bold">微信扫码支付</div>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={qr} alt="微信支付二维码" className="mt-3 h-56 w-56 rounded-lg bg-white p-2" />
              <div className="mt-2 text-xs text-[#778494]">订单号：{orderId}</div>
            </div>
          )}

          {paid && (
            <div className="mt-6 rounded-2xl bg-[#e5f0ee] p-5 text-center">
              <div className="text-2xl">✅</div>
              <div className="mt-2 font-bold text-[#1f4a44]">支付成功，已解锁</div>
              <Link href="/downloads" className="mt-4 inline-block rounded-2xl bg-[#4e8b84] px-6 py-3 font-bold text-white">查看我的报告</Link>
            </div>
          )}

          {message && (
            <div className="mt-5 rounded-2xl bg-[#fff7f2] p-4 text-sm leading-6 text-[#667487]">
              {message}
              {orderId && !paid && <span className="mt-2 block text-xs">订单号：{orderId}</span>}
              {orderId && !paid && (
                <button type="button" onClick={recheckNow} className="mt-3 block w-full rounded-xl border border-[#4e8b84] px-4 py-2 text-xs font-bold text-[#1f4a44]">
                  我已支付，刷新状态
                </button>
              )}
              {sandbox && !paid && (
                <button type="button" onClick={sandboxUnlock} className="mt-3 block w-full rounded-xl border border-dashed border-[#b94f38] px-4 py-2 text-xs font-bold text-[#b94f38]">
                  （沙盒）本地演示解锁，预览完整方案
                </button>
              )}
            </div>
          )}

          <p className="mt-5 text-center text-xs text-[#778494]">支付信息由服务端处理，不会在浏览器保存商户密钥。</p>
        </section>
      </div>
    </main>
  );
}

export default function Checkout() {
  return (
    <Suspense>
      <CheckoutInner />
    </Suspense>
  );
}

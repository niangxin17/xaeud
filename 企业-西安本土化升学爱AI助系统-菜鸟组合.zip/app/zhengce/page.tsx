import {
  SOURCES,
  EXAM_2026,
  ADMISSION_SCHEME_2026,
  PLAN_2026,
  DIRECTIONAL_2026,
  PRIVATE_JUNIOR_2026,
  CONTROL_LINES,
  LINTONG_SCORE_ANCHORS,
  DATA_STATUS_NOTE,
} from "../lib/official-zhaosheng";

function Section({
  no,
  title,
  children,
}: {
  no: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mx-auto max-w-[1100px] px-5 py-8">
      <div className="mb-4 flex items-center gap-3">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[#10233d] text-sm font-bold text-white">
          {no}
        </span>
        <h2 className="text-[1.35rem] font-bold text-[#10233d]">{title}</h2>
      </div>
      <div className="border-l-2 border-[#ede8e0] pl-5">{children}</div>
    </section>
  );
}

function Badge({ kind, children }: { kind: "ok" | "pending"; children: React.ReactNode }) {
  const cls =
    kind === "ok"
      ? "bg-[#e7f6ec] text-[#1a7f43] border border-[#bfe6cd]"
      : "bg-[#fff4e5] text-[#b9742a] border border-[#f3d9af]";
  return (
    <span className={"inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold " + cls}>
      {children}
    </span>
  );
}

function SourceLink({ id }: { id: keyof typeof SOURCES }) {
  const s = SOURCES[id];
  return (
    <a
      href={s.url}
      target="_blank"
      rel="noopener noreferrer"
      className="text-[#b94f38] underline decoration-dotted underline-offset-2 hover:text-[#a23f29]"
    >
      {s.publisher} · {s.published}
    </a>
  );
}

function OwnershipTag({ o }: { o: string }) {
  if (o === "public") return <span className="rounded bg-[#e7f6ec] px-1.5 py-0.5 text-xs text-[#1a7f43]">公办</span>;
  if (o === "private") return <span className="rounded bg-[#fff4e5] px-1.5 py-0.5 text-xs text-[#b9742a]">民办</span>;
  if (o === "comprehensive")
    return <span className="rounded bg-[#eef6fa] px-1.5 py-0.5 text-xs text-[#1a5f7f]">综合高中班</span>;
  return <span className="rounded bg-[#f3f4f6] px-1.5 py-0.5 text-xs text-[#6b7280]">—</span>;
}

export default function ZhengcePage() {
  const p = PLAN_2026;
  return (
    <main className="min-h-screen bg-[#f7f3ec] pb-16 text-[#10233d]">
      {/* Hero */}
      <header className="bg-gradient-to-b from-[#10233d] to-[#1b3a5c] px-5 py-12 text-center text-white">
        <p className="mb-2 text-sm font-medium text-[#f4b740]">西安市教育局等官方渠道 · 已标注来源</p>
        <h1 className="mx-auto max-w-[720px] text-[1.9rem] font-bold leading-tight sm:text-[2.4rem]">
          2026 西安中招官方数据与政策
        </h1>
        <p className="mx-auto mt-4 max-w-[680px] text-[0.98rem] leading-relaxed text-white/80">
          招生计划、录取工作方案、志愿批次与同分规则、城六区录取控制线均来自西安市教育局公开发布文件（控制线已于 2026-07-17 公布）；
          各校具体录取分数线在录取结束前未公布，统一标注「待官方发布」。
        </p>
      </header>

      {/* 计分改革提醒 */}
      <section className="mx-auto mt-6 max-w-[1100px] px-5">
        <div className="flex items-start gap-3 rounded-2xl border border-[#cfe3ec] bg-[#eef6fa] p-4">
          <span className="mt-0.5 text-xl">📌</span>
          <p className="text-[0.95rem] leading-relaxed text-[#274a5e]">
            <b>2026 中考计分改革：</b>
            {EXAM_2026.note} 中考成绩及城六区录取控制线已于 <b>{EXAM_2026.scorePublish}</b> 公布（普高 492.0 / 体育艺术特长生 295.2 / 试点综合高中班 465.0）。
          </p>
        </div>
      </section>

      {/* 录取工作方案 */}
      <Section no="1" title="2026 录取工作方案要点">
        <div className="space-y-4 text-[0.95rem] leading-relaxed">
          <div>
            <b className="text-[#10233d]">志愿填报时间</b>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-[#4b5563]">
              <li>城六区：{ADMISSION_SCHEME_2026.fillWindow.chengliu}</li>
              <li>五区二县及西咸新区独立单元：{ADMISSION_SCHEME_2026.fillWindow.others}</li>
            </ul>
          </div>
          <div>
            <b className="text-[#10233d]">城六区普通高中志愿批次</b>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-[#4b5563]">
              {ADMISSION_SCHEME_2026.chengliuBatches.map((b) => (
                <li key={b.batch}>
                  <b>{b.batch}</b>：{b.desc}
                </li>
              ))}
              <li>{ADMISSION_SCHEME_2026.parallel}</li>
            </ul>
          </div>
          <div>
            <b className="text-[#10233d]">定向生（指标到校）政策</b>
            <p className="mt-1 text-[#4b5563]">{ADMISSION_SCHEME_2026.directionalPolicy}</p>
          </div>
          <div>
            <b className="text-[#10233d]">录取依据</b>
            <p className="mt-1 text-[#4b5563]">{ADMISSION_SCHEME_2026.admissionBasis}</p>
          </div>
          <div>
            <b className="text-[#10233d]">同分排序规则</b>
            <ol className="mt-1 list-decimal space-y-1 pl-5 text-[#4b5563]">
              {ADMISSION_SCHEME_2026.tieBreak.map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ol>
          </div>
          <div>
            <b className="text-[#10233d]">录取资格</b>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-[#4b5563]">
              <li>{ADMISSION_SCHEME_2026.eligibility.regular}</li>
              <li>{ADMISSION_SCHEME_2026.eligibility.provincial}</li>
            </ul>
          </div>
          <div>
            <b className="text-[#10233d]">照顾政策</b>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-[#4b5563]">
              {ADMISSION_SCHEME_2026.carePolicy.map((c, i) => (
                <li key={i}>{c}</li>
              ))}
            </ul>
          </div>
          <p className="pt-1 text-xs text-[#9ca3af]">
            来源：<SourceLink id="scheme2026" />
          </p>
        </div>
      </Section>

      {/* 招生计划 */}
      <Section no="2" title="2026 普通高中招生计划">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            <Stat label="全市普通高中" value={p.totalSenior.toLocaleString()} unit="人" />
            <Stat label="城六区公办普高" value={p.chengliuPublic.total.toLocaleString()} unit="人" />
            <Stat label="城六区民办普高" value={p.chengliuPrivate.total.toLocaleString()} unit="人" />
            <Stat label="五区二县公办普高" value={p.wuquErxianPublic.toLocaleString()} unit="人" />
            <Stat label="五区二县民办普高" value={p.wuquErxianPrivate.total.toLocaleString()} unit="人" />
            <Stat label="综合高中班试点" value={String(p.comprehensiveHigh)} unit="人" />
          </div>

          <div className="overflow-hidden rounded-xl border border-[#ede8e0]">
            <table className="w-full text-left text-sm">
              <thead className="bg-[#f3f4f6] text-[#4b5563]">
                <tr>
                  <th className="px-4 py-2.5 font-semibold">招生单元</th>
                  <th className="px-4 py-2.5 text-right font-semibold">总计划</th>
                  <th className="px-4 py-2.5 text-right font-semibold">统招</th>
                  <th className="px-4 py-2.5 text-right font-semibold">定向</th>
                  <th className="px-4 py-2.5 text-right font-semibold">特长</th>
                  <th className="px-4 py-2.5 text-right font-semibold">特色班</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#ede8e0] text-[#10233d]">
                <tr>
                  <td className="px-4 py-2.5">城六区 · 公办</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPublic.total}</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPublic.zhaotong}</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPublic.dingxiang}</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPublic.tese}</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPublic.teSeBan}</td>
                </tr>
                <tr>
                  <td className="px-4 py-2.5">城六区 · 民办</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPrivate.total}</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPrivate.zhaotong}</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPrivate.dingxiang}</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPrivate.tese}</td>
                  <td className="px-4 py-2.5 text-right">{p.chengliuPrivate.teSeBan}</td>
                </tr>
                <tr>
                  <td className="px-4 py-2.5">五区二县 · 公办</td>
                  <td className="px-4 py-2.5 text-right">{p.wuquErxianPublic}</td>
                  <td className="px-4 py-2.5 text-right text-[#9ca3af]" colSpan={4}>
                    详见官方分学校计划
                  </td>
                </tr>
                <tr>
                  <td className="px-4 py-2.5">五区二县 · 民办</td>
                  <td className="px-4 py-2.5 text-right">{p.wuquErxianPrivate.total}</td>
                  <td className="px-4 py-2.5 text-right">{p.wuquErxianPrivate.zhaotong}</td>
                  <td className="px-4 py-2.5 text-right">{p.wuquErxianPrivate.dingxiang}</td>
                  <td className="px-4 py-2.5 text-right text-[#9ca3af]" colSpan={2}>
                    详见官方计划
                  </td>
                </tr>
                <tr>
                  <td className="px-4 py-2.5">综合高中班试点</td>
                  <td className="px-4 py-2.5 text-right">{p.comprehensiveHigh}</td>
                  <td className="px-4 py-2.5 text-right text-[#9ca3af]" colSpan={4}>
                    依托中职学校与普通高中联合试点
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div>
            <div className="mb-2 flex items-center gap-2">
              <b className="text-[#10233d]">分学校招生计划（官方已发布）</b>
              <Badge kind="ok">官方已发布</Badge>
            </div>
            <p className="mb-2 text-xs text-[#9ca3af]">
              共 {p.bySchool.length} 所学校，按招生单元分类。定向名额为 0 的单元表示该 PDF 未公布分项。
            </p>
            <div className="max-h-[560px] overflow-auto rounded-xl border border-[#ede8e0] bg-white">
              <table className="w-full text-left text-sm">
                <thead className="sticky top-0 z-10 bg-[#f3f4f6] text-[#4b5563]">
                  <tr>
                    <th className="px-4 py-2.5 font-semibold">学校名称</th>
                    <th className="px-4 py-2.5 font-semibold">招生单元</th>
                    <th className="px-4 py-2.5 font-semibold">性质</th>
                    <th className="px-4 py-2.5 text-right font-semibold">招生计划</th>
                    <th className="px-4 py-2.5 text-right font-semibold">定向名额</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#ede8e0] text-[#10233d]">
                  {p.bySchool.map((s) => (
                    <tr key={s.name}>
                      <td className="px-4 py-2">{s.name}</td>
                      <td className="px-4 py-2 text-[#4b5563]">{s.region}</td>
                      <td className="px-4 py-2">
                        <OwnershipTag o={s.ownership} />
                      </td>
                      <td className="px-4 py-2 text-right font-semibold">{s.plan}</td>
                      <td className="px-4 py-2 text-right text-[#4b5563]">
                        {s.dingxiang ? s.dingxiang : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <p className="text-xs text-[#9ca3af]">
            来源：<SourceLink id="plan2026" />（西安市教育局 2026-07-16 发布，含 5 个 PDF 附件）
          </p>
        </div>
      </Section>

      {/* 定向生计划 */}
      <Section no="3" title="2026 定向生分校生源计划">
        <div className="space-y-4">
          <p className="text-[0.95rem] leading-relaxed text-[#4b5563]">
            2026 年城六区及西咸新区省级标准化高中定向生分校生源计划已公布。家长可在
            <a
              href={SOURCES.directional2026.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#b94f38] underline decoration-dotted underline-offset-2 hover:text-[#a23f29]"
            >
              西安市教育局官网
            </a>
            下载各区 PDF 原表，查看孩子所在初中的具体定向名额。
          </p>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
            {Object.entries(DIRECTIONAL_2026.summary).map(([district, info]) => (
              <div
                key={district}
                className="rounded-xl border border-[#ede8e0] bg-white p-3 text-center"
              >
                <div className="text-xs text-[#6b7280]">{district}</div>
                <div className="mt-1 text-[1.2rem] font-bold text-[#10233d]">{info.totalQuota}</div>
                <div className="text-xs text-[#9ca3af]">{info.juniorSchools} 所初中</div>
              </div>
            ))}
          </div>
          <p className="text-xs text-[#9ca3af]">
            来源：<SourceLink id="directional2026" />（西安市教育局 2026-07-16 发布，含 7 个区 PDF 附件）
          </p>
        </div>
      </Section>

      {/* 民办初中（小升初）招生计划 —— 义务教育阶段，与高中中招志愿不同 */}
      <Section no="4" title="2026 民办初中（小升初）招生计划">
        <div className="space-y-4">
          <div className="flex items-start gap-3 rounded-2xl border border-[#cfe3ec] bg-[#eef6fa] p-4">
            <span className="mt-0.5 text-xl">🧒</span>
            <p className="text-[0.95rem] leading-relaxed text-[#274a5e]">
              <b>注意阶段不同：</b>
              以下为<b>义务教育民办初中（小升初）</b>招生计划，实行<b>电脑随机录取（摇号）</b>，
              <b>不填报志愿</b>，与本站「高中中招志愿」属于不同的招生阶段。此处仅作官方信息收录，
              供家长了解各校招生规模与直升名额。
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Stat label="全市民办初中班数" value={String(PRIVATE_JUNIOR_2026.total.classes)} unit="个" />
            <Stat label="招生计划总数" value={PRIVATE_JUNIOR_2026.total.plan.toLocaleString()} unit="人" />
            <Stat label="其中直升" value={PRIVATE_JUNIOR_2026.total.shengzhi.toLocaleString()} unit="人" />
          </div>

          <div>
            <div className="mb-2 flex items-center gap-2">
              <b className="text-[#10233d]">分区域招生计划（官方已发布）</b>
              <Badge kind="ok">官方已发布</Badge>
            </div>
            <div className="overflow-hidden rounded-xl border border-[#ede8e0]">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#f3f4f6] text-[#4b5563]">
                  <tr>
                    <th className="px-4 py-2.5 font-semibold">区域</th>
                    <th className="px-4 py-2.5 text-right font-semibold">班数</th>
                    <th className="px-4 py-2.5 text-right font-semibold">计划</th>
                    <th className="px-4 py-2.5 text-right font-semibold">直升</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#ede8e0] text-[#10233d]">
                  {PRIVATE_JUNIOR_2026.byDistrict.map((d) => (
                    <tr key={d.district}>
                      <td className="px-4 py-2.5">{d.district}</td>
                      <td className="px-4 py-2.5 text-right">{d.classes}</td>
                      <td className="px-4 py-2.5 text-right font-semibold">{d.plan}</td>
                      <td className="px-4 py-2.5 text-right text-[#4b5563]">
                        {d.shengzhi ? d.shengzhi : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <div className="mb-2 flex items-center gap-2">
              <b className="text-[#10233d]">分学校招生计划（{PRIVATE_JUNIOR_2026.schools.length} 所）</b>
              <Badge kind="ok">官方已发布</Badge>
            </div>
            <div className="max-h-[520px] overflow-auto rounded-xl border border-[#ede8e0] bg-white">
              <table className="w-full text-left text-sm">
                <thead className="sticky top-0 z-10 bg-[#f3f4f6] text-[#4b5563]">
                  <tr>
                    <th className="px-4 py-2.5 font-semibold">序号</th>
                    <th className="px-4 py-2.5 font-semibold">学校名称</th>
                    <th className="px-4 py-2.5 font-semibold">区域</th>
                    <th className="px-4 py-2.5 text-right font-semibold">班数</th>
                    <th className="px-4 py-2.5 text-right font-semibold">计划</th>
                    <th className="px-4 py-2.5 text-right font-semibold">直升</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#ede8e0] text-[#10233d]">
                  {PRIVATE_JUNIOR_2026.schools.map((s) => (
                    <tr key={s.seq}>
                      <td className="px-4 py-2 text-[#6b7280]">{s.seq}</td>
                      <td className="px-4 py-2">{s.name}</td>
                      <td className="px-4 py-2 text-[#4b5563]">{s.district}</td>
                      <td className="px-4 py-2 text-right">{s.classes}</td>
                      <td className="px-4 py-2 text-right font-semibold">{s.plan}</td>
                      <td className="px-4 py-2 text-right text-[#4b5563]">
                        {s.shengzhi ? s.shengzhi : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <p className="text-xs text-[#9ca3af]">
            来源：<SourceLink id="privateJunior2026" />（西安市教育局 2026-07-02 发布，电脑随机录取，不填报志愿）
          </p>
        </div>
      </Section>

      {/* 录取控制线 */}
      <Section no="5" title="录取控制线">
        <div className="space-y-3">
          <div className="rounded-xl border border-[#ede8e0] bg-white p-4">
            <div className="mb-2 flex items-center gap-2">
              <b className="text-[#10233d]">2025 年城六区（历史参考）</b>
              <Badge kind="ok">官方已发布</Badge>
            </div>
            <div className="grid grid-cols-3 gap-3 text-center">
              <Stat label="普高线" value={String(CONTROL_LINES.y2025.chengliuRegular)} unit="分" />
              <Stat label="特长生线" value={String(CONTROL_LINES.y2025.sportsArt)} unit="分" />
              <Stat label="综合高中班" value={String(CONTROL_LINES.y2025.comprehensiveHigh)} unit="分" />
            </div>
            <p className="mt-2 text-xs text-[#9ca3af]">{CONTROL_LINES.y2025.note}</p>
            <p className="mt-1 text-xs text-[#9ca3af]">来源：<SourceLink id="controlLine2025" /></p>
          </div>
          <div className="rounded-xl border border-[#d7ece0] bg-[#f3fbf6] p-4">
            <div className="mb-2 flex items-center gap-2">
              <b className="text-[#10233d]">2026 年城六区录取控制线</b>
              <Badge kind="ok">官方已发布</Badge>
            </div>
            <div className="grid grid-cols-3 gap-3 text-center">
              <Stat label="普高线" value={String(CONTROL_LINES.y2026.chengliuRegular)} unit="分" />
              <Stat label="特长生线" value={String(CONTROL_LINES.y2026.sportsArt)} unit="分" />
              <Stat label="综合高中班" value={String(CONTROL_LINES.y2026.comprehensiveHigh)} unit="分" />
            </div>
            <p className="mt-2 text-xs text-[#6b7280]">{CONTROL_LINES.y2026.note}</p>
            <p className="mt-1 text-xs text-[#9ca3af]">来源：<SourceLink id="controlLine2026" /></p>
          </div>
          <div className="rounded-xl border border-[#e7e0f2] bg-[#f7f4fc] p-4">
            <div className="mb-2 flex items-center gap-2">
              <b className="text-[#10233d]">2026 年五区二县及西咸新区控制线</b>
              <Badge kind="ok">官方已发布</Badge>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-[#6b7280]">
                    <th className="px-2 py-1.5 font-medium">招生单元</th>
                    <th className="px-2 py-1.5 text-center font-medium">普高线</th>
                    <th className="px-2 py-1.5 text-center font-medium">特长生线</th>
                    <th className="px-2 py-1.5 text-center font-medium">综合高中班</th>
                  </tr>
                </thead>
                <tbody>
                  {CONTROL_LINES.y2026.districts.map((d) => (
                    <tr key={d.name} className="border-t border-[#eceaf5]">
                      <td className="px-2 py-1.5 text-[#10233d]">
                        {d.name}
                        {d.estimated ? <span className="ml-1 text-[10px] text-[#b45309]">（预估）</span> : null}
                        {d.note ? <span className="ml-1 text-[10px] text-[#9ca3af]">（{d.note}）</span> : null}
                      </td>
                      <td className="px-2 py-1.5 text-center">{d.regular != null ? d.regular.toFixed(1) : "—"}</td>
                      <td className="px-2 py-1.5 text-center">{d.sportsArt != null ? d.sportsArt.toFixed(1) : "—"}</td>
                      <td className="px-2 py-1.5 text-center">{d.comprehensiveHigh != null ? d.comprehensiveHigh.toFixed(1) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-2 text-xs text-[#6b7280]">
              五区二县及西咸新区为独立招生单元，控制线由各区县教育局公布、互不通用；城六区考生约 80550 人，临潼区约 6411 人。
            </p>
            <p className="mt-1 text-xs text-[#9ca3af]">来源：<SourceLink id="controlLines2026Districts" /></p>
          </div>
          <p className="mt-3 rounded-lg bg-[#fff7ed] px-3 py-2 text-xs leading-relaxed text-[#9a3412]">
            关于一分一段表：全市目前仅<b>城六区</b>官方公开发布完整版（633–511 分，已收录并用于位次估算）；五区二县及西咸新区按招生单元单独发布，
            公开渠道仅临潼区有零星分段锚点（620 分以上 {LINTONG_SCORE_ANCHORS.anchors[0].geCount} 人、610 分以上 {LINTONG_SCORE_ANCHORS.anchors[1].geCount} 人、
            600 分以上 {LINTONG_SCORE_ANCHORS.anchors[2].geCount} 人、510 分以上 {LINTONG_SCORE_ANCHORS.anchors[3].geCount} 人，临潼考生约 {LINTONG_SCORE_ANCHORS.totalCandidates} 人），
            其余单元待官方分段表发布后补充；本站不预测、不估算录取分数线。
          </p>
        </div>
      </Section>

      {/* 官方平台入口 */}
      <Section no="6" title="官方平台入口">
        <div className="space-y-2 text-[0.95rem]">
          <p className="text-[#4b5563]">
            志愿填报、成绩查询与录取结果均以
            <a
              href={SOURCES.platform.url}
              target="_blank"
              rel="noopener noreferrer"
              className="mx-1 text-[#b94f38] underline decoration-dotted underline-offset-2 hover:text-[#a23f29]"
            >
              西安市初中学业水平考试招生管理平台
            </a>
            为准（{SOURCES.platform.url}）。
          </p>
          <p className="text-xs text-[#9ca3af]">
            该平台为官方业务系统，不支持在本站内嵌展示；请直接访问上述官方地址操作。
          </p>
        </div>
      </Section>

      {/* 数据状态脚注 */}
      <section className="mx-auto max-w-[1100px] px-5 py-6">
        <div className="rounded-xl bg-white/70 p-4 text-xs leading-relaxed text-[#6b7280]">
          {DATA_STATUS_NOTE}
          <div className="mt-2 space-y-0.5">
            <div>官方来源：</div>
            <ul className="list-disc pl-5">
              <li>
                <SourceLink id="scheme2026" /> — 2026 录取工作方案
              </li>
              <li>
                <SourceLink id="plan2026" /> — 2026 普通高中招生计划
              </li>
              <li>
                <SourceLink id="directional2026" /> — 2026 定向生分校生源计划
              </li>
              <li>
                <SourceLink id="privateJunior2026" /> — 2026 民办初中（小升初）招生计划
              </li>
              <li>
                <SourceLink id="controlLine2025" /> — 2025 城六区控制线
              </li>
              <li>
                <SourceLink id="controlLine2026" /> — 2026 城六区控制线（普高 492.0 / 特长生 295.2 / 综合高中班 465.0）
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* 数据来源声明（全站统一口径） */}
      <section className="mx-auto mt-2 max-w-[1100px] px-5 pb-8">
        <div className="rounded-2xl border border-[#ede8e0] bg-white p-4 text-[12px] leading-relaxed text-[#667487]">
          数据来源：西安市教育局《2026年普通高中分学校招生计划》；学校计划、招生单元及办学层级以官方附件为准。志愿推荐结果仅作信息参考，最终以西安市中招录取平台公布结果为准。
        </div>
      </section>
    </main>
  );
}

function Stat({ label, value, unit }: { label: string; value: string; unit?: string }) {
  return (
    <div className="rounded-xl border border-[#ede8e0] bg-white p-3 text-center">
      <div className="text-xs text-[#6b7280]">{label}</div>
      <div className="mt-1 text-[1.4rem] font-bold text-[#10233d]">
        {value}
        {unit && <span className="ml-0.5 text-sm font-normal text-[#9ca3af]">{unit}</span>}
      </div>
    </div>
  );
}

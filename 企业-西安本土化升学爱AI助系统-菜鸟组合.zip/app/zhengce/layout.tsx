import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "中招官方政策与招生计划",
  description:
    "西安市2026年中考中招官方数据：招生计划、录取工作方案、志愿批次、定向生政策与同分规则，来源均已标注。",
};

export default function ZhengceLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return children;
}

"use client";
import { useEffect } from "react";

export function track(name: string, properties: Record<string, unknown> = {}) {
  try {
    const sid = localStorage.getItem("ly_sid") || crypto.randomUUID();
    localStorage.setItem("ly_sid", sid);
    void fetch("/api/collect", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, sessionId: sid, environment: "production", properties }), keepalive: true }).catch(() => undefined);
  } catch { }
}

export default function Analytics() {
  useEffect(() => { track("page_view"); }, []);
  return null;
}
"use client";
import { ReportsRenderer } from "../../components/report/ReportsRenderer";

export default function SortReportRoute() {
  return <ReportsRenderer tier="sort" />;
}

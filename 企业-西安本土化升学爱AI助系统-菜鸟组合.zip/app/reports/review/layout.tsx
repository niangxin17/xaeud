import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "老师复核报告",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

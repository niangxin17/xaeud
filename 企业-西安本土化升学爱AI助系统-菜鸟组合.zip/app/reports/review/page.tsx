"use client";
import { ReportsRenderer } from "../../components/report/ReportsRenderer";

export default function ReviewReportRoute() {
  return <ReportsRenderer tier="review" />;
}

import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "学校适配报告",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

"use client";
import { ReportsRenderer } from "../../components/report/ReportsRenderer";

export default function FitReportRoute() {
  return <ReportsRenderer tier="fit" />;
}

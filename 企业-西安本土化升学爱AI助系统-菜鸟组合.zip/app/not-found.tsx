import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "页面不存在",
};

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-[#f7f3ec] px-5 text-center text-[#10233d]">
      <div className="grid h-14 w-14 place-items-center rounded-2xl bg-[#10233d] text-2xl text-white">志</div>
      <h1 className="mt-5 text-5xl font-black tracking-tight">404</h1>
      <p className="mt-2 text-base text-[#667487]">抱歉，您访问的页面不存在或已被移动。</p>
      <Link
        href="/"
        className="mt-6 rounded-full bg-[#b94f38] px-6 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-[#a23f29]"
      >
        返回首页
      </Link>
    </main>
  );
}

import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "隐私政策",
  description: "西安中考志愿用户隐私政策：我们如何收集、使用与保护您的信息。",
};

export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-[#f7f3ec] px-5 py-10 text-[#10233d]">
      <div className="mx-auto max-w-2xl">
        <h1 className="text-2xl font-black">隐私政策</h1>
        <p className="mt-2 text-sm text-[#667487]">最后更新：2026 年 7 月</p>

        <section className="mt-6 space-y-3 text-sm leading-relaxed text-[#4b5563]">
          <p>我们重视您的隐私。本政策说明「西安中考志愿」如何收集、使用与保护您的信息。</p>

          <h2 className="pt-3 text-base font-bold text-[#10233d]">一、我们收集的信息</h2>
          <p>
            您主动填写的中考预估分数、所在区县、就读初中（定向生）等信息，仅用于为您生成匹配学校与志愿方案。我们不会要求手机号，也不会向您拨打推销电话。
          </p>

          <h2 className="pt-3 text-base font-bold text-[#10233d]">二、信息的使用</h2>
          <p>
            您的信息主要用于在本机浏览器（localStorage）与本次会话中生成报告，不会用于营销或转售。
          </p>

          <h2 className="pt-3 text-base font-bold text-[#10233d]">三、Cookie 与本地存储</h2>
          <p>
            我们使用浏览器本地存储保存您的测分结果与订单状态，以便您再次访问时查看报告。您可以随时清除浏览器数据。
          </p>

          <h2 className="pt-3 text-base font-bold text-[#10233d]">四、支付信息</h2>
          <p>支付由微信支付与支付宝提供，我们不直接存储您的银行卡或支付凭证。</p>

          <h2 className="pt-3 text-base font-bold text-[#10233d]">五、联系我们</h2>
          <p>如对本政策有疑问，可通过站点内反馈渠道与我们联系。</p>
        </section>

        <Link
          href="/"
          className="mt-8 inline-block rounded-full bg-[#b94f38] px-6 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-[#a23f29]"
        >
          返回首页
        </Link>
      </div>
    </main>
  );
}

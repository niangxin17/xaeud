import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "解锁报告",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

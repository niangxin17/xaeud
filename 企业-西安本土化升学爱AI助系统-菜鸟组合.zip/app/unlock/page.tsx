"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

// 测试权益注入工具：仅供本地体验/测试套餐功能使用。
// 仅把测试权益写入本机浏览器 localStorage，不向服务器发送任何数据。
export default function UnlockPage() {
  return (
    <Suspense>
      <Inner />
    </Suspense>
  );
}

function Inner() {
  const params = useSearchParams();
  const [msg, setMsg] = useState("准备中…");

  useEffect(() => {
    const plan = params.get("plan") || "review_599";
    const score = Number(params.get("score") || 573);
    const district = params.get("district") || "yanta";
    const junior = params.get("junior") || "测试初中（复审演示）";
    try {
      const lock = {
        score,
        rank: params.get("rank") || "约 3000 名",
        district,
        juniorSchool: junior,
        directionalSchool: params.get("dir") || undefined,
        packageId: plan as any,
        lockedAt: new Date().toISOString(),
      };
      const paid = JSON.parse(localStorage.getItem("ly_paid_plans") || "[]");
      if (!paid.some((p: any) => p.planId === plan)) {
        paid.push({ orderId: "demo_" + plan, planId: plan, ts: Date.now() });
      }
      localStorage.setItem("ly_profile_locked", JSON.stringify(lock));
      localStorage.setItem("ly_paid_plans", JSON.stringify(paid));
      setMsg(`已注入 ${plan} 测试权益，正在跳转…`);
      const go = params.get("go") || "/downloads";
      window.setTimeout(() => {
        window.location.href = go;
      }, 800);
    } catch (e: any) {
      setMsg("注入失败：" + (e?.message || e));
    }
  }, [params]);

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#f7f3ec] px-5 text-[#10233d]">
      <div className="max-w-md rounded-2xl bg-white p-8 text-center shadow-[0_12px_32px_rgba(16,35,61,.06)]">
        <div className="text-xs font-bold tracking-[.2em] text-[#b94f38]">TEST UNLOCK</div>
        <h1 className="mt-2 text-xl font-black">测试权益注入工具</h1>
        <p className="mt-3 text-sm text-[#667487]">
          仅供本地测试，不会向服务器发送任何数据。仅把测试权益写入本机浏览器，用于体验对应套餐功能。
        </p>
        <p className="mt-4 rounded-xl bg-[#f7f3ec] px-3 py-3 text-sm">{msg}</p>
      </div>
    </main>
  );
}

"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { initWechatShare, isWechat, ShareContent } from "../lib/wechat-share";

const DEFAULT_SHARE: ShareContent = {
  title: "西安中考志愿｜输入分数，找到更适合的高中",
  desc: "分数定位、学校匹配、志愿方案、老师复核，一站式搞定中考志愿。",
  link: "https://laoyou.love/?from=wechat-share",
  imgUrl: "https://laoyou.love/images/logo.png",
};

function currentShare(): ShareContent {
  // 各页面可把自定义分享内容写入 window.__lyShare，否则用默认
  if (typeof window !== "undefined") {
    const custom = (window as any).__lyShare as ShareContent | undefined;
    if (custom && custom.title) return custom;
  }
  return DEFAULT_SHARE;
}

export default function WeChatShareInitializer() {
  const pathname = usePathname();

  useEffect(() => {
    if (!isWechat()) return; // 仅在微信内初始化，避免污染其他浏览器
    let cancelled = false;
    initWechatShare(currentShare()).then(() => {
      if (!cancelled) {
        // 配置完成后再补一次当前内容（兜底 route 变化竞态）
        initWechatShare(currentShare());
      }
    });
    return () => {
      cancelled = true;
    };
  }, [pathname]);

  return null;
}

"use client";

import { useEffect, useMemo } from "react";
import OwnershipBadge from "./OwnershipBadge";
import {
  schoolsByDataDistrict,
  DISTRICT_TO_DATA,
  estimateRank,
  chengliuquSchoolsWithRank,
  directionalSchools,
  DIRECTIONAL_DROP,
  classifySchool,
  admissionProbability,
  probClass,
  ownershipLabel,
  type School,
} from "../lib/volunteer-data";

const districtLabelMap: Record<string, string> = {
  xincheng: "新城区",
  beilin: "碑林区",
  lianhu: "莲湖区",
  yanta: "雁塔区",
  weiyang: "未央区",
  bashan: "灞桥区",
  xixian: "西咸新区",
  changan: "长安区",
};

type ReportModalProps = {
  open: boolean;
  onClose: () => void;
  score: number;
  district: string; // 页面区县 value
  middleSchool: string;
  rank: string;
  directionalSchool: string;
};

function diffClass(diff: number): string {
  if (diff <= 0) return "text-[#059669]"; // 低于或等于用户分数，更稳
  if (diff <= 20) return "text-[#b94f38]"; // 略高
  return "text-[#6b7280]"; // 高出较多
}

export default function ReportModal({
  open,
  onClose,
  score,
  district,
  middleSchool,
  rank,
  directionalSchool,
}: ReportModalProps) {
  // 锁定 body 滚动 + ESC 关闭
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  const data = useMemo(() => {
    if (!score || !district) return null;
    const dataDistrict = DISTRICT_TO_DATA[district] || "chengliuqu";

    // ① 匹配学校（±80，不足 15 所逐步扩展，与首页推荐一致）
    const inDistrict = schoolsByDataDistrict(dataDistrict);
    const refOf = (s: School) => s.referenceScore;
    let range = 80;
    let matched = inDistrict
      .map((s) => ({ ...s, diff: refOf(s) - score }))
      .filter((s) => Math.abs(s.diff) <= range);
    while (matched.length < 15 && range < 200 && matched.length < inDistrict.length) {
      range += 10;
      matched = inDistrict
        .map((s) => ({ ...s, diff: refOf(s) - score }))
        .filter((s) => Math.abs(s.diff) <= range);
    }
    matched = matched
      .sort((a, b) => Math.abs(a.diff) - Math.abs(b.diff))
      .slice(0, 30);

    // ② 城六区全部高中分数与位次
    const cityTable = chengliuquSchoolsWithRank();

    // ③ 所选就读初中对应可报考的定向生高中（按数据区县）
    const dirSchools = directionalSchools(dataDistrict).map((s) => ({
      ...s,
      estLine: Math.max(s.referenceScore - DIRECTIONAL_DROP, 0),
    }));

    const userRank = rank ? Number(rank) : estimateRank(score, dataDistrict).rank;

    return {
      dataDistrict,
      matched,
      range,
      cityTable,
      dirSchools,
      userRank,
    };
  }, [score, district, rank]);

  if (!open) return null;

  // 未填写分数/区县时的提示
  if (!score || !district) {
    return (
      <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-[#10233d]/40 backdrop-blur-sm" onClick={onClose} />
        <div className="relative z-10 w-full max-w-[440px] rounded-[24px] bg-white p-8 text-center shadow-[0_24px_60px_rgba(16,35,61,.2)]">
          <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full bg-[#fdf2ee] text-3xl">📋</div>
          <h3 className="text-xl font-bold text-[#10233d]">还没生成报告哦</h3>
          <p className="mt-3 text-base leading-relaxed text-[#4b5563]">
            请先在页面上方填写<span className="font-bold text-[#b94f38]">中考预估分数</span>与<span className="font-bold text-[#b94f38]">所在区县</span>，
            点击「免费生成基础报告」后，再来生成这份升学报告。
          </p>
          <button
            type="button"
            onClick={onClose}
            className="mt-6 w-full rounded-xl bg-[#10233d] px-5 py-3 text-base font-bold text-white transition hover:bg-[#0c1a2c]"
          >
            去填写
          </button>
        </div>
      </div>
    );
  }

  const genTime = new Date().toLocaleString("zh-CN", { hour12: false });
  const dl = districtLabelMap[district] || "—";

  return (
    <div className="fixed inset-0 z-[300] flex items-start justify-center overflow-y-auto p-4 sm:p-6">
      <div className="absolute inset-0 bg-[#10233d]/50 backdrop-blur-sm" onClick={onClose} />

      {/* 报告主体（打印区域） */}
      <div
        id="report-print"
        className="relative z-10 my-2 w-full max-w-[820px] rounded-[20px] bg-white shadow-[0_24px_70px_rgba(16,35,61,.28)]"
      >
        {/* 顶部工具条（不打印） */}
        <div className="no-print sticky top-0 z-20 flex items-center justify-between rounded-t-[20px] border-b border-[#ede8e0] bg-white/95 px-5 py-3 backdrop-blur">
          <span className="text-sm font-bold text-[#10233d]">升学报告预览</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => window.print()}
              className="rounded-lg bg-[#b94f38] px-4 py-2 text-sm font-bold text-white transition hover:bg-[#a23f29]"
            >
              打印 / 保存为 PDF
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-[#cedeae] px-4 py-2 text-sm font-bold text-[#10233d] transition hover:bg-[#f3f4f6]"
            >
              关闭
            </button>
          </div>
        </div>

        <div className="px-6 py-6 sm:px-9 sm:py-8">
          {/* 报告抬头 */}
          <div className="border-b-2 border-[#10233d]/10 pb-5">
            <div className="flex items-center gap-2">
              <span className="inline-grid h-7 w-7 place-items-center rounded-lg bg-[#b94f38] text-sm font-black text-white">志</span>
              <h1 className="text-2xl font-black text-[#10233d]">西安中考升学报告</h1>
            </div>
            <p className="mt-2 text-sm text-[#667487]">生成时间：{genTime}（数据仅供参考，最终以西安市教育局官方公布为准）</p>
            <div className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2 sm:grid-cols-4">
              <InfoCell label="中考预估分" value={`${score} 分`} />
              <InfoCell label="估算位次" value={`${data!.userRank.toLocaleString()} 名`} />
              <InfoCell label="所在区县" value={dl} />
              <InfoCell label="就读初中" value={middleSchool || "未填写"} />
            </div>
          </div>

          {/* ① 匹配学校 */}
          <Section index="一" title="与你的分数最匹配的学校" desc={`系统自动匹配「${dl}」分数 ${data!.range === 80 ? "上下 80 分" : `上下 ${data!.range} 分`} 内的学校，共 ${data!.matched.length} 所`}>
            <div className="overflow-hidden rounded-xl border border-[#ede8e0]">
              <table className="w-full border-collapse text-sm">
                <thead>
                  <tr className="bg-[#f7f3ec] text-left text-xs text-[#667487]">
                    <th className="px-3 py-2 font-semibold">学校</th>
                    <th className="px-3 py-2 font-semibold">代码</th>
                    <th className="px-3 py-2 text-right font-semibold">2026预估分</th>
                    <th className="px-3 py-2 text-right font-semibold">分差</th>
                    <th className="px-3 py-2 text-center font-semibold">冲稳保</th>
                    <th className="px-3 py-2 text-center font-semibold">录取概率</th>
                  </tr>
                </thead>
                <tbody>
                  {data!.matched.map((s) => {
                    const prob = admissionProbability(score, s.referenceScore);
                    return (
                    <tr key={s.id} className="border-t border-[#ede8e0]">
                      <td className="px-3 py-2">
                        <span className="flex items-center gap-2">
                          <OwnershipBadge ownership={s.ownership} />
                          <span className="font-medium text-[#10233d]">{s.name}</span>
                        </span>
                      </td>
                      <td className="px-3 py-2 font-mono text-xs text-[#9ca3af]">{s.code}</td>
                      <td className="px-3 py-2 text-right font-bold text-[#10233d]">{s.referenceScore}</td>
                      <td className={`px-3 py-2 text-right font-black ${diffClass(s.diff)}`}>
                        {s.diff > 0 ? `+${s.diff}` : s.diff}
                      </td>
                      <td className="px-3 py-2 text-center">
                        <span className={"rounded-full px-2 py-0.5 text-xs font-bold " + classifyStyle(classifySchool(score, s.referenceScore))}>
                          {classifySchool(score, s.referenceScore)}
                        </span>
                      </td>
                      <td className={"px-3 py-2 text-center font-black " + probClass(prob)}>
                        ≈{prob}%
                      </td>
                    </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Section>

          {/* ② 城六区分数位次一览 */}
          <Section index="二" title="城六区全部高中 录取分数与位次一览" desc={`共 ${data!.cityTable.length} 所（按2026预估分从高到低，位次为估算值）`}>
            <div className="max-h-[420px] overflow-y-auto rounded-xl border border-[#ede8e0]">
              <table className="w-full border-collapse text-sm">
                <thead className="sticky top-0 bg-[#f7f3ec] text-left text-xs text-[#667487]">
                  <tr>
                    <th className="px-3 py-2 font-semibold">排名</th>
                    <th className="px-3 py-2 font-semibold">学校</th>
                    <th className="px-3 py-2 font-semibold">代码</th>
                    <th className="px-3 py-2 font-semibold">性质</th>
                    <th className="px-3 py-2 font-semibold">批次</th>
                    <th className="px-3 py-2 text-right font-semibold">2026预估分</th>
                    <th className="px-3 py-2 text-right font-semibold">估算位次</th>
                  </tr>
                </thead>
                <tbody>
                  {data!.cityTable.map((s, i) => (
                    <tr key={s.id} className="border-t border-[#ede8e0]">
                      <td className="px-3 py-2 text-[#9ca3af]">{i + 1}</td>
                      <td className="px-3 py-2">
                        <span className="flex items-center gap-2">
                          <OwnershipBadge ownership={s.ownership} />
                          <span className="font-medium text-[#10233d]">{s.name}</span>
                        </span>
                      </td>
                      <td className="px-3 py-2 font-mono text-xs text-[#9ca3af]">{s.code}</td>
                      <td className="px-3 py-2 text-xs text-[#667487]">{ownershipLabel(s.ownership)}</td>
                      <td className="px-3 py-2 text-xs text-[#667487]">{s.batch === 1 ? "第一批" : "第二批"}</td>
                      <td className="px-3 py-2 text-right font-bold text-[#10233d]">{s.referenceScore}</td>
                      <td className="px-3 py-2 text-right text-[#183b75]">{s.rank.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>

          {/* ③ 定向生高中 */}
          <Section
            index="三"
            title="你的就读初中可报考的定向生高中"
            desc={
              middleSchool
                ? `就读初中：${middleSchool}（${dl}）`
                : `就读初中：未填写（选填后可更精准匹配）`
            }
          >
            {data!.dirSchools.length === 0 ? (
              <p className="rounded-xl bg-[#f7f3ec] px-4 py-3 text-sm text-[#667487]">
                当前区县暂无带定向生名额的高中数据，可补充就读初中后进一步查询。
              </p>
            ) : (
              <>
                <div className="overflow-hidden rounded-xl border border-[#ede8e0]">
                  <table className="w-full border-collapse text-sm">
                    <thead>
                      <tr className="bg-[#f7f3ec] text-left text-xs text-[#667487]">
                        <th className="px-3 py-2 font-semibold">定向生高中</th>
                        <th className="px-3 py-2 font-semibold">代码</th>
                        <th className="px-3 py-2 text-right font-semibold">定向生名额</th>
                        <th className="px-3 py-2 text-right font-semibold">统招参考分</th>
                        <th className="px-3 py-2 text-right font-semibold">定向生预估线</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data!.dirSchools.map((s) => {
                        const chosen = directionalSchool && s.name === directionalSchool;
                        return (
                          <tr key={s.id} className={"border-t border-[#ede8e0] " + (chosen ? "bg-[#fff6f1]" : "")}>
                            <td className="px-3 py-2">
                              <span className="flex items-center gap-2">
                                <OwnershipBadge ownership={s.ownership} />
                                <span className="font-medium text-[#10233d]">{s.name}</span>
                                {chosen && (
                                  <span className="rounded-full bg-[#b94f38] px-2 py-0.5 text-[0.65rem] font-bold text-white">你已选</span>
                                )}
                              </span>
                            </td>
                            <td className="px-3 py-2 font-mono text-xs text-[#9ca3af]">{s.code}</td>
                            <td className="px-3 py-2 text-right font-bold text-[#10233d]">{s.directionalQuota}</td>
                            <td className="px-3 py-2 text-right font-bold text-[#10233d]">{s.referenceScore}</td>
                            <td className="px-3 py-2 text-right font-black text-[#059669]">{s.estLine}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                <p className="mt-3 text-xs leading-relaxed text-[#9ca3af]">
                  定向生名额按初中分配，上表为该校在{DL_SCOPE[data!.dataDistrict] || "本招生区域"}的定向生总计划；具体到你校的名额以西安市教育局下达的分配方案为准。
                  定向生预估线按“统招线下 {DIRECTIONAL_DROP} 分”估算（西安市政策：定向生录取分数不低于本校统招线 50 分）。
                </p>
              </>
            )}
          </Section>

          {/* 温馨提示 */}
          <div className="mt-6 rounded-xl bg-[#f7f3ec] px-5 py-4 text-sm leading-relaxed text-[#4b5563]">
            <span className="font-bold text-[#b94f38]">温馨提示：</span>
            本报告由系统依据公开招生计划与往年录取分数自动排版生成，位次为统计学估算值，仅供参考，不构成录取承诺。
            志愿填报请结合孩子实际、家庭通勤与批次规则，并以上级教育部门最终公布数据为准。
          </div>
        </div>
      </div>

      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #report-print, #report-print * { visibility: visible !important; }
          #report-print {
            position: absolute !important; left: 0 !important; top: 0 !important;
            width: 100% !important; max-width: 100% !important; margin: 0 !important;
            border-radius: 0 !important; box-shadow: none !important;
          }
          .no-print { display: none !important; }
          thead { position: static !important; }
        }
      `}</style>
    </div>
  );
}

const DL_SCOPE: Record<string, string> = {
  chengliuqu: "城六区",
  xixian: "西咸新区",
  changan: "长安区",
};

function classifyStyle(c: "冲" | "稳" | "保"): string {
  if (c === "冲") return "bg-[#fde8dd] text-[#c2410c]";
  if (c === "稳") return "bg-[#e5f0ee] text-[#1f4a44]";
  return "bg-[#eaf2fb] text-[#1d4ed8]";
}

function InfoCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-[#f7f3ec] px-3 py-2">
      <div className="text-xs text-[#9ca3af]">{label}</div>
      <div className="mt-0.5 text-sm font-bold text-[#10233d]">{value}</div>
    </div>
  );
}

function Section({
  index,
  title,
  desc,
  children,
}: {
  index: string;
  title: string;
  desc: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mt-7">
      <div className="flex items-baseline gap-2">
        <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#10233d] text-xs font-bold text-white">
          {index}
        </span>
        <h2 className="text-lg font-black text-[#10233d]">{title}</h2>
      </div>
      <p className="mt-1 mb-3 pl-8 text-sm text-[#667487]">{desc}</p>
      {children}
    </section>
  );
}

"use client";

import { schools, type School } from "../lib/volunteer-data";
import OwnershipBadge from "./OwnershipBadge";
import TierBadge from "./TierBadge";
import { SchoolNameTag } from "./RegionTag";

type FreeSchoolsRecommendationProps = {
  score: number;
  district: string;
};

const regionAbbr = (region?: string): string => {
  if (!region) return "";
  if (region.includes("港务")) return "港务";
  if (region.includes("浐灞")) return "浐灞";
  if (region.includes("沣东")) return "沣东";
  if (region.includes("沣西")) return "沣西";
  if (region.includes("泾河")) return "泾河";
  if (region.includes("空港")) return "空港";
  if (region.includes("金贸")) return "金贸";
  if (region.includes("创新")) return "创新";
  if (region.includes("高新")) return "高新";
  if (region.includes("经开")) return "经开";
  if (region.includes("曲江")) return "曲江";
  if (region.includes("航天")) return "航天";
  if (region.includes("碑林")) return "碑林";
  if (region.includes("雁塔")) return "雁塔";
  if (region.includes("莲湖")) return "莲湖";
  if (region.includes("未央")) return "未央";
  if (region.includes("新城")) return "新城";
  if (region.includes("灞桥")) return "灞桥";
  if (region.includes("长安")) return "长安";
  if (region.includes("临潼")) return "临潼";
  if (region.includes("高陵")) return "高陵";
  if (region.includes("鄠邑")) return "鄠邑";
  if (region.includes("蓝田")) return "蓝田";
  if (region.includes("周至")) return "周至";
  if (region.includes("阎良")) return "阎良";
  if (region.startsWith("城六")) return "城六";
  return region.slice(0, 2);
};
const districtMap: Record<string, string> = {
  xincheng: "chengliuqu",
  yanta: "chengliuqu",
  beilin: "chengliuqu",
  lianhu: "chengliuqu",
  weiyang: "chengliuqu",
  bashan: "chengliuqu",
  xixian: "xixian",
  changan: "changan",
  // 五区二县：每个区县独立成单元
  yanliang: "yanliang",
  lintong: "lintong",
  gaoling: "gaoling",
  huyi: "huyi",
  lantian: "lantian",
  zhouzhi: "zhouzhi",
};

export default function FreeSchoolsRecommendation({ score, district }: FreeSchoolsRecommendationProps) {
  if (!score || !district) return null;

  const targetDistrict = districtMap[district] || "chengliuqu";
  const allSchools = (schools as unknown as School[]).filter(
    (s) => s.district === targetDistrict && s.schoolType === "high"
  );

  const scored = allSchools.map((s) => ({
    ...s,
    ref: s.referenceScore,
    diff: s.referenceScore - score,
  }));

  // 免费版：向下 20 分、向上 40 分（如 560 分 → 540–600），按与用户分数差值升序
  const selected = scored
    .filter((s) => s.diff >= -20 && s.diff <= 40)
    .sort((a, b) => Math.abs(a.diff) - Math.abs(b.diff))
    .slice(0, 30);
  const diffClass = (diff: number) => {
    if (diff <= 0) return "text-[#059669]"; // 低于或等于用户分数，更稳
    if (diff <= 20) return "text-[#b94f38]"; // 略高
    return "text-[#6b7280]"; // 高出较多
  };

  return (
    <section className="mb-4 rounded-2xl border border-[#10233d]/10 bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-[#10233d]">参考学校推荐</h2>
          <p className="mt-1 text-sm text-[#6b7280]">
            {score} 分 · 向下 20 分 / 向上 40 分，共 {selected.length} 所
          </p>
        </div>
        <span className="rounded-full bg-[#e5f0ee] px-3 py-1 text-xs font-bold text-[#1f4a44]">免费</span>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {selected.map((s) => (
          <div
            key={s.id}
            className="relative flex flex-col gap-2 rounded-xl bg-[#f7f3ec] px-4 py-3 transition hover:bg-[#ede8e0]"
          >
            <TierBadge tier={s.tier} className="absolute right-3 top-3" />
            <span className="flex items-start gap-1.5 pr-6">
              <OwnershipBadge ownership={s.ownership} className="mt-0.5 shrink-0" />
              <SchoolNameTag
                name={s.name}
                district={s.district}
                className="inline-block break-words text-sm font-medium leading-snug text-[#10233d]"
              />
            </span>
            <span className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-2">
                <span className="font-mono text-[0.7rem] text-[#9ca3af]">{s.code}</span>
                {s.region && (
                  <span className="text-[0.65rem] font-medium text-[#9ca3af]">
                    {regionAbbr(s.region)}
                  </span>
                )}
              </span>
              <span className={`text-sm font-black ${diffClass(s.diff)}`}>
                {s.ref} 分
              </span>
            </span>
          </div>
        ))}
      </div>

      {selected.length < 15 && (
        <p className="mt-4 text-center text-xs text-[#9ca3af]">
          当前数据在该区县/分数段内可匹配学校不足 15 所，已显示全部相近学校。
        </p>
      )}
    </section>
  );
}

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import Logo from "./Logo";

const NAV = [
  { label: "能上的学校", href: "/" },
  { label: "定向生计划", href: "/directional" },
  { label: "中考志愿模拟", href: "/filing" },
  { label: "我的报告", href: "/downloads" },
  { label: "长安成长地图", href: "/growth" },
];

function isActive(href: string, pathname: string) {
  if (href === "/") return pathname === "/";
  return pathname.startsWith(href);
}

export default function SiteNav() {
  const pathname = usePathname() || "/";
  const [mobileOpen, setMobileOpen] = useState(false);

  // ESC 关闭抽屉
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setMobileOpen(false);
    }
    if (mobileOpen) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mobileOpen]);

  // 打开抽屉时锁定背景滚动
  useEffect(() => {
    if (mobileOpen) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  const linkBase =
    "whitespace-nowrap rounded-full px-3.5 py-1.5 text-sm font-semibold transition ";
  const linkIdle = "text-[#4b5563] hover:bg-[#f3f4f6]";
  const linkActive = "bg-[#fdf2ee] text-[#b94f38]";

  return (
    <>
      <header className="sticky top-0 z-[100] border-b border-[#ede8e0] bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1080px] items-center justify-between gap-4 px-5 py-3">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <Logo />
          </Link>

          {/* PC 导航 */}
          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((n) => {
              const active = isActive(n.href, pathname);
              return (
                <Link
                  key={n.href}
                  href={n.href}
                  className={linkBase + (active ? linkActive : linkIdle)}
                >
                  {n.label}
                </Link>
              );
            })}
            <Link
              href="/checkout?plan=match_29_9"
              className="ml-2 whitespace-nowrap rounded-full bg-[#b94f38] px-4 py-1.5 text-sm font-bold text-white shadow-sm transition hover:bg-[#a23f29]"
            >
              升级套餐
            </Link>
          </nav>

          {/* 手机汉堡按钮 */}
          <button
            type="button"
            aria-label={mobileOpen ? "关闭菜单" : "打开菜单"}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((o) => !o)}
            className="grid h-10 w-10 place-items-center rounded-xl bg-[#f7f3ec] text-[#10233d] transition hover:bg-[#ede8e0] md:hidden"
          >
            {mobileOpen ? (
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 6L6 18M6 6l12 12" />
              </svg>
            ) : (
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>
      </header>

      {/* 手机抽屉 */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[99] md:hidden">
          {/* 遮罩 */}
          <div
            className="absolute inset-0 bg-[#10233d]/30 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          {/* 面板 */}
          <div className="absolute right-0 top-0 h-full w-[min(80vw,320px)] bg-white shadow-[0_0_40px_rgba(16,35,61,.18)]">
            <div className="flex h-16 items-center justify-between border-b border-[#ede8e0] px-5">
              <span className="font-bold text-[#10233d]">菜单</span>
              <button
                type="button"
                aria-label="关闭菜单"
                onClick={() => setMobileOpen(false)}
                className="grid h-9 w-9 place-items-center rounded-lg text-[#4b5563] transition hover:bg-[#f3f4f6]"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 6L6 18M6 6l12 12" />
                </svg>
              </button>
            </div>
            <nav className="flex flex-col gap-2 p-5">
              {NAV.map((n) => {
                const active = isActive(n.href, pathname);
                return (
                  <Link
                    key={n.href}
                    href={n.href}
                    onClick={() => setMobileOpen(false)}
                    className={
                      "rounded-xl px-4 py-3 text-base font-semibold transition " +
                      (active ? "bg-[#fdf2ee] text-[#b94f38]" : "text-[#10233d] hover:bg-[#f3f4f6]")
                    }
                  >
                    {n.label}
                  </Link>
                );
              })}
              <Link
                href="/checkout?plan=match_29_9"
                onClick={() => setMobileOpen(false)}
                className="mt-3 rounded-xl bg-[#b94f38] px-4 py-3 text-center text-base font-bold text-white transition hover:bg-[#a23f29]"
              >
                升级套餐
              </Link>
            </nav>
          </div>
        </div>
      )}
    </>
  );
}

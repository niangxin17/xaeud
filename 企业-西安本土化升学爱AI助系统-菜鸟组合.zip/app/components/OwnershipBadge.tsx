// 公办/民办 徽标：学校名前展示「公」或「民」图标
// 公办 = 深蓝底（#10233d），民办 = 橙红底（#b94f38），与站点配色一致
import { Ownership, OWNERSHIP_CN } from "../lib/volunteer-data";

export default function OwnershipBadge({
  ownership,
  className = "",
}: {
  ownership?: Ownership;
  className?: string;
}) {
  if (ownership !== "public" && ownership !== "private") return null;
  const isPublic = ownership === "public";
  const bg = isPublic ? "#10233d" : "#b94f38";
  const label = isPublic ? "公" : "民";
  return (
    <span
      title={OWNERSHIP_CN[ownership]}
      className={
        "inline-grid h-[1.15rem] w-[1.15rem] shrink-0 place-items-center rounded-md text-[0.7rem] font-black leading-none text-white " +
        className
      }
      style={{ backgroundColor: bg }}
      aria-label={OWNERSHIP_CN[ownership]}
    >
      {label}
    </span>
  );
}

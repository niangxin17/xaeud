export type StepStatus = "done" | "current" | "upcoming";

const STEPS = [
  { id: 1, title: "填写分数与区县", hint: "输入预估分与所在区" },
  { id: 2, title: "生成基础报告", hint: "免费定位冲稳保方向" },
  { id: 3, title: "补充初中与策略", hint: "完善定向生与偏好" },
  { id: 4, title: "解锁 冲稳保 完整方案", hint: "解锁学校匹配详情" },
];

function circleClass(status: StepStatus) {
  if (status === "done")
    return "bg-[#5c9f88] text-white";
  if (status === "current")
    return "bg-[#173960] text-white";
  return "bg-white text-[#9ca3af] border border-[#d8dde3]";
}

function titleClass(status: StepStatus) {
  return status === "upcoming" ? "text-[#9ca3af]" : "text-[#102b50]";
}

export function ProgressSidebar({
  stepStatus,
}: {
  stepStatus: (id: number) => StepStatus;
}) {
  return (
    <>
      {/* 桌面端：竖向流程 */}
      <div className="hidden md:block">
        <div className="mb-4 text-xs font-bold tracking-[.16em] text-[#b94f38]">
          流程进度
        </div>
        <ol className="space-y-4">
          {STEPS.map((s) => {
            const status = stepStatus(s.id);
            const last = s.id === STEPS.length;
            return (
              <li key={s.id} className="flex items-start gap-3">
                <div className="flex flex-col items-center">
                  <span
                    className={`grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-bold ${circleClass(
                      status
                    )}`}
                  >
                    {status === "done" ? "✓" : s.id}
                  </span>
                  {!last && (
                    <span
                      className={`mt-0.5 w-px flex-1 ${
                        status === "done" ? "bg-[#5c9f88]" : "bg-[#eee8df]"
                      }`}
                      style={{ minHeight: 22 }}
                    />
                  )}
                </div>
                <span className="pb-1">
                  <span className={`block text-sm font-bold ${titleClass(status)}`}>
                    {s.title}
                  </span>
                  <span className="block text-xs text-[#778494]">{s.hint}</span>
                </span>
              </li>
            );
          })}
        </ol>
      </div>

      {/* 移动端：横向进度条 */}
      <div className="md:hidden">
        <div className="mb-2 text-xs font-bold tracking-[.16em] text-[#b94f38]">
          流程进度
        </div>
        <div className="flex items-center">
          {STEPS.map((s, i) => {
            const status = stepStatus(s.id);
            return (
              <div key={s.id} className="flex flex-1 items-center">
                <span
                  className={`grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-bold ${circleClass(
                    status
                  )}`}
                >
                  {status === "done" ? "✓" : s.id}
                </span>
                {i < STEPS.length - 1 && (
                  <span
                    className={`mx-1 h-0.5 flex-1 ${
                      status === "done" ? "bg-[#5c9f88]" : "bg-[#eee8df]"
                    }`}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

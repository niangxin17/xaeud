import { THEME, type PackageConfig } from "./package-config";
import { FeatureIconList } from "./FeatureIconList";
import { Star, Info, CheckCircle2 } from "lucide-react";

export type PackageCardProps = {
  pkg: PackageConfig;
  onSelect: () => void;
};

export function PackageCard({ pkg, onSelect }: PackageCardProps) {
  const t = THEME[pkg.theme];

  return (
    <div className="package-card group relative flex flex-col rounded-[13px] border border-[#eee8df] bg-white p-5 shadow-[0_2px_8px_rgba(40,55,70,.04)] transition-transform duration-200 ease-out hover:-translate-y-[3px] hover:shadow-[0_10px_24px_rgba(30,47,67,.12)]">
      {/* 顶部：大图标 + 文案 + 价格 */}
      <div className="flex items-start gap-4">
        <img
          src={pkg.mainIconSrc}
          srcSet={`${pkg.mainIconSrc} 1x, ${pkg.mainIconSrc.replace(".png", "@2x.png")} 2x, ${pkg.mainIconSrc.replace(".png", "@4x.png")} 4x`}
          alt={pkg.badge}
          className="h-20 w-20 shrink-0 object-contain"
          loading="lazy"
        />

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span
              className={`rounded-full px-2.5 py-1 text-xs font-bold ${t.badgeBg} ${t.badgeText}`}
            >
              {pkg.badge}
            </span>
            {pkg.extra && (
              <span className="inline-flex items-center gap-1 rounded-full bg-[#fef3c7] px-2.5 py-1 text-xs font-bold text-[#b45309]">
                <Star size={12} fill="currentColor" className="text-[#b45309]" />
                {pkg.extra}
              </span>
            )}
          </div>

          <div className="mt-2 flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h3 className="text-[17px] font-extrabold leading-snug text-[#102b50]">
                {pkg.title}
              </h3>
              <p className={`mt-0.5 text-[13px] ${pkg.id === "match_29_9" ? t.subtitle : "text-[#667487]"}`}>
                {pkg.subtitle}
              </p>
            </div>
            <div className="flex shrink-0 items-baseline gap-0.5">
              <span className="text-sm text-[#9ca3af]">¥</span>
              <span className={`text-3xl font-black ${t.price}`}>{pkg.price}</span>
            </div>
          </div>
        </div>
      </div>

      <FeatureIconList features={pkg.features} featureIconClass={t.featureIcon} />

      {pkg.note && (
        <div className="mt-3 flex items-center gap-1 text-xs text-[#9ca3af]">
          <Info size={14} className={pkg.id === "match_29_9" ? `shrink-0 ${t.featureIcon}` : "shrink-0 text-[#9ca3af]"} aria-hidden />
          <span>{pkg.note}</span>
        </div>
      )}

      {pkg.footerTag && (
        <div className="mt-3 flex justify-end">
          <span className="inline-flex items-center gap-1 rounded-lg bg-[#f7f3ec] px-2.5 py-1 text-xs font-medium text-[#667487]">
            <CheckCircle2 size={13} className="text-[#d09c44]" aria-hidden />
            {pkg.footerTag}
          </span>
        </div>
      )}

      <button
        type="button"
        onClick={onSelect}
        className={`mt-4 w-full rounded-xl border-2 px-4 py-3 text-sm font-bold transition active:scale-[.98] ${t.btn}`}
      >
        {pkg.buttonText}
      </button>
    </div>
  );
}

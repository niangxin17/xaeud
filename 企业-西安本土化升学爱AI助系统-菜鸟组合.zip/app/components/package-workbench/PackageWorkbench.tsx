import { PACKAGES, type PackageId } from "./package-config";
import { PackageCard } from "./PackageCard";
import { ProgressSidebar, type StepStatus } from "./ProgressSidebar";
import { PlanSummary } from "./PlanSummary";

export type PackageWorkbenchProps = {
  score: string;
  rank: string;
  district?: string;
  districtLabel: string;
  middleSchool: string;
  strategy: string;
  stepStatus: (id: number) => StepStatus;
  onFree: () => void;
  onPlan: (id: PackageId) => void;
};

const WORKBENCH_CSS = `
.workbench-layout {
  display: grid;
  grid-template-columns: 255px minmax(0, 1fr);
  gap: 14px;
  grid-template-areas:
    "progress summary"
    "title    title"
    "cards    cards";
  align-items: start;
}
.wb-progress { grid-area: progress; }
.wb-summary  { grid-area: summary; }
.wb-title    { grid-area: title; }
.wb-cards    { grid-area: cards; }

.package-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px;
}

.package-card {
  animation: fadeUp .45s ease both;
}
.package-card:nth-child(2) { animation-delay: .06s; }
.package-card:nth-child(3) { animation-delay: .12s; }
.package-card:nth-child(4) { animation-delay: .18s; }

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(12px); }
  to   { opacity: 1; transform: translateY(0); }
}

.package-card:active,
.package-card button:active {
  transform: scale(.98);
}

@media (max-width: 720px) {
  .workbench-layout {
    display: flex;
    flex-direction: column;
  }
  .wb-title    { order: 1; margin-bottom: 14px; }
  .wb-cards    { order: 2; }
  .wb-progress { order: 3; margin-top: 14px; }
  .wb-summary  { order: 4; margin-top: 14px; }
  .package-grid {
    grid-template-columns: 1fr;
  }
}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: .01ms !important;
    transition-duration: .01ms !important;
  }
}
`;

export function PackageWorkbench({
  score,
  rank,
  district,
  districtLabel,
  middleSchool,
  strategy,
  stepStatus,
  onFree,
  onPlan,
}: PackageWorkbenchProps) {
  function handleSelect(id: PackageId) {
    if (id === "free") onFree();
    else onPlan(id);
  }

  return (
    <div className="workbench-layout">
      <style dangerouslySetInnerHTML={{ __html: WORKBENCH_CSS }} />

      <div className="wb-progress rounded-2xl border border-[#eee8df] bg-white p-5 lg:self-start">
        <ProgressSidebar stepStatus={stepStatus} />
      </div>

      <div className="wb-summary rounded-2xl border border-[#eee8df] bg-white p-5 shadow-[0_4px_12px_rgba(40,55,70,.04)] lg:self-start">
        <PlanSummary
          score={score}
          rank={rank}
          districtLabel={districtLabel}
          district={district}
          middleSchool={middleSchool}
          strategy={strategy}
        />
      </div>

      <div className="wb-title text-center">
        <h2 className="text-[28px] font-bold leading-tight text-[#102b50]">
          你现在最需要哪种帮助？
        </h2>
        <p className="mt-1 text-[13px] text-[#8d9297]">
          先看清自己需要什么，再选择下一步。
        </p>
      </div>

      <div className="wb-cards">
        <div className="package-grid">
          {PACKAGES.map((p) => (
            <PackageCard key={p.id} pkg={p} onSelect={() => handleSelect(p.id)} />
          ))}
        </div>
      </div>
    </div>
  );
}

import type { PackageFeature } from "./package-config";

export function FeatureIconList({
  features,
  featureIconClass,
}: {
  features: PackageFeature[];
  featureIconClass: string;
}) {
  return (
    <div className="mt-4 flex items-start justify-between gap-2">
      {features.map((f, i) => {
        const Icon = f.Icon;
        return (
          <div
            key={i}
            className="flex flex-1 flex-col items-center gap-1 text-center"
          >
            <Icon size={22} strokeWidth={1.6} className={featureIconClass} aria-hidden />
            <span className="text-[11px] leading-tight text-[#667487]">{f.label}</span>
          </div>
        );
      })}
    </div>
  );
}

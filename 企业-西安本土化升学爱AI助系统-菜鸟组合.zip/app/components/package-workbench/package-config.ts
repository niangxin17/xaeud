import {
  ArrowUpDown,
  GraduationCap,
  Star,
  FileText,
  Download,
  BarChart3,
  Flag,
  Users,
  ListChecks,
  Target,
  Brain,
  CalendarDays,
  ShieldCheck,
  AlertTriangle,
  PencilLine,
  MessageCircle,
  CheckCircle2,
  type LucideIcon,
} from "lucide-react";

export type PackageId = "free" | "match_29_9" | "planning_199" | "review_599";
export type ThemeKey = "green" | "orange" | "blue" | "gold";

export type ThemeClasses = {
  badgeBg: string;
  badgeText: string;
  iconBg: string;
  iconColor: string;
  price: string;
  subtitle: string;
  btn: string;
  featureIcon: string;
};

// 主题色严格对齐参考图 8.jpg（从原图采样）
export const THEME: Record<ThemeKey, ThemeClasses> = {
  green: {
    badgeBg: "bg-[#43764b]",
    badgeText: "text-white",
    iconBg: "bg-[#e8f0e6]",
    iconColor: "text-[#43764b]",
    price: "text-[#43764b]",
    subtitle: "text-[#43764b]",
    btn: "border-[#43764b] text-[#43764b] hover:bg-[#43764b] hover:text-white",
    featureIcon: "text-[#43764b]",
  },
  orange: {
    badgeBg: "bg-[#e1544a]",
    badgeText: "text-white",
    iconBg: "bg-[#fee8dd]",
    iconColor: "text-[#e1544a]",
    price: "text-[#e1544a]",
    subtitle: "text-[#e1544a]",
    btn: "border-[#e1544a] text-[#e1544a] hover:bg-[#e1544a] hover:text-white",
    featureIcon: "text-[#e1544a]",
  },
  blue: {
    badgeBg: "bg-[#3864a0]",
    badgeText: "text-white",
    iconBg: "bg-[#e7eef6]",
    iconColor: "text-[#3864a0]",
    price: "text-[#3864a0]",
    subtitle: "text-[#3864a0]",
    btn: "border-[#3864a0] text-[#3864a0] hover:bg-[#3864a0] hover:text-white",
    featureIcon: "text-[#3864a0]",
  },
  gold: {
    badgeBg: "bg-[#d09c44]",
    badgeText: "text-white",
    iconBg: "bg-[#fbf0d6]",
    iconColor: "text-[#d09c44]",
    price: "text-[#d09c44]",
    subtitle: "text-[#d09c44]",
    btn: "border-[#d09c44] text-[#d09c44] hover:bg-[#d09c44] hover:text-white",
    featureIcon: "text-[#d09c44]",
  },
};

export type PackageFeature = { label: string; Icon: LucideIcon };

export type PackageConfig = {
  id: PackageId;
  theme: ThemeKey;
  badge: string;
  extra?: string;
  title: string;
  subtitle: string;
  price: string;
  mainIconSrc: string;
  features: PackageFeature[];
  note?: string;
  footerTag?: string;
  buttonText: string;
  // 真实权限边界（单一来源，供首页/结算/后端校验共用）
  permissions: Record<string, boolean | number>;
};

export const PACKAGES: PackageConfig[] = [
  {
    id: "free",
    theme: "green",
    badge: "免费测算",
    title: "我还不知道能报哪些学校",
    subtitle: "先找到分数接近的学校",
    price: "0",
    mainIconSrc: "/images/icons/free-icon.png",
    features: [
      { label: "上下80分学校", Icon: ArrowUpDown },
      { label: "定向生对应高中", Icon: GraduationCap },
      { label: "收藏归档", Icon: Star },
      { label: "自动PDF", Icon: FileText },
      { label: "下载转发", Icon: Download },
    ],
    buttonText: "免费生成学校清单",
    permissions: {
      scoreRange: 80,
      canViewMatchedSchools: true,
      canViewDirectional: true,
      canArchive: true,
      canDownloadBasicPdf: true,
      canEditFiling: false,
      canGenerateSimulation: false,
      simulationLimit: 0,
    },
  },
  {
    id: "match_29_9",
    theme: "orange",
    badge: "冲稳保分析",
    extra: "冲稳保入门方案",
    title: "我不知道志愿怎么排",
    subtitle: "模拟填报 3次",
    price: "29.9",
    mainIconSrc: "/images/icons/match-icon.png",
    features: [
      { label: "冲刺/稳妥/垫底", Icon: BarChart3 },
      { label: "分数位次分析", Icon: Flag },
      { label: "历年招生人数", Icon: Users },
      { label: "志愿顺序建议", Icon: ListChecks },
    ],
    note: "不含老师人工复核",
    buttonText: "查看冲稳保方案",
    permissions: {
      canViewRiskLayers: true,
      canViewProbability: true,
      canViewHistoricalRank: true,
      canViewEnrollment: true,
      canEditFiling: true,
      canGenerateSimulation: true,
      simulationLimit: 3,
      canViewTeacherReview: false,
    },
  },
  {
    id: "planning_199",
    theme: "blue",
    badge: "AI完整规划",
    title: "我想知道学校适不适合孩子",
    subtitle: "不限次模拟填报",
    price: "199",
    mainIconSrc: "/images/icons/ai-icon.png",
    features: [
      { label: "学校匹配度", Icon: Target },
      { label: "学习压力", Icon: Brain },
      { label: "重点班与定向生", Icon: GraduationCap },
      { label: "家长学生指导", Icon: Users },
      { label: "高中三年计划", Icon: CalendarDays },
      { label: "完整PDF", Icon: FileText },
    ],
    note: "不含老师一对一复核",
    buttonText: "志愿精准匹配 199元直接查看",
    permissions: {
      canViewMatchAnalysis: true,
      canViewLearningPressure: true,
      canViewClassAnalysis: true,
      canViewParentGuidance: true,
      canViewThreeYearPlan: true,
      canEditFiling: true,
      canGenerateSimulation: true,
      simulationLimit: Infinity,
      canDownloadFullPdf: true,
      canViewTeacherReview: false,
    },
  },
  {
    id: "review_599",
    theme: "gold",
    badge: "老师复核",
    title: "我已经有方案，想让老师把关",
    subtitle: "不限次模拟填报",
    price: "599",
    mainIconSrc: "/images/icons/teacher-icon.png",
    features: [
      { label: "老师逐志愿复核", Icon: ShieldCheck },
      { label: "结合孩子实际情况", Icon: Users },
      { label: "指出填报风险", Icon: AlertTriangle },
      { label: "修改建议", Icon: PencilLine },
      { label: "沟通确认", Icon: MessageCircle },
    ],
    footerTag: "AI不限次模拟 + 老师人工复核",
    buttonText: "老师复核稳一点 599元联系老师",
    permissions: {
      canViewMatchAnalysis: true,
      canViewLearningPressure: true,
      canViewClassAnalysis: true,
      canViewParentGuidance: true,
      canViewThreeYearPlan: true,
      canEditFiling: true,
      canGenerateSimulation: true,
      simulationLimit: Infinity,
      canDownloadFullPdf: true,
      canViewTeacherReview: true,
      canBookTeacherReview: true,
    },
  },
];

export const PACKAGE_BY_ID: Record<PackageId, PackageConfig> = PACKAGES.reduce(
  (acc, p) => {
    acc[p.id] = p;
    return acc;
  },
  {} as Record<PackageId, PackageConfig>
);

// 规范 §9：页面跳转映射（支付成功后才写入 localStorage 激活套餐）
export const PACKAGE_ROUTE: Record<PackageId, string> = {
  free: "#free-schools",
  match_29_9: "/checkout?plan=match_29_9",
  planning_199: "/checkout?plan=planning_199",
  review_599: "/checkout?plan=review_599",
};

export { CheckCircle2 };

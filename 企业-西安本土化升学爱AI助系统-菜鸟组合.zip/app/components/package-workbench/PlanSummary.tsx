import { directionalPlanSchools, DISTRICT_TO_DATA } from "../../lib/volunteer-data";

export function PlanSummary({
  score,
  rank,
  districtLabel,
  district,
  middleSchool,
  strategy,
}: {
  score: string;
  rank: string;
  districtLabel: string;
  district?: string;
  middleSchool: string;
  strategy: string;
}) {
  const dataDistrict = district ? DISTRICT_TO_DATA[district] || district : "";
  const directionalList = directionalPlanSchools(Number(score) || 0, dataDistrict);
  const directionalText =
    directionalList.length > 0
      ? directionalList.map((s) => s.name).join(" / ")
      : middleSchool
      ? "暂无匹配定向生学校"
      : "待补充初中信息";

  const rows: { label: string; value: string }[] = [
    { label: "分数", value: score ? `${score} 分` : "待填写" },
    { label: "位次", value: rank ? `${rank} 名` : "待填写" },
    { label: "区县", value: districtLabel || "待选择" },
    { label: "初中", value: middleSchool || "待补充" },
    { label: "定向生计划", value: directionalText },
  ];

  return (
    <div>
      <div className="mb-4 text-xs font-bold tracking-[.16em] text-[#b94f38]">
        方案摘要
      </div>
      <dl className="space-y-3">
        {rows.map((r) => (
          <div
            key={r.label}
            className="flex items-center justify-between border-b border-[#eee8df] pb-2 last:border-0 last:pb-0"
          >
            <dt className="text-xs text-[#778494]">{r.label}</dt>
            <dd className="text-sm font-bold text-[#102b50]">{r.value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

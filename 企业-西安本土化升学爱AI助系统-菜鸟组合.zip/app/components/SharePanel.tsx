"use client";

import { useEffect, useRef, useState } from "react";
import { initWechatShare, isWechat, ShareContent } from "../lib/wechat-share";

const DISTRICT_LABEL: Record<string, string> = {
  xincheng: "新城区", beilin: "碑林区", lianhu: "莲湖区", yanta: "雁塔区",
  weiyang: "未央区", bashan: "灞桥区", xixian: "西咸新区", changan: "长安区",
};

function generateId() {
  return "ly" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

function copyText(text: string) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text);
  }
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand("copy"); } finally { document.body.removeChild(ta); }
  return Promise.resolve();
}

function showToast(message: string) {
  const existing = document.querySelector(".ly-share-toast");
  if (existing) existing.remove();
  const el = document.createElement("div");
  el.className = "ly-share-toast";
  el.textContent = message;
  el.style.cssText =
    "position:fixed;left:50%;bottom:80px;transform:translateX(-50%);background:#10233d;color:#fff;padding:10px 18px;border-radius:999px;font-size:14px;z-index:9999;box-shadow:0 8px 24px rgba(0,0,0,.2);opacity:0;transition:opacity .25s;max-width:80%;text-align:center;";
  document.body.appendChild(el);
  requestAnimationFrame(() => (el.style.opacity = "1"));
  setTimeout(() => { el.style.opacity = "0"; setTimeout(() => el.remove(), 300); }, 2400);
}

export interface SharePanelProps {
  originalPrice?: number;
  score?: string | number;
  district?: string;
  category?: string;
  onCountChange?: (count: number) => void;
}

/** 分享优惠面板：微信转发 / 复制链接 / 进度节点 / 抵扣规则
 *  规则：1人减10元；3人减20元；10+人免费。
 */
export function SharePanel({
  originalPrice = 29.9,
  score = "",
  district = "",
  category = "平衡推荐",
  onCountChange,
}: SharePanelProps) {
  const [ref] = useState(() => {
    if (typeof window === "undefined") return "";
    return (
      new URLSearchParams(window.location.search).get("ref") ||
      localStorage.getItem("ly_share_id") ||
      generateId()
    );
  });
  const [count, setCount] = useState(0);
  const [showGuide, setShowGuide] = useState(false);
  const loadedRef = useRef(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    localStorage.setItem("ly_share_id", ref);
    const stored = localStorage.getItem("ly_share_friends");
    const initial = stored ? Math.max(0, Math.floor(Number(stored)) || 0) : 0;
    setCount(initial);
    loadedRef.current = true;
  }, [ref]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    localStorage.setItem("ly_share_friends", String(count));
    onCountChange?.(count);
  }, [count, onCountChange]);

  const districtLabel = DISTRICT_LABEL[district] || district || "本地";
  const url = new URL("https://laoyou.love/result.html");
  if (score) url.searchParams.set("score", String(score));
  if (district) url.searchParams.set("district", district);
  url.searchParams.set("category", category);
  url.searchParams.set("ref", ref);
  const shareUrl = url.toString();

  // 微信内挂载即把自定义转发卡片（标题/描述/链接/缩略图）写入全局，
  // 这样用户直接点右上角「···」也能拿到砍价卡片，无需先点页面按钮。
  // 注意：必须放在 shareUrl / districtLabel 声明之后，否则依赖数组触发 TDZ 报错导致组件崩溃。
  useEffect(() => {
    if (!isWechat()) return;
    const content: ShareContent = {
      title: "一起测分，拿志愿填报抵扣券",
      desc: `${districtLabel}中考志愿推荐，邀请同学测分可领取抵扣券。`,
      link: shareUrl,
      imgUrl: "https://laoyou.love/images/logo.png",
    };
    (window as any).__lyShare = content;
    initWechatShare(content);
  }, [shareUrl, districtLabel]);

  const tier = count >= 10 ? 3 : count >= 3 ? 2 : count >= 1 ? 1 : 0;
  const currentPrice =
    tier >= 3 ? 0 : tier === 2 ? 9.9 : tier === 1 ? 19.9 : originalPrice;
  const discount = Math.max(0, originalPrice - currentPrice);
  const nextTarget = tier === 0 ? 1 : tier === 1 ? 3 - count : 10 - count;
  const progress = Math.min(100, (count / 10) * 100);

  const tiers = [
    { people: 1, discount: 10, price: 19.9, label: "分享1人" },
    { people: 3, discount: 20, price: 9.9, label: "分享3人" },
    { people: 10, discount: 29.9, price: 0, label: "分享10+人" },
  ];

  async function shareBySystem() {
    const shareData = {
      title: "一起测分，拿志愿填报抵扣券",
      text: `我在看${districtLabel}的中考志愿推荐，邀你一起测分，双方都能拿抵扣券。`,
      url: shareUrl,
    };
    if (navigator.share && (!navigator.canShare || navigator.canShare(shareData))) {
      try {
        await navigator.share(shareData);
        showToast("分享面板已打开，请选择微信好友或复制链接。");
        return;
      } catch (e: any) {
        if (e && e.name === "AbortError") {
          showToast("你取消了分享，邀请人数不会变化。");
          return;
        }
        // 分享被取消或失败，落到复制链接
      }
    }
    await copyText(shareUrl);
    showToast("链接已复制，可粘贴到微信发给好友。");
  }

  async function shareWechat() {
    if (!isWechat()) {
      shareBySystem();
      return;
    }
    const content: ShareContent = {
      title: "一起测分，拿志愿填报抵扣券",
      desc: `${districtLabel}中考志愿推荐，邀请同学测分可领取抵扣券。`,
      link: shareUrl,
      imgUrl: "https://laoyou.love/images/logo.png",
    };
    // 写入全局分享内容，供 WeChatShareInitializer 在路由变化时复用
    if (typeof window !== "undefined") (window as any).__lyShare = content;
    // 配置自定义转发卡片（标题/图/链接），并弹出微信内标准「点击右上角···」指引遮罩
    await initWechatShare(content);
    setShowGuide(true);
  }

  function copyLink() {
    copyText(shareUrl).then(() => showToast("链接已复制，快去分享吧"));
  }

  function simulateFriend() {
    setCount((c) => c + 1);
    showToast("好友助力成功！");
  }

  const statusText =
    count === 0
      ? `邀请 1 位同学测分，到手价 ${tiers[0].price.toFixed(1)} 元`
      : count < 3
      ? `已助力 ${count} 人，再邀 ${nextTarget} 人立减 20 元`
      : count < 10
      ? `已助力 ${count} 人，再邀 ${nextTarget} 人立减 29.9 元`
      : `已助力 ${count} 人，完整方案已免费`;

  return (
    <div className="flex flex-col">
      {/* 标题区 */}
      <div className="mb-4">
        <div className="text-base font-black text-[#10233d]">邀请同学，砍到免费</div>
        <div className="mt-1 text-xs text-[#778494]">好友通过你的链接完成测分，即可为你砍价</div>
      </div>

      {/* 三档节点 + 进度线 */}
      <div className="relative mb-5">
        {/* 连接线 */}
        <div className="absolute left-[16%] right-[16%] top-[18px] h-[3px] rounded-full bg-[#ede8e0]">
          <div
            className="h-full rounded-full bg-gradient-to-r from-[#b94f38] via-[#ff8c69] to-[#f3c766]"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* 节点 */}
        <div className="relative flex justify-between">
          {tiers.map((t, i) => {
            const active = i < tier;
            const current = i === tier;
            return (
              <div key={t.people} className="flex flex-col items-center">
                <div
                  className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-black shadow-sm ${
                    active
                      ? "bg-[#b94f38] text-white"
                      : current
                      ? "bg-white text-[#b94f38] ring-2 ring-[#b94f38]"
                      : "bg-white text-[#778494] ring-2 ring-[#e5e0d8]"
                  }`}
                >
                  {t.people === 10 ? "10+" : t.people}
                </div>
                <div className="mt-2 text-center">
                  <div className={`text-sm font-black ${active || current ? "text-[#10233d]" : "text-[#a0a0a0]"}`}>
                    {t.price === 0 ? "免费" : `¥${t.price.toFixed(1)}`}
                  </div>
                  <div className={`text-[10px] font-bold ${active || current ? "text-[#b94f38]" : "text-[#9ca3af]"}`}>
                    {t.label}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 状态提示 */}
      <div className="mb-4 rounded-xl bg-[#fff7f2] px-3 py-2.5 text-center">
        <div className="text-xs font-bold text-[#b94f38]">{statusText}</div>
      </div>

      {/* 操作按钮 */}
      <div className="mb-4 grid grid-cols-5 gap-3">
        <button
          type="button"
          onClick={shareWechat}
          className="col-span-3 flex items-center justify-center gap-2 rounded-xl bg-[#b94f38] px-3 py-3 text-sm font-black text-white shadow-[0_4px_14px_rgba(185,79,56,.35)] active:scale-[0.98]"
        >
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
            <path d="M8.69 12.5c-.57 0-1.03-.46-1.03-1.03 0-.57.46-1.03 1.03-1.03.57 0 1.03.46 1.03 1.03 0 .57-.46 1.03-1.03 1.03zm5.62 0c-.57 0-1.03-.46-1.03-1.03 0-.57.46-1.03 1.03-1.03.57 0 1.03.46 1.03 1.03 0 .57-.46 1.03-1.03 1.03zM12 2C6.48 2 2 5.9 2 10.8c0 2.55 1.35 4.83 3.46 6.36-.15.85-.65 2.22-1.08 3.05 0 0-.17.34.13.45.29.11 3.74-1.41 4.87-2.05.79.21 1.62.33 2.48.35L12 19c0-.06 0-.11.02-.17-.06.02-.12.03-.19.03 5.52 0 10-3.9 10-8.8C22 5.9 17.52 2 12 2z" />
          </svg>
          微信转发
        </button>
        <button
          type="button"
          onClick={copyLink}
          className="col-span-2 flex items-center justify-center rounded-xl border-2 border-[#b94f38] bg-white px-3 py-3 text-sm font-black text-[#b94f38] active:scale-[0.98]"
        >
          复制链接
        </button>
      </div>

      {/* 当前抵扣价格 */}
      <div className="flex items-center justify-between rounded-2xl bg-[#10233d] px-4 py-3 text-white">
        <div>
          <div className="text-xs opacity-70">当前抵扣后价格</div>
          <div className="mt-0.5 text-[10px] opacity-60">原价 ¥{originalPrice.toFixed(1)}</div>
        </div>
        <div className="text-right">
          <div className="text-2xl font-black leading-none">
            {currentPrice === 0 ? "免费" : `¥${currentPrice.toFixed(1)}`}
          </div>
          {discount > 0 && (
            <div className="mt-1 text-[10px] font-bold text-[#f3c766]">已省 ¥{discount.toFixed(1)}</div>
          )}
        </div>
      </div>

      {/* 本地演示：仅开发环境 */}
      {typeof window !== "undefined" && location.hostname === "localhost" && (
        <button
          type="button"
          onClick={simulateFriend}
          className="mt-3 rounded-xl bg-[#f3f4f6] px-3 py-2 text-xs font-bold text-[#10233d]"
        >
          模拟好友助力 +1
        </button>
      )}

      {/* 微信内分享指引遮罩：标准微信 H5 分享形式（点击右上角 ··· → 发送给朋友） */}
      {showGuide && (
        <div
          onClick={() => setShowGuide(false)}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 99999,
            background: "rgba(0,0,0,.78)",
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-end",
            padding: "14px 18px",
            color: "#fff",
            WebkitTapHighlightColor: "transparent",
          }}
        >
          <div style={{ marginTop: 22, maxWidth: 280, textAlign: "right" }}>
            <div style={{ fontSize: 15, fontWeight: 700, lineHeight: 1.5 }}>
              点击右上角 <span style={{ fontSize: 18 }}>···</span> 选择「发送给朋友」
            </div>
            <div style={{ marginTop: 8, fontSize: 13, opacity: 0.85, lineHeight: 1.5 }}>
              把优惠分享给同学，一起测分砍到免费。
            </div>
          </div>
          <div style={{ marginRight: 4, marginTop: 2, fontSize: 34, lineHeight: 1 }}>↗</div>
          <div style={{ marginTop: 2, fontSize: 12, opacity: 0.6 }}>（点击屏幕任意处关闭）</div>
        </div>
      )}
    </div>
  );
}

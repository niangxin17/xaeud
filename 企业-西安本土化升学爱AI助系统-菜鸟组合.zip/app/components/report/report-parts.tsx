"use client";
// 报告共享展示组件（纯展示，使用 report.css 类）
import type { ReactNode } from "react";

export function Section({
  no,
  title,
  children,
  tab,
}: {
  no: string;
  title: string;
  children: ReactNode;
  tab?: string;
}) {
  return (
    <section className="page">
      {tab && <span className="section-tab">{tab}</span>}
      <div className="section-no">{no}</div>
      <h2>{title}</h2>
      {children}
    </section>
  );
}

export function Lead({ children }: { children: ReactNode }) {
  return <p className="lead">{children}</p>;
}

export function Summary({ strong, children }: { strong: string; children?: ReactNode }) {
  return (
    <div className="summary">
      <strong>{strong}</strong>
      {children && <p>{children}</p>}
    </div>
  );
}

export function KpiGrid({ items }: { items: Array<{ label: string; value: string }> }) {
  return (
    <div className="kpis">
      {items.map((it, i) => (
        <div className="kpi" key={i}>
          <small>{it.label}</small>
          <b>{it.value}</b>
        </div>
      ))}
    </div>
  );
}

type BadgeKind = "rush" | "steady" | "safe" | "warn" | "pending" | "locked";
export function Badge({ kind, children }: { kind: BadgeKind; children: ReactNode }) {
  return <span className={`badge ${kind}`}>{children}</span>;
}

export function Chips({ items }: { items: Array<{ label: string; value: string }> }) {
  return (
    <div className="chips">
      {items.map((it, i) => (
        <span className="chip" key={i}>
          {it.label}：{it.value}
        </span>
      ))}
    </div>
  );
}

export function Timeline({ children }: { children: ReactNode }) {
  return <div className="timeline">{children}</div>;
}

export function Step({
  num,
  title,
  sub,
  badge,
}: {
  num: number | string;
  title: ReactNode;
  sub?: ReactNode;
  badge?: ReactNode;
}) {
  return (
    <div className="step">
      <div className="num">{num}</div>
      <div>
        <b>{title}</b>
        {sub && <small>{sub}</small>}
      </div>
      {badge}
    </div>
  );
}

export function Cards({ children }: { children: ReactNode }) {
  return <div className="cards">{children}</div>;
}

export function Card({
  title,
  children,
  highlight,
  badge,
}: {
  title: ReactNode;
  children?: ReactNode;
  highlight?: boolean;
  badge?: ReactNode;
}) {
  return (
    <div className={`card${highlight ? " highlight" : ""}`}>
      <div className="topline">
        <h3>{title}</h3>
        {badge}
      </div>
      {children && <p>{children}</p>}
    </div>
  );
}

export function Checklist({ items }: { items: string[] }) {
  return (
    <ul className="checklist">
      {items.map((it, i) => (
        <li key={i}>{it}</li>
      ))}
    </ul>
  );
}

export function Source({ title, updated }: { title: ReactNode; updated: ReactNode }) {
  return (
    <div className="source">
      <strong>{title}</strong>
      <span>{updated}</span>
    </div>
  );
}

export function Compare({ before, after }: { before: ReactNode; after: ReactNode }) {
  return (
    <div className="compare">
      <div>{before}</div>
      <div className="arrow">→</div>
      <div>{after}</div>
    </div>
  );
}

export function Audit({ num, title, desc }: { num: number; title: ReactNode; desc: ReactNode }) {
  return (
    <div className="audit">
      <div className="num">{num}</div>
      <div>
        <b>{title}</b>
        <span>{desc}</span>
      </div>
    </div>
  );
}

export function Closing({
  title,
  text,
  actionLabel,
  onAction,
  disclaimer,
}: {
  title: string;
  text: ReactNode;
  actionLabel?: string;
  onAction?: () => void;
  disclaimer?: ReactNode;
}) {
  return (
    <section className="page closing">
      <div className="done">✓</div>
      <h2>{title}</h2>
      <p>{text}</p>
      {actionLabel && (
        <a
          className="closing-action"
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onAction?.();
          }}
        >
          {actionLabel}
        </a>
      )}
      {disclaimer && <div className="disclaimer">{disclaimer}</div>}
    </section>
  );
}

export function Quote({ children }: { children: ReactNode }) {
  return <div className="quote">“{children}”</div>;
}

export function Note({ children }: { children: ReactNode }) {
  return <div className="note">{children}</div>;
}

export function StatusRow({
  items,
}: {
  items: Array<{ small: string; bold: string; kind: "verified" | "pending" | "danger" }>;
}) {
  return (
    <div className="status-row">
      {items.map((it, i) => (
        <div className="status-box" key={i}>
          <small>{it.small}</small>
          <b className={it.kind}>{it.bold}</b>
        </div>
      ))}
    </div>
  );
}

export function DataRule({ children }: { children: ReactNode }) {
  return <div className="data-rule">{children}</div>;
}

export function Footnote({ children }: { children: ReactNode }) {
  return <p className="footnote">{children}</p>;
}

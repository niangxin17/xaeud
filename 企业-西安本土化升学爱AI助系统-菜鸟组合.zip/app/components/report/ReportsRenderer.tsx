"use client";
// 统一报告渲染与权益判定：读 profile lock + 已支付订单，按套餐层级渲染对应档位报告。
import { useEffect, useState } from "react";
import { getProfileLock } from "../../lib/profile-lock";
import { TIER_ORDER, type Tier } from "../../lib/reports/types";
import { DISTRICT_TO_DATA } from "../../lib/volunteer-data";
import { SortReport } from "./SortReport";
import { FitReport } from "./FitReport";
import { ReviewReport } from "./ReviewReport";

const DISTRICTS: Record<string, string> = {
  xincheng: "新城区", beilin: "碑林区", lianhu: "莲湖区", yanta: "雁塔区",
  weiyang: "未央区", bashan: "灞桥区", xixian: "西咸新区", changan: "长安区",
};

// 路由档位 -> 套餐 id
const ROUTE_TO_PKG: Record<string, Tier> = {
  free: "free",
  sort: "match_29_9",
  fit: "planning_199",
  review: "review_599",
};

const TIER_META: Record<Tier, { label: string; price: string; question: string; cta: string }> = {
  free: { label: "免费版", price: "免费", question: "我能报哪些学校？", cta: "返回首页查看结果" },
  match_29_9: { label: "冲稳保分析", price: "29.9元", question: "志愿怎么排？", cta: "解锁冲稳保报告" },
  planning_199: { label: "AI志愿规划", price: "199元", question: "学校适合孩子吗？", cta: "志愿精准匹配 199元直接查看" },
  review_599: { label: "老师复审", price: "599元", question: "我的方案会不会出错？", cta: "老师复核稳一点 599元联系老师" },
};

function tierRank(t: Tier): number {
  return TIER_ORDER.indexOf(t);
}

function loadPaidPlans(): string[] {
  try {
    const arr = JSON.parse(localStorage.getItem("ly_paid_plans") || "[]");
    return (arr || []).map((p: any) => p.planId).filter(Boolean);
  } catch {
    return [];
  }
}

export function ReportsRenderer({ tier }: { tier?: Tier }) {
  const [ready, setReady] = useState(false);
  const [lockPkg, setLockPkg] = useState<Tier>("free");
  const [paid, setPaid] = useState<string[]>([]);
  const [hasLock, setHasLock] = useState(false);

  useEffect(() => {
    const lock = getProfileLock();
    setHasLock(!!lock);
    if (lock) setLockPkg((lock.packageId as Tier) || "free");
    setPaid(loadPaidPlans());
    setReady(true);
  }, []);

  if (!ready) {
    return <div style={{ padding: 40, textAlign: "center", color: "#627d98" }}>加载中…</div>;
  }

  if (!hasLock) {
    return (
      <main className="min-h-screen bg-[#eef3f7] px-5 py-12">
        <div className="mx-auto max-w-xl rounded-2xl bg-white p-8 text-center shadow-[0_22px_60px_rgba(16,42,67,.11)]">
          <h1 className="text-2xl font-black text-[#102a43]">我的报告</h1>
          <p className="mt-3 text-sm text-[#627d98]">尚未生成报告。请先在首页测分并确认资料，付费套餐将解锁对应报告。</p>
          <a href="/" className="mt-5 inline-block rounded-xl bg-[#102a43] px-6 py-3 text-sm font-bold text-white">去测分</a>
        </div>
      </main>
    );
  }

  // 计算用户最高可访问档位
  const paidTiers = paid.filter((p): p is Tier => TIER_ORDER.includes(p as Tier));
  const maxTier: Tier = [...paidTiers, lockPkg].reduce((best, t) => (tierRank(t) > tierRank(best) ? t : best), "free" as Tier);

  const requested: Tier = tier ? ROUTE_TO_PKG[tier] : maxTier;
  const entitled = tierRank(requested) <= tierRank(maxTier);

  if (!entitled) {
    const meta = TIER_META[requested];
    const have = TIER_META[maxTier];
    return (
      <main className="min-h-screen bg-[#eef3f7] px-5 py-12">
        <div className="mx-auto max-w-xl rounded-2xl bg-white p-8 text-center shadow-[0_22px_60px_rgba(16,42,67,.11)]">
          <span className="rounded-full bg-[#fff7df] px-3 py-1 text-xs font-black text-[#986400]">{meta.question}</span>
          <h1 className="mt-4 text-2xl font-black text-[#102a43]">{meta.label}报告需解锁</h1>
          <p className="mt-3 text-sm text-[#627d98]">
            你当前已获得：<b>{have.label}</b>。{meta.label}在 {meta.price} 套餐中，解锁后可查看完整分析报告（含本档专属结论与最终方案）。
          </p>
          <a href={`/checkout?plan=${requested}`} className="mt-5 inline-block rounded-xl bg-[#b94f38] px-6 py-3 text-sm font-bold text-white shadow-[0_4px_14px_rgba(185,79,56,.25)] transition-all duration-200 hover:-translate-y-[2px] hover:bg-[#a23f29] hover:shadow-[0_8px_20px_rgba(185,79,56,.32)] active:scale-[0.96]">{meta.cta}</a>
          <a href="/downloads" className="mt-3 block text-xs text-[#087f8c] underline">返回我已获得的报告</a>
        </div>
      </main>
    );
  }

  // 构建报告上下文（真实用户数据）
  const lock = getProfileLock()!;
  const districtLabel = DISTRICTS[lock.district] || lock.district;
  const dataDistrict = DISTRICT_TO_DATA[lock.district] || "chengliuqu";
  const generatedAt = new Date().toISOString().slice(0, 10);
  const ctx = {
    studentName: "同学",
    score: Number(lock.score),
    rank: lock.rank || "—",
    districtLabel,
    juniorSchool: lock.juniorSchool || "—",
    dataDistrict,
    generatedAt,
  };
  const profile = {
    score: Number(lock.score),
    rank: lock.rank || "—",
    district: lock.district,
    juniorSchool: lock.juniorSchool || "—",
    packageId: lock.packageId,
  };

  if (requested === "free") {
    return (
      <main className="min-h-screen bg-[#eef3f7] px-5 py-12">
        <div className="mx-auto max-w-xl rounded-2xl bg-white p-8 text-center shadow-[0_22px_60px_rgba(16,42,67,.11)]">
          <span className="rounded-full bg-[#fdf2ee] px-3 py-1 text-xs font-black text-[#b94f38]">免费基础报告</span>
          <h1 className="mt-4 text-2xl font-black text-[#102a43]">免费版已整合到首页</h1>
          <p className="mt-3 text-sm leading-relaxed text-[#627d98]">
            为了让你更快拿到结果，免费基础报告已改为在首页直接展示。如需保存/打印完整分析报告，可解锁付费套餐。
          </p>
          <div className="mt-6 flex flex-col gap-3">
            <a href="/" className="inline-block rounded-xl bg-[#102a43] px-6 py-3 text-sm font-bold text-white">返回首页查看结果</a>
            <a href="/checkout?plan=match_29_9" className="inline-block rounded-xl border border-[#d1d5db] bg-white px-6 py-3 text-sm font-bold text-[#4b5563]">解锁冲稳保报告</a>
          </div>
        </div>
      </main>
    );
  }
  if (requested === "match_29_9") return <SortReport ctx={ctx} profile={profile} />;
  if (requested === "planning_199") return <FitReport ctx={ctx} profile={profile} />;
  return <ReviewReport ctx={ctx} profile={profile} />;
}

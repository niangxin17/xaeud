"use client";
// 报告框架：工具栏 + 封面 + 内容容器 + 可选公章
import type { ReactNode } from "react";
import "./report.css";

export type AccentClass = "" | "sort-report" | "fit-report" | "premium" | "prod";

export function ReportShell({
  accent,
  brand,
  tierLabel,
  eyebrow,
  title,
  subtitle,
  identity,
  stamp,
  children,
}: {
  accent: AccentClass;
  brand: string;
  tierLabel: string;
  eyebrow: string;
  title: ReactNode;
  subtitle: ReactNode;
  identity: Array<{ label: string; value: string }>;
  stamp?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className={accent || undefined}>
      <div className="demo">
        真实数据版报告 · 数字均标注来源与核验状态；未核验项显示“待核验”，不展示推算数字
      </div>
      <header className="toolbar">
        <div className="toolbar-inner">
          <div className="brand">
            <i className="logo" />
            老友升学
          </div>
          <div className="toolbar-title">{tierLabel}</div>
          <a href="/downloads">我的报告</a>
          <button className="primary" onClick={() => window.print()}>
            打印 / 保存PDF
          </button>
        </div>
      </header>
      <main className="report">
        <section className="cover">
          <div className="cover-top">
            <div className="cover-brand">{brand}</div>
            <span className="tier">{tierLabel}</span>
          </div>
          <div className="cover-main">
            <div className="eyebrow">{eyebrow}</div>
            <h1>{title}</h1>
            <p>{subtitle}</p>
          </div>
          <div className="identity">
            {identity.map((it, i) => (
              <span key={i}>
                {it.label}：{it.value}
              </span>
            ))}
          </div>
        </section>
        {children}
        {stamp && <div className="stamp">{stamp}</div>}
      </main>
    </div>
  );
}

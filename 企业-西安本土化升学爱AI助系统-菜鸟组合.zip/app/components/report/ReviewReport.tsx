"use client";
import { ReportShell } from "./ReportShell";
import { Section, Lead, Summary, KpiGrid, Badge, Cards, Card, Timeline, Step, Checklist, Compare, Audit, Closing, Footnote } from "./report-parts";
import { buildReview, type ReportProfile } from "../../lib/reports/analysis";
import type { ReportContext } from "../../lib/reports/types";
import { SchoolNameTag } from "../RegionTag";

const BADGE_OF_CAT: Record<string, "rush" | "steady" | "safe"> = { 冲: "rush", 稳: "steady", 保: "safe" };

export function ReviewReport({ ctx, profile }: { ctx: ReportContext; profile: ReportProfile }) {
  const d = buildReview(profile);
  const identity = [
    { label: "学生", value: ctx.studentName },
    { label: "原方案", value: "V1.0" },
    { label: "复核方案", value: "V2.0" },
    { label: "复核老师", value: "李老师（演示）" },
    { label: "完成时间", value: ctx.generatedAt },
  ];

  return (
    <ReportShell
      accent="premium"
      brand="LAOYOU · EXPERT REVIEW"
      tierLabel="599元 · 人工复核完成"
      eyebrow="回答你的最后一个问题"
      title={<>我的志愿方案，<br />有没有没看见的风险？</>}
      subtitle="在完整匹配、排序和适配分析基础上，由老师逐项检查资格、梯度、顺序、退路和家庭接受度，交付修改后的最终版本。"
      identity={identity}
      stamp={<><span>人工复核</span><span>已完成</span></>}
    >
      <Section no="01 · 老师最终意见" title="方向基本正确，但原方案不能直接提交">
        <Summary strong={`发现 ${d.findings.length} 项关键风险：主选梯度、保底接受度、定向生资格未最终确认。老师已给出调整建议并交付修改版方案。`}>
          修改后仍保留冲刺上限，同时降低多所学校同时落空的可能。
        </Summary>
        <KpiGrid
          items={[
            { label: "检查志愿", value: `${d.finalPlaced.length}个` },
            { label: "发现风险", value: `${d.findings.length}项` },
            { label: "建议修改", value: "梯度+保底" },
          ]}
        />
      </Section>

      <Section no="02 · 发现的问题" title="老师不是再讲一遍报告，而是指出哪里可能出错">
        {d.findings.map((f) => (
          <Audit key={f.n} num={f.n} title={f.title} desc={f.desc} />
        ))}
      </Section>

      <Section no="03 · 修改前后" title="两处调整，让方案有上限也有退路">
        <Compare
          before={
            <>
              <span className="badge warn">原方案 V1.0</span>
              <h3 style={{ marginTop: 10 }}>{d.beforeStructure}</h3>
              <p>{d.beforeText}</p>
            </>
          }
          after={
            <>
              <span className="badge steady">老师修改版 V2.0</span>
              <h3 style={{ marginTop: 10 }}>{d.afterStructure}</h3>
              <p>{d.afterText}</p>
            </>
          }
        />
      </Section>

      <Section no="04 · 最终建议方案" title="老师复核后的可执行版本">
        <Timeline>
          {d.finalPlaced.map((s, i) => (
            <Step
              key={s.id}
              num={i + 1}
              title={<SchoolNameTag name={s.name} district={s.district} />}
              sub={s.reason + ` 录取概率约 ${s.prob}%。`}
              badge={<Badge kind={BADGE_OF_CAT[s.cat]}>{s.cat}</Badge>}
            />
          ))}
        </Timeline>
        <Footnote>
          录取概率为模型估算：基于考生分与学校预估投档线的分差，用 logistic 函数映射为百分比，非官方一分一段表；同一分差下每年实际录取波动较大，仅供参考，不构成录取保证。
        </Footnote>
      </Section>

      <Section no="05 · 老师逐项确认" title="哪些已经确认，哪些仍需家长行动">
        <table className="table">
          <thead>
            <tr>
              <th>检查项目</th>
              <th>状态</th>
              <th>老师意见</th>
              <th>责任人</th>
            </tr>
          </thead>
          <tbody>
            {d.confirmRows.map((r) => (
              <tr key={r.item}>
                <td>
                  <strong>{r.item}</strong>
                </td>
                <td>
                  <Badge kind={r.status}>{r.statusText}</Badge>
                </td>
                <td>{r.opinion}</td>
                <td>{r.owner}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      <Section no="06 · 正式提交前" title="最后一次检查，只做这五件事">
        <Checklist
          items={[
            "核对学生姓名、准考证信息和报考区县。",
            "确认定向生资格和本校本年度正式名额。",
            "按最终位次执行对应的成绩变化预案。",
            "再次确认两所保底学校都是家庭真实可接受的选择。",
            "正式提交后保存截图，并由第二位家庭成员复核学校代码和顺序。",
          ]}
        />
      </Section>

      <Section no="07 · 服务交付记录" title="599元购买的，是一次有结果的人工复核">
        <Cards>
          <Card title="资料核验" highlight>
            检查成绩、位次、就读初中、报考地及家庭约束是否完整。
          </Card>
          <Card title="方案复核">
            逐项检查志愿梯度、学校顺序、资格、退路和适配风险。
          </Card>
          <Card title="修改版本">
            不只指出问题，交付一份已经修改完成的 V2.0 方案。
          </Card>
          <Card title="结果说明">
            解释为什么修改、仍有哪些待办、正式提交前如何检查。
          </Card>
        </Cards>
        <Footnote>
          正式上线时，应明确公示老师资质、响应时效、修改次数、沟通方式及服务边界；复核老师姓名与意见在本演示中为示例。
        </Footnote>
      </Section>

      <Closing
        title="这份方案，已经完成专业复核"
        text="你现在拿到的不是另一个意见，而是一份已标出风险、已完成修改、仍有明确待办的最终方案。剩下的事情，是完成资格确认，并在最终成绩公布后做最后一次校准。"
        actionLabel="保存老师复核终稿"
        onAction={() => window.print()}
        disclaimer="说明：人工复核用于识别志愿方案中的信息遗漏和决策风险，不构成录取保证。最终报考资格、招生计划、志愿规则和录取结果以官方审核为准。"
      />
    </ReportShell>
  );
}

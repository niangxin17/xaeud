"use client";
import { ReportShell } from "./ReportShell";
import { Section, Lead, Summary, Chips, Cards, Card, Timeline, Step, Checklist, Quote, Closing, Badge, Footnote } from "./report-parts";
import { buildFit, buildSort, type ReportProfile } from "../../lib/reports/analysis";
import type { ReportContext } from "../../lib/reports/types";
import { probClass } from "../../lib/volunteer-data";
import { SchoolNameTag } from "../RegionTag";

const BADGE_OF_CAT: Record<string, "rush" | "steady" | "safe"> = { 冲: "rush", 稳: "steady", 保: "safe" };
const CONCLUSION_BADGE: Record<string, "rush" | "steady" | "safe" | "warn"> = {
  priority: "steady",
  consider: "steady",
  caution: "rush",
  not_recommended: "warn",
  unknown: "warn",
};

export function FitReport({ ctx, profile }: { ctx: ReportContext; profile: ReportProfile }) {
  const d = buildFit(profile);
  const sort = buildSort(profile);
  const identity = [
    { label: "学生", value: ctx.studentName },
    { label: "预估分", value: `${ctx.score}分` },
    { label: "学习特点", value: "基于分数推断" },
    { label: "家庭优先", value: "管理·通勤待补充" },
    { label: "生成时间", value: ctx.generatedAt },
  ];

  return (
    <ReportShell
      accent="fit-report"
      brand="LAOYOU · SCHOOL FIT REPORT"
      tierLabel="199元 · 个性化适配"
      eyebrow="回答你的第三个问题"
      title={<>能考上的学校，<br />真的适合孩子吗？</>}
      subtitle="在完整候选学校和志愿排序基础上，进一步分析孩子的学习特点、管理适应、住宿通勤与学校环境。"
      identity={identity}
    >
      <Section no="01 · 适配结论" title="先说适配结论，再给依据">
        <Summary strong={`优先比较 ${d.priorityNames}；冲刺校可作为上限，但不建议只因名气排在所有现实条件之前。`}>
          下面用高压、舒适区、通勤、升学口径和班型逐项说明“适合在哪里、不适合在哪里”。
        </Summary>
        <Chips items={d.profileChips} />
        <Footnote>{d.profileNote}</Footnote>
      </Section>

      <Section no="02 · 孩子画像" title="不是给孩子贴标签，而是找到选择条件">
        <Lead>画像只服务于学校决策：哪些环境会放大优势，哪些环境可能增加不必要的压力。下表基于分数与学校公开/历史数据，孩子个性部分需家庭补充。</Lead>
        <Cards>
          <Card title="学习稳定性" highlight>
            从估算位次看，成绩处于可重点了解区间，适合按稳定位次制定主选方案，不围绕单次最高分冒险。
          </Card>
          <Card title="学科结构">
            待家庭补充孩子优势学科（理/文倾向），以便比较学校的培养环境。
          </Card>
          <Card title="管理适应">
            待家庭补充孩子管理偏好（自主/规则导向），用于匹配学校风格。
          </Card>
          <Card title="家庭约束">
            通勤待家庭住址确认；住宿待家庭商议是否可接受。
          </Card>
        </Cards>
      </Section>

      <Section no="03 · 四所学校逐一判断" title="每所学校，都给出“适合在哪里、不适合在哪里”">
        <Cards>
          {d.rows.slice(0, 4).map((r) => (
            <Card
              key={r.school.id}
              title={<SchoolNameTag name={r.school.name} district={r.school.district} />}
              badge={<Badge kind={CONCLUSION_BADGE[r.conclusion]}>{r.conclusionText}</Badge>}
            >
              <b>适合：</b>
              {r.reasons[0] || "与当前分数区间匹配。"}
              <br />
              <b>风险：</b>
              {r.reasons[1] || r.reasons[0] || "需结合孩子实际情况确认。"}
            </Card>
          ))}
        </Cards>
      </Section>

      <Section no="04 · 核心学校对比" title="真正影响选择的，不只是录取分数">
        <Lead>以下 985/211 与班型数据均标注口径状态：缺届次、分母或官方来源的，显示“待统一口径数据 / 待官方材料核验”，不显示伪精确结论。</Lead>
        <table className="table fit-table">
          <thead>
            <tr>
              <th>学校</th>
              <th>录取概率</th>
              <th>高压提醒</th>
              <th>舒适区判断</th>
              <th>通勤/住宿</th>
              <th>985/211数据</th>
              <th>重点/火箭班</th>
              <th>适配结论</th>
            </tr>
          </thead>
          <tbody>
            {d.rows.map((r) => (
              <tr key={r.school.id}>
                <td>
                  <strong><SchoolNameTag name={r.school.name} district={r.school.district} /></strong>
                </td>
                <td className={"text-center font-black " + probClass(r.prob)}>≈{r.prob}%</td>
                <td>{r.pressureText}（模型估算）</td>
                <td>{r.comfortText}</td>
                <td>{r.commuteText}</td>
                <td className="locked">{r.rateLocked ? "待统一口径数据" : "可显示"}</td>
                <td className={r.classTrackVerified ? "" : "locked"}>{r.classTrackText}</td>
                <td>
                  <Badge kind={CONCLUSION_BADGE[r.conclusion]}>{r.conclusionText}</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <Footnote>
          985/211 数据须显示届次、毕业生分母、统计范围、是否含复读生与来源；班型须采信学校官方招生说明。当前校库记录缺上述口径，故以上两项标注“待核验”。
        </Footnote>
        <Footnote>
          录取概率为模型估算：基于考生分与学校预估投档线的分差，用 logistic 函数映射为百分比，非官方一分一段表；同一分差下每年实际录取波动较大，仅供参考，不构成录取保证。
        </Footnote>
      </Section>

      <Section no="05 · 适配后的志愿建议" title="排序不只看分数，还要体现孩子与家庭选择">
        <Timeline>
          {sort.placed.map((s, i) => (
            <Step
              key={s.id}
              num={i + 1}
              title={<SchoolNameTag name={s.name} district={s.district} />}
              sub={
                (s.cat === "冲"
                  ? "保留冲刺上限，但不作为唯一成功标准。"
                  : s.cat === "保"
                    ? "保留家庭能够接受的稳妥退路。"
                    : "综合分数与孩子特点，作为主选。") + ` 录取概率约 ${s.prob}%。`
              }
              badge={<Badge kind={BADGE_OF_CAT[s.cat]}>{s.cat}</Badge>}
            />
          ))}
        </Timeline>
      </Section>

      <Section no="06 · 家庭决策会" title="今晚只需要讨论这四个问题">
        <Checklist
          items={[
            "孩子愿不愿意为更强的学校接受住宿或更长通勤？",
            "家庭更重视学校上限，还是孩子三年持续稳定？",
            "如果两所学校都能录取，孩子更愿意去哪一所，为什么？",
            "我们是否真正接受保底学校，而不是只把它写在表上？",
          ]}
        />
        <Quote>最适合的学校，不是名气最大的那一所，而是孩子能够持续成长、家庭能够长期支持的那一所。</Quote>
      </Section>

      <Closing
        title="你的第三个问题，已经解决"
        text="你现在不仅知道学校怎么排，也能说清楚为什么这所学校更适合孩子。下一步是让孩子参与选择，形成家庭共同认可的主选和退路。"
        actionLabel="保存家庭决策版报告"
        onAction={() => window.print()}
        disclaimer="说明：人校适配分析基于用户填写信息和学校公开/历史资料，用于辅助家庭比较，不构成对学校质量、孩子发展或录取结果的保证。985/211 与班型数据以官方口径为准。"
      />
    </ReportShell>
  );
}

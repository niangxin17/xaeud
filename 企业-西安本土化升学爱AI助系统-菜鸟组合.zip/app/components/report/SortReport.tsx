"use client";
import { ReportShell } from "./ReportShell";
import { Section, Lead, Summary, KpiGrid, Badge, Cards, Card, Timeline, Step, Checklist, Source, Closing, Footnote } from "./report-parts";
import { buildSort, type ReportProfile } from "../../lib/reports/analysis";
import type { ReportContext } from "../../lib/reports/types";
import { SchoolNameTag } from "../RegionTag";

const BADGE_OF_CAT: Record<string, "rush" | "steady" | "safe"> = { 冲: "rush", 稳: "steady", 保: "safe" };

export function SortReport({ ctx, profile }: { ctx: ReportContext; profile: ReportProfile }) {
  const d = buildSort(profile);
  const identity = [
    { label: "学生", value: ctx.studentName },
    { label: "预估分", value: `${ctx.score}分` },
    { label: "稳定位次", value: ctx.rank },
    { label: "方案版本", value: "V1.0" },
    { label: "生成时间", value: ctx.generatedAt },
  ];

  return (
    <ReportShell
      accent="sort-report"
      brand="LAOYOU · VOLUNTEER PLAN"
      tierLabel="29.9元 · 完整排序"
      eyebrow="回答你的第二个问题"
      title={<>学校已经知道了，<br />志愿到底怎么排？</>}
      subtitle="把全部候选学校整理成一份有上限、有主选、有退路的志愿草案，并说明每个顺序为什么这样放。"
      identity={identity}
    >
      <Section no="01 · 最终排序结论" title={`建议采用“${d.chong}冲＋${d.wen}主选＋${d.bao}保底”`}>
        <Summary strong="前两位争取上限，中间承接主要录取机会，最后确保方案有退路。">
          不要把多所风险相近的热门学校全部当成“主选”，否则看似选择很多，实际可能同时落空。
        </Summary>
        <KpiGrid
          items={[
            { label: "冲刺志愿", value: `${d.chong}个` },
            { label: "主选志愿", value: `${d.wen}个` },
            { label: "保底志愿", value: `${d.bao}个` },
          ]}
        />
      </Section>

      <Section no="02 · 你的志愿草案" title="一张可以直接拿去讨论的顺序表">
        <Lead>以下顺序基于你的分数、位次与学校历年参考分生成；正式填报须按当年志愿数量、批次和学生条件最终确认。</Lead>
        <Timeline>
          {d.placed.map((s, i) => (
            <Step
              key={s.id}
              num={i + 1}
              title={<SchoolNameTag name={s.name} district={s.district} />}
              sub={s.reason + ` 录取概率约 ${s.prob}%。`}
              badge={<Badge kind={BADGE_OF_CAT[s.cat]}>{s.cat}</Badge>}
            />
          ))}
        </Timeline>
        <Footnote>
          录取概率为模型估算：基于考生分与学校预估投档线的分差，用 logistic 函数映射为百分比，非官方一分一段表；同一分差下每年实际录取波动较大，仅供参考，不构成录取保证。
        </Footnote>
      </Section>

      <Section no="03 · 为什么这样排" title="顺序背后的三个判断">
        <Cards>
          <Card title="先争取，再承接" highlight>
            把高风险目标放在前面尝试，但不能让后续志愿仍处在同一风险区间。
          </Card>
          <Card title="主选不能只有一所">
            招生计划和分数线会变化，至少准备两至三所风险不同的主选。
          </Card>
          <Card title="保底必须真的能接受">
            不愿意就读的学校不算保底。家庭要提前确认距离、住宿和管理。
          </Card>
          <Card title="名额不等于录取">
            定向生还受资格、校内竞争、最低条件和志愿顺序影响。
          </Card>
        </Cards>
      </Section>

      <Section no="04 · 分数变化方案" title="最终成绩变化时，不需要推倒重来">
        <Cards>
          {d.scenarios.map((sc) => (
            <Card key={sc.title} title={sc.title} badge={<Badge kind={sc.badge}>{sc.badgeText}</Badge>}>
              {sc.text}
            </Card>
          ))}
        </Cards>
      </Section>

      <Section no="05 · 定向生名额" title="你所在初中的指标计划">
        <Lead>本项目尚未接入“官方分学校生源计划”数据。系统在官方文件已发布并完成核验前，统一显示“待官方发布”，不会把全区计划写成你所在初中的名额。</Lead>
        <table className="table">
          <thead>
            <tr>
              <th>高中</th>
              <th>本初中指标</th>
              <th>资格状态</th>
              <th>建议</th>
            </tr>
          </thead>
          <tbody>
            {d.directionalRows.map((r) => (
              <tr key={r.name}>
                <td>
                  <strong>{r.name}</strong>
                  <small>{r.ownership === "private" ? "民办" : "公办"}</small>
                </td>
                <td className="locked">{r.quotaLabel}</td>
                <td>
                  <Badge kind="warn">待确认</Badge>
                </td>
                <td>{r.suggestion}</td>
              </tr>
            ))}
            {d.directionalRows.length === 0 && (
              <tr>
                <td colSpan={4} className="locked">当前区县数据中暂无带定向生名额的学校记录，待官方计划发布后更新。</td>
              </tr>
            )}
          </tbody>
        </table>
        <Source
          title="数据边界：定向生名额须以当年官方分学校生源计划为准"
          updated="核验时间：待官方发布"
        />
        <Footnote>
          竞争度需同时具备“本初中资格人数、本初中名额、校内位次”才能计算；当前数据缺失，显示“无法判断”，不生成伪精确百分比。
        </Footnote>
      </Section>

      <Section no="06 · 家庭确认" title="填报前，请全家确认四句话">
        <Checklist
          items={[
            "我们接受这两所保底学校，不会录取后再后悔。",
            "我们理解冲刺学校有落空可能，不把希望只押在一处。",
            "我们已经核验定向生资格，而不是只看到“有名额”。",
            "最终成绩和位次公布后，会重新校准一次方案。",
          ]}
        />
      </Section>

      <Closing
        title="你的第二个问题，已经解决"
        text="你现在拥有一份能够讨论、修改和最终确认的志愿草案。下一步不是继续搜集无限资料，而是完成家庭确认，并在最终成绩公布后校准一次。"
        actionLabel="保存我的志愿草案"
        onAction={() => window.print()}
        disclaimer="说明：本报告用于志愿决策辅助，不构成录取承诺。具体批次、顺序规则、招生计划和定向生名额以当年官方文件为准。"
      />
    </ReportShell>
  );
}

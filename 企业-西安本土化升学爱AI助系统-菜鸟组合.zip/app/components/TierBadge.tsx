// 办学层级徽标：学校名前展示「示」(省示范) / 「标」(省标) / 「普」(普高)
// 省示范 = 金棕底（#a16207），省标 = 蓝底（#1d4ed8），普高 = 灰底（#6b7280），与站点配色协调
import { type TierOption } from "../lib/volunteer-data";

const TIER_META: Record<string, { label: string; bg: string }> = {
  省示范: { label: "示", bg: "#a16207" },
  省标: { label: "标", bg: "#1d4ed8" },
  普高: { label: "普", bg: "#6b7280" },
};

export default function TierBadge({
  tier,
  className = "",
}: {
  tier?: string;
  className?: string;
}) {
  const meta = tier ? TIER_META[tier] : undefined;
  if (!meta) return null;
  return (
    <span
      title={tier as string}
      className={
        "inline-grid h-[1.15rem] w-[1.15rem] shrink-0 place-items-center rounded-md text-[0.7rem] font-black leading-none text-white " +
        className
      }
      style={{ backgroundColor: meta.bg }}
      aria-label={tier as string}
    >
      {meta.label}
    </span>
  );
}

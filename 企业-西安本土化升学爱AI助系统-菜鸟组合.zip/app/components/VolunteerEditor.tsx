"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { schools, type School, estimateRank, isVerifiedPlan, classifySchool, admissionProbability } from "../lib/volunteer-data";
import OwnershipBadge from "./OwnershipBadge";
import { SchoolNameTag } from "./RegionTag";

export type VRow = {
  id: string;
  name: string;
  code: string;
  ref: number;
  rank?: number;
  ownership?: "public" | "private";
  district?: string;
};

// 行内学校搜索/输入选择器：输入或点击建议选中后，由父级自动带出代码、参考分、性质
// dataDistrict 用于招生单元隔离（城六区/长安/西咸），只返回对应区县的高中。
export function SchoolSelect({
  value,
  onInput,
  onPick,
  dataDistrict,
}: {
  value: string;
  onInput: (v: string) => void;
  onPick: (s: School) => void;
  dataDistrict?: string;
}) {
  const [q, setQ] = useState(value);
  const [open, setOpen] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => setQ(value), [value]);

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const pool = useMemo(
    () => (dataDistrict ? schools.filter((s) => s.district === dataDistrict && s.schoolType !== "junior") : schools.filter((s) => s.schoolType !== "junior")),
    [dataDistrict]
  );

  const list = useMemo(() => {
    const kw = q.trim();
    const base = kw ? pool.filter((s) => s.name.includes(kw) || s.code.includes(kw)) : pool;
    return base.slice(0, 20);
  }, [q, pool]);

  return (
    <div className="relative" ref={boxRef}>
      <input
        value={q}
        onFocus={() => setOpen(true)}
        onChange={(e) => {
          const v = e.target.value;
          setQ(v);
          onInput(v);
          const s = pool.find((x) => x.name === v);
          if (s) onPick(s);
        }}
        placeholder="输入或搜索学校名称"
        className="w-full rounded-lg border border-[#d9d2c8] bg-[#fdfbf8] px-2.5 py-2 text-sm outline-none focus:border-[#b94f38]"
      />
      {open && (
        <div className="absolute z-30 mt-1 max-h-60 w-full overflow-auto rounded-xl border border-[#ede8e0] bg-white shadow-[0_12px_32px_rgba(16,35,61,.12)]">
          {list.length === 0 ? (
            <div className="px-3 py-2 text-xs text-[#9ca3af]">未找到匹配学校</div>
          ) : (
            list.map((s) => (
              <button
                key={s.id}
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  onPick(s);
                  setQ(s.name);
                  setOpen(false);
                }}
                className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-xs hover:bg-[#f7f3ec]"
              >
                <span className="flex min-w-0 items-center gap-1.5">
                  <SchoolNameTag name={s.name} district={s.district} className="truncate" />
                  {s.schoolType === "comprehensive" && s.pairHigh && (
                    <span className="shrink-0 rounded bg-[#eaf2ff] px-1.5 py-0.5 text-[10px] font-bold text-[#2b6cb0]">↔{s.pairHigh}</span>
                  )}
                  {!isVerifiedPlan(s) && (
                    <span className="shrink-0 rounded bg-[#f3f4f6] px-1.5 py-0.5 text-[10px] font-bold text-[#9ca3af]">待核验</span>
                  )}
                </span>
                <span className="shrink-0 font-mono text-[#9ca3af]">
                  {s.code ? s.code + " · " : ""}
                  {s.referenceScore ? s.referenceScore + "分" : s.schoolType === "vocational" ? "职高" : s.schoolType === "comprehensive" ? "综高" : "—"}
                </span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}

export function VolunteerBatchEditor({
  title,
  need,
  tip,
  slots,
  rows,
  onChange,
  disabled,
  dataDistrict,
  score,
}: {
  title: string;
  need: string;
  tip?: string;
  slots: number;
  rows: VRow[];
  onChange: (rows: VRow[]) => void;
  disabled?: boolean;
  dataDistrict?: string;
  score?: number;
}) {
  const [dragIdx, setDragIdx] = useState<number | null>(null);

  function update(idx: number, patch: Partial<VRow>) {
    onChange(rows.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
  }
  function pick(idx: number, s: School) {
    update(idx, {
      id: s.id,
      name: s.name,
      code: s.code,
      ref: s.referenceScore,
      rank: estimateRank(s.referenceScore, s.district).rank,
      ownership: s.ownership,
      district: s.district,
    });
  }
  function clearRow(idx: number) {
    update(idx, { id: "", name: "", code: "", ref: 0, rank: 0, ownership: undefined });
  }
  function move(idx: number, dir: -1 | 1) {
    const j = idx + dir;
    if (j < 0 || j >= rows.length) return;
    const next = [...rows];
    [next[idx], next[j]] = [next[j], next[idx]];
    onChange(next);
  }
  function onDrop(target: number) {
    if (dragIdx === null || dragIdx === target) {
      setDragIdx(null);
      return;
    }
    const next = [...rows];
    const [m] = next.splice(dragIdx, 1);
    next.splice(target, 0, m);
    onChange(next);
    setDragIdx(null);
  }

  const display = [...rows];
  while (display.length < slots) display.push({ id: "", name: "", code: "", ref: 0, ownership: undefined });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-[#10233d]">{title}</h3>
        <span className="rounded-full bg-[#e5f0ee] px-2 py-0.5 text-[10px] font-bold text-[#1f4a44]">{need}</span>
      </div>
      {tip && (
        <p className="mt-1 flex items-start gap-1 text-[11px] text-[#4e8b84]">
          <svg className="mt-0.5 h-3 w-3 shrink-0" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2a10 10 0 100 20 10 10 0 000-20zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" />
          </svg>
          <span>{tip}</span>
        </p>
      )}

      <div className="mt-2 space-y-2">
        {display.map((r, i) => (
          <div
            key={i}
            draggable={!disabled}
            onDragStart={() => setDragIdx(i)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => onDrop(i)}
            className={`rounded-xl border bg-white p-2.5 ${
              dragIdx === i ? "border-[#b94f38]" : "border-[#ede8e0]"
            } ${disabled ? "opacity-70" : ""}`}
          >
            <div className="flex items-center gap-2">
              <span className={`shrink-0 select-none text-[#cbb3aa] ${disabled ? "cursor-not-allowed" : "cursor-grab"}`} title="拖动调整顺序">
                ⠿
              </span>
              <span className="w-12 shrink-0 text-xs font-bold text-[#10233d]">第{i + 1}志愿</span>
              <div className="min-w-0 flex-1">
                {disabled ? (
                  <div className="rounded-lg bg-[#fdfbf8] px-2.5 py-2 text-sm text-[#10233d]">
                    {r.name ? (
                      <SchoolNameTag name={r.name} district={r.district || ""} />
                    ) : (
                      <span className="text-[#9ca3af]">（未选择）</span>
                    )}
                  </div>
                ) : (
                  <SchoolSelect
                    value={r.name}
                    onInput={(v) => update(i, { name: v, id: "", code: "", ref: 0, ownership: undefined })}
                    onPick={(s) => pick(i, s)}
                    dataDistrict={dataDistrict}
                  />
                )}
              </div>
              <div className="flex shrink-0 flex-col gap-0.5">
                <button
                  type="button"
                  disabled={disabled}
                  onClick={() => move(i, -1)}
                  className="rounded border border-[#ede8e0] px-1.5 py-0.5 text-[10px] text-[#667487] disabled:opacity-40"
                >
                  ↑
                </button>
                <button
                  type="button"
                  disabled={disabled}
                  onClick={() => move(i, 1)}
                  className="rounded border border-[#ede8e0] px-1.5 py-0.5 text-[10px] text-[#667487] disabled:opacity-40"
                >
                  ↓
                </button>
              </div>
            </div>
            <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 pl-7 text-[11px] text-[#667487]">
              <span>
                代码：<b className="font-mono text-[#10233d]">{r.code || "—"}</b>
              </span>
              <span>
                去年参考分：<b className="text-[#10233d]">{r.ref || "—"}</b>
              </span>
              <span>
                位次：<b className="text-[#10233d]">{r.rank ? r.rank.toLocaleString() : "—"}</b>
              </span>
              {r.ownership && <OwnershipBadge ownership={r.ownership} />}
              {r.name && score != null && (() => {
                const cat = classifySchool(score, r.ref);
                const prob = admissionProbability(score, r.ref);
                const catStyle =
                  cat === "冲"
                    ? "bg-[#fde8dd] text-[#c2410c]"
                    : cat === "稳"
                      ? "bg-[#e5f0ee] text-[#1f4a44]"
                      : "bg-[#eaf2fb] text-[#1d4ed8]";
                return (
                  <span className={"rounded-full px-2 py-0.5 text-[10px] font-bold " + catStyle}>
                    {cat}·录取≈{prob}%
                  </span>
                );
              })()}
              {r.name && !disabled && (
                <button type="button" onClick={() => clearRow(i)} className="ml-auto text-[#b94f38] underline">
                  清空
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

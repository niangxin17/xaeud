// 阶段交接说明信息卡（成长地图 ↔ 中考志愿系统）。
//
// 纯展示组件：不读取/写入任何浏览器存储、不发起网络请求、不收集或传递任何用户数据、
// 不进行任何跳转。仅用于向用户说明两个系统之间的关系与边界。
//
// 注意：本组件不得包含任何以下禁用表述：内部名额、关系运作、付费保录、
// 录取概率承诺、学校排名、虚假用户案例。

type Props = {
  /** compact=true 时输出单行精简说明，适合在中考系统返回横幅中复用 */
  compact?: boolean;
};

const POINTS = [
  "成长地图与中考志愿系统是同一平台的不同阶段工具，各自独立使用。",
  "中考测算以你在中考系统填写的分数、位次与志愿数据为准。",
  "成长地图的家庭档案不会自动传递，不会传入中考测算系统。",
  "政策、招生与录取信息以官方最新公布为准。",
  "平台不承诺任何录取结果。",
];

export default function EducationStageBridge({ compact = false }: Props) {
  if (compact) {
    return (
      <p className="text-xs leading-relaxed text-[#9ca3af]">
        成长地图与中考志愿系统为同一平台的不同阶段工具；家庭档案不会自动传递，中考测算以你在中考系统填写的数据为准，结果以官方公布为准，平台不承诺录取结果。
      </p>
    );
  }

  return (
    <div className="rounded-xl border border-[#ede8e0] bg-[#f7f3ec] p-5">
      <h2 className="text-sm font-bold text-[#10233d]">阶段交接说明</h2>
      <ul className="mt-3 space-y-2 text-sm leading-relaxed text-[#4b5563]">
        {POINTS.map((p, i) => (
          <li key={i} className="flex gap-2">
            <span aria-hidden className="mt-1 inline-block h-1.5 w-1.5 shrink-0 rounded-full bg-[#b94f38]" />
            <span>{p}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

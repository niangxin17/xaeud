"use client";

import { districtLabelOf } from "../lib/volunteer-data";

// 学校名 + 悬浮显示所属区域（招生单元）。
// 默认不显示区域，鼠标悬停（含触屏长按）才弹出“所属区域：XX区/县”，满足“打标签、不直接显示”的要求。
export function SchoolNameTag({
  name,
  district,
  className = "",
}: {
  name: string;
  district: string;
  className?: string;
}) {
  const region = districtLabelOf(district);
  return (
    <span
      className={"group/region relative inline-flex cursor-help items-center " + className}
      title={"所属区域：" + region}
    >
      {name}
      <span className="pointer-events-none absolute left-0 top-full z-50 mt-1 hidden whitespace-nowrap rounded-md bg-[#10233d] px-2 py-1 text-xs font-medium text-white shadow-lg group-hover/region:block">
        所属区域：{region}
      </span>
    </span>
  );
}

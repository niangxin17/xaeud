"use client";

export default function Logo({ className = "" }: { className?: string }) {
  return (
    <div className={"flex items-center gap-2.5 " + className}>
      <img
        src="/images/logo.png"
        alt="西安中考志愿"
        width={180}
        height={151}
        className="h-9 w-auto shrink-0"
        draggable={false}
      />
      <span className="text-[1.05rem] font-black tracking-[-0.01em] text-[#10233d]">西安中考志愿</span>
    </div>
  );
}

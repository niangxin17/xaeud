import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Analytics from "./analytics";
import SiteNav from "./components/SiteNav";
import WeChatShareInitializer from "./components/WeChatShareInitializer";
const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });
export const metadata: Metadata = {
  metadataBase: new URL("https://laoyou.love"),
  title: {
    default: "西安中考志愿｜输入分数，找到更适合的高中",
    template: "%s｜西安中考志愿",
  },
  description: "西安中考分数定位、学校匹配、志愿方案、学校适配与老师复核一站式平台。",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
  openGraph: {
    type: "website",
    locale: "zh_CN",
    url: "https://laoyou.love/",
    siteName: "西安中考志愿",
    title: "西安中考志愿｜输入分数，找到更适合的高中",
    description: "西安中考分数定位、学校匹配、志愿方案、学校适配与老师复核一站式平台。",
    images: [{ url: "/share-cover.png", width: 1200, height: 630, alt: "西安中考志愿" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "西安中考志愿｜输入分数，找到更适合的高中",
    description: "西安中考分数定位、学校匹配、志愿模拟与升学规划平台",
    images: ["/share-cover.png"],
  },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body className={geistSans.variable + " " + geistMono.variable + " antialiased"}>
        <meta name="codex-preview" content="development" />
        <SiteNav />
        {children}
        <footer className="border-t border-[#ede8e0] bg-[#f7f3ec]">
          <div className="mx-auto flex max-w-[1080px] flex-wrap items-center gap-x-6 gap-y-2 px-5 py-6 text-sm text-[#6b7280]">
            <span className="font-bold text-[#10233d]">西安中考志愿</span>
            <a href="/zhengce" className="text-[#4b5563] transition hover:text-[#b94f38]">
              官方政策与招生计划
            </a>
            <a href="/privacy" className="text-[#4b5563] transition hover:text-[#b94f38]">
              隐私政策
            </a>
            <span className="ml-auto text-xs text-[#9ca3af]">
              数据来源：西安市教育局等官方渠道，仅供参考，请以官方平台为准
            </span>
          </div>
          <div className="mx-auto max-w-[1080px] px-5 pb-6 text-xs text-[#9ca3af]">
            <a
              href="https://beian.miit.gov.cn/"
              target="_blank"
              rel="noopener noreferrer"
              className="transition hover:text-[#b94f38]"
            >
              陕ICP备2024037631号
            </a>
          </div>
        </footer>
        <Analytics />
        <WeChatShareInitializer />
      </body>
    </html>
  );
}
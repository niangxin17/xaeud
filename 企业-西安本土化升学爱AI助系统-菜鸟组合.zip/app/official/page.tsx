"use client";

import { useEffect, useMemo, useState } from "react";
import { getProfileLock } from "../lib/profile-lock";
import { getOwnership, ownershipLabel } from "../lib/volunteer-data";
import OwnershipBadge from "../components/OwnershipBadge";

const DISTRICTS: Record<string, string> = {
  xincheng: "新城区", beilin: "碑林区", lianhu: "莲湖区", yanta: "雁塔区",
  weiyang: "未央区", bashan: "灞桥区", xixian: "西咸新区", changan: "长安区",
};

const officialSystemUrl =
  process.env.NEXT_PUBLIC_OFFICIAL_SYSTEM_URL || "https://www.sneac.com/";

const RISK_TEXT: Record<string, string> = {
  冲: "冲刺", 稳: "稳妥", 保: "保底",
};

type Row = { batch: number; order: number; name: string; code: string; ref: number; risk: string };

export default function OfficialPage() {
  const [lock, setLock] = useState<ReturnType<typeof getProfileLock>>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setLock(getProfileLock());
    try {
      setRows(JSON.parse(localStorage.getItem("ly_filing_rows") || "[]"));
    } catch {
      setRows([]);
    }
  }, []);

  const districtLabel = lock ? DISTRICTS[lock.district] || lock.district : "—";

  const officialText = useMemo(() => {
    const head = [
      "【陕西中考志愿填报准备】",
      `分数：${lock?.score ?? "—"}`,
      `所在区县：${districtLabel}`,
      `就读初中：${lock?.juniorSchool ?? "—"}`,
      lock?.directionalSchool ? `定向学校：${lock.directionalSchool}` : "",
    ].filter(Boolean).join("\n");
    const body = rows
      .map((r) => {
        const own = ownershipLabel(getOwnership(r.name, r.code));
        return `批次${r.batch} 第${r.order}志愿 ${own ? own + " " : ""}${r.name}（代码 ${r.code || "—"}） 去年参考分 ${r.ref} ${RISK_TEXT[r.risk] || ""}`;
      })
      .join("\n");
    return head + "\n\n" + (body || "（尚未生成志愿方案）");
  }, [lock, rows, districtLabel]);

  function copyAll() {
    navigator.clipboard?.writeText(officialText).then(
      () => { setCopied(true); setTimeout(() => setCopied(false), 2000); },
      () => alert("复制失败，请手动选择复制。")
    );
  }

  return (
    <main className="min-h-screen bg-[#f7f3ec] px-5 py-8 text-[#10233d]">
      <div className="mx-auto max-w-3xl">
        <span className="text-xs font-bold tracking-[.16em] text-[#b94f38]">官方入口</span>
        <h1 className="mt-3 text-3xl font-black">陕西官方填报入口准备区</h1>
        <p className="mt-2 text-sm text-[#667487]">
          本页不是伪造的官方系统，而是你正式填报前的「准备区」：核对资料、整理志愿、一键复制，再到官方系统自行提交。
        </p>

        {/* 流程 */}
        <ol className="mt-5 flex flex-wrap gap-2 text-xs text-[#4b5563]">
          {["站内生成志愿", "核对锁定资料", "核对学校名称与代码", "复制全部信息", "打开陕西官方系统", "用户自行登录/填写/提交"].map((s, i) => (
            <li key={i} className="rounded-full bg-white px-3 py-1.5 shadow-[0_8px_20px_rgba(16,35,61,.05)]">{i + 1}. {s}</li>
          ))}
        </ol>

        {/* 锁定资料核对 */}
        <section className="mt-5 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <h2 className="text-lg font-bold">核对锁定资料</h2>
          <div className="mt-2 grid grid-cols-2 gap-y-1 text-sm text-[#4b5563] sm:grid-cols-4">
            <span>分数：<b>{lock?.score ?? "—"}</b></span>
            <span>区县：<b>{districtLabel}</b></span>
            <span>初中：<b>{lock?.juniorSchool ?? "—"}</b></span>
            <span>定向：<b>{lock?.directionalSchool ?? "未选"}</b></span>
          </div>
        </section>

        {/* 已选学校 */}
        <section className="mt-4 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <h2 className="text-lg font-bold">已选择的学校</h2>
          {rows.length === 0 ? (
            <p className="mt-2 text-sm text-[#9ca3af]">尚未生成志愿方案。请先在「填报」页生成或填写。</p>
          ) : (
            <div className="mt-3 space-y-2">
              {rows.map((r, i) => (
                <div key={i} className="flex items-center justify-between rounded-xl bg-[#f7f3ec] px-4 py-2.5 text-sm">
                  <span className="flex min-w-0 items-center gap-1.5">批次{r.batch} 第{r.order}志愿 <OwnershipBadge ownership={getOwnership(r.name, r.code)} /><b>{r.name}</b></span>
                  <span className="ml-2 shrink-0 font-mono text-xs text-[#10233d]">代码 {r.code || "—"} · {r.ref}分 · {RISK_TEXT[r.risk] || r.risk}</span>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* 复制 + 打开 */}
        <section className="mt-4 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <h2 className="text-lg font-bold">复制与提交</h2>
          <pre className="mt-3 max-h-64 overflow-auto whitespace-pre-wrap rounded-xl bg-[#f7f3ec] p-4 text-xs leading-relaxed text-[#4b5563]">{officialText}</pre>
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" onClick={copyAll} className="rounded-xl bg-[#4e8b84] px-4 py-2.5 text-sm font-bold text-white transition hover:bg-[#3f756f]">
              {copied ? "已复制 ✓" : "复制全部填报信息"}
            </button>
            <a href={officialSystemUrl} target="_blank" rel="noopener noreferrer" className="rounded-xl border border-[#10233d]/20 px-4 py-2.5 text-sm font-bold text-[#10233d] transition hover:bg-[#f3f4f6]">
              打开陕西官方系统
            </a>
          </div>
        </section>

        <p className="mt-5 rounded-xl bg-[#fff7f2] p-4 text-xs leading-relaxed text-[#9ca3af]">
          本站不代替官方系统进行登录、身份验证或正式提交。如未来获得官方授权接口，将单独开发官方接口适配器，不会通过抓包、模拟登录、验证码绕过或非授权方式接入。
        </p>
      </div>
    </main>
  );
}

import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "官方招生信息",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import EducationStageBridge from "../components/EducationStageBridge";
import {
  packageRules,
  canGeneratePlan,
  getSimulationLabel,
  type PackageId,
} from "../lib/entitlements";
import { getProfileLock, getSimUsed, incSimUsed } from "../lib/profile-lock";
import {
  schools,
  getFreeMatchedSchools,
  classifySchool,
  admissionProbability,
  getOwnership,
  ownershipLabel,
  estimateRank,
  DISTRICT_TO_DATA,
  TIER_OPTIONS,
  DATA_SOURCE_STATEMENT,
} from "../lib/volunteer-data";
import { POLICY_TIMES } from "../lib/policy-times";
import { VolunteerBatchEditor, SchoolSelect, type VRow } from "../components/VolunteerEditor";
import OwnershipBadge from "../components/OwnershipBadge";

const DISTRICTS: Record<string, string> = {
  xincheng: "新城区", beilin: "碑林区", lianhu: "莲湖区", yanta: "雁塔区",
  weiyang: "未央区", bashan: "灞桥区", xixian: "西咸新区", changan: "长安区",
};

// 2026 年西安市官方填报入口（城六区与独立单元统一平台）
const officialSystemUrl = "https://222.91.162.190:91/";

// 城六区 2026 填报窗口（真实信息，以官方公布为准）
const CITY6_START = new Date("2026-07-18T08:00:00+08:00");
const CITY6_END = new Date("2026-07-20T18:00:00+08:00");

const RISK_TEXT: Record<string, string> = {
  冲: "冲刺：录取有机会，但存在风险",
  稳: "稳妥：分数和位次较匹配",
  保: "保底：录取概率相对更高",
};

const FAQ = [
  {
    q: "忘记登录密码怎么办？",
    a: "在填报时间内，可持准考证或身份证（户口本）到区县招生办（教育考试管理中心）书面申请恢复初始密码，并及时登录修改。",
  },
  {
    q: "报名号 / 准考证号是什么？",
    a: "报名号是中考报名时由学校发放的 12 位编号；准考证号印在准考证上。登录中招管理系统时使用其中一项加自设密码。",
  },
  {
    q: "第一批次、第二批次分别要填几所？",
    a: "城六区：第一批次为 3 所省级示范高中志愿，须至少填报 2 所；第二批次为 4 所省级标准化高中及其他普通高中志愿，须填满 4 所，方可提交。",
  },
  {
    q: "平行志愿是怎么录取的？",
    a: "同一批次选报的学校为平行志愿，录取按“分数优先、遵循志愿”原则依次检索。高分考生先被投档，再按其志愿顺序匹配。仍建议志愿间拉开梯度，避免滑档。",
  },
  {
    q: "定向生（指标到校）能报几所？",
    a: "定向生类志愿每生限报 1 所学校，须与就读初中获得的定向名额对应，按区县与初中资格填报。定向生通常单独作为一个志愿栏，不占用普通批次名额。",
  },
  {
    q: "保存后、确认后还能修改吗？",
    a: "填写过程中点“保存”后可再次修改；但最后一步输入身份证号“确认”后，志愿即生效，任何人不得更改。截止前未确认的，系统不默认提交，所填志愿无效——请务必主动确认。",
  },
];

const emptyRow = (): VRow => ({ id: "", name: "", code: "", ref: 0, ownership: undefined });

export default function FilingPage() {
  const [pkg, setPkg] = useState<PackageId>("free");
  const [lock, setLock] = useState<ReturnType<typeof getProfileLock>>(null);
  const [b1, setB1] = useState<VRow[]>(() => Array.from({ length: 3 }, emptyRow));
  const [b2, setB2] = useState<VRow[]>(() => Array.from({ length: 4 }, emptyRow));
  const [dir, setDir] = useState<VRow | null>(null);
  const [genMsg, setGenMsg] = useState("");
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [countdown, setCountdown] = useState("");

  // 精准推荐筛选（考试年份固定 2026；招生单元由已锁定区县决定；可叠加学校性质 / 学校层级）
  const [fOwnership, setFOwnership] = useState<"all" | "public" | "private">("all");
  const [fTier, setFTier] = useState<"all" | "省示范" | "省标" | "普高">("all");

  useEffect(() => {
    const l = getProfileLock();
    setLock(l);
    setPkg(l?.packageId || "free");
  }, []);

  // 倒计时（client-only）
  useEffect(() => {
    function calc() {
      const now = new Date();
      if (now < CITY6_START) {
        const days = Math.max(0, Math.ceil((CITY6_START.getTime() - now.getTime()) / 86400000));
        setCountdown(`城六区志愿填报 ${CITY6_START.getMonth() + 1}月${CITY6_START.getDate()}日 8:00 开始，还剩约 ${days} 天`);
      } else if (now <= CITY6_END) {
        setCountdown("城六区志愿填报进行中，请在 7月20日 18:00 前完成确认提交");
      } else {
        setCountdown("城六区志愿填报已结束，请以官方最新公告为准");
      }
    }
    calc();
    const t = setInterval(calc, 60000);
    return () => clearInterval(t);
  }, []);

  const rule = packageRules[pkg];
  const used = getSimUsed(pkg);
  const canGenerate = canGeneratePlan(pkg, used);

  const districtLabel = lock ? DISTRICTS[lock.district] || lock.district : "—";
  const dataDistrict = lock ? DISTRICT_TO_DATA[lock.district] || "chengliuqu" : "chengliuqu";

  // 合并所有已填行，持久化 + 生成文本
  const filled = useMemo(() => {
    const out: { batch: number; order: number; name: string; code: string; ref: number }[] = [];
    b1.filter((r) => r.name).forEach((r, i) => out.push({ batch: 1, order: i + 1, ...r }));
    b2.filter((r) => r.name).forEach((r, i) => out.push({ batch: 2, order: i + 1, ...r }));
    if (dir?.name) out.push({ batch: 0, order: 1, ...dir });
    return out;
  }, [b1, b2, dir]);

  useEffect(() => {
    if (typeof window !== "undefined") localStorage.setItem("ly_filing_rows", JSON.stringify(filled));
  }, [filled]);

  function generate() {
    if (!canGenerate) {
      if (pkg === "free") setGenMsg("免费用户可以体验填报交互，解锁 29.9 元套餐后可使用“智能生成方案”一键推荐。");
      else setGenMsg(`本套餐模拟次数已用完（${getSimulationLabel(pkg, used)}）。`);
      return;
    }
    if (!lock) {
      setGenMsg("请先在首页完成测分并确认资料，再生成志愿方案。");
      return;
    }
    const score = Number(lock.score);
    const dataDistrict = DISTRICT_TO_DATA[lock.district] || "chengliuqu";
    const matched = getFreeMatchedSchools(score, dataDistrict, schools, {
      ownership: fOwnership === "all" ? undefined : fOwnership,
      tier: fTier === "all" ? undefined : fTier,
    });
    const toV = (s: typeof matched[number]): VRow => ({
      id: s.id,
      name: s.name,
      code: s.code,
      ref: s.referenceScore,
      rank: estimateRank(s.referenceScore, s.district).rank,
      ownership: s.ownership,
    });
    const b1src = matched.filter((s) => s.batch === 1).slice(0, 3);
    const b2src = matched.filter((s) => s.batch === 2).slice(0, 4);
    const n = incSimUsed(pkg);
    setB1([...b1src.map(toV), ...Array.from({ length: Math.max(0, 3 - b1src.length) }, emptyRow)]);
    setB2([...b2src.map(toV), ...Array.from({ length: Math.max(0, 4 - b2src.length) }, emptyRow)]);
    setGenMsg(`已生成第 ${n} 次志愿方案（示范高中 ${b1src.length} 所、普高 ${b2src.length} 所，可拖动调整顺序）。`);
  }

  const officialText = useMemo(() => {
    const head = [
      "【陕西中考志愿填报准备】",
      `分数：${lock?.score ?? "—"}`,
      `所在区县：${districtLabel}`,
      `就读初中：${lock?.juniorSchool ?? "—"}`,
      lock?.directionalSchool ? `定向学校：${lock.directionalSchool}` : "",
    ].filter(Boolean).join("\n");
    const body = filled
      .map((r) => {
        const own = ownershipLabel(getOwnership(r.name, r.code));
        const scoreNum = Number(lock?.score || 0);
        const cat = r.batch === 0 ? "定向" : classifySchool(scoreNum, r.ref);
        const risk = r.batch === 0 ? "定向" : RISK_TEXT[cat] || "";
        const probText = r.batch === 0 ? "" : `录取概率约${admissionProbability(scoreNum, r.ref)}%`;
        const label = r.batch === 0 ? "定向生" : `批次${r.batch} 第${r.order}志愿`;
        return `${label} ${own ? own + " " : ""}${r.name}（代码 ${r.code || "—"}） 去年参考分 ${r.ref} ${risk}${probText ? " " + probText : ""}`;
      })
      .join("\n");
    return head + "\n\n" + (body || "（尚未填写志愿）");
  }, [lock, filled, districtLabel]);

  function copyAll() {
    navigator.clipboard?.writeText(officialText).then(
      () => setGenMsg("已复制全部填报信息到剪贴板。"),
      () => setGenMsg("复制失败，请手动选择复制。")
    );
  }

  return (
    <main className="min-h-screen bg-[#f7f3ec] px-5 py-8 text-[#10233d]">
      {/* 返回长安成长地图（成长地图家庭档案不会恢复，属预期隐私行为） */}
      <div className="mx-auto mb-4 max-w-3xl">
        <Link
          href="/growth"
          className="inline-flex items-center gap-1.5 rounded-xl border border-[#ede8e0] bg-white px-4 py-2.5 text-sm font-semibold text-[#4b5563] transition hover:bg-[#f3f4f6]"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
          返回长安成长地图
        </Link>
        <div className="mt-2">
          <EducationStageBridge compact />
          <p className="mt-1 text-xs text-[#9ca3af]">
            返回后成长地图的家庭档案不会恢复，这是预期隐私行为。
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-3xl">
        <span className="text-xs font-bold tracking-[.16em] text-[#b94f38]">填报</span>
        <h1 className="mt-3 text-3xl font-black">志愿填报</h1>

        {/* 0. 填报时间提醒条 */}
        <div className="mt-4 flex items-center gap-2 rounded-2xl bg-[#10233d] px-4 py-3 text-white">
          <svg className="h-4 w-4 shrink-0 text-[#f3c766]" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2a10 10 0 100 20 10 10 0 000-20zm1 11h-5v-2h3V7h2v6z" />
          </svg>
          <span className="text-sm font-bold">{countdown || "加载填报时间…"}</span>
        </div>
        <p className="mt-1 px-1 text-[11px] text-[#9ca3af]">填报时间以西安市教育考试中心当年公布为准；独立单元（五区二县+西咸新区）为 7月21日–23日。</p>

        {/* 1. 锁定信息 */}
        <div className="mt-5 rounded-2xl bg-white p-5 text-sm shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <div className="font-bold text-[#10233d]">本次填报依据（已锁定，不可修改）：</div>
          <div className="mt-2 grid grid-cols-2 gap-y-1 text-[#4b5563] sm:grid-cols-4">
            <span>分数：<b>{lock?.score ?? "—"}</b></span>
            <span>区县：<b>{districtLabel}</b></span>
            <span>初中：<b>{lock?.juniorSchool ?? "—"}</b></span>
            <span>定向：<b>{lock?.directionalSchool ?? "未选"}</b></span>
          </div>
        </div>

        {/* 2. 本页定位引导条 */}
        <div className="mt-4 flex items-start gap-2 rounded-2xl bg-[#fff7f2] px-4 py-3 text-sm text-[#b94f38]">
          <svg className="mt-0.5 h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2 1 21h22L12 2zm0 6 1 7h-2l1-7zm0 9.5a1.3 1.3 0 110 2.6 1.3 1.3 0 010-2.6z" />
          </svg>
          <span><b>本站仅用于预览、生成与核对志愿方案。</b>以下为官方填报系统的交互还原，可拖拽排序、搜索选校；正式登录、身份验证与最终提交请到西安市官方平台完成。</span>
        </div>

        {/* 3. 高仿真填报系统界面还原卡（可交互） */}
        <section className="mt-4 overflow-hidden rounded-2xl border border-[#10233d]/15 bg-white shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <div className="relative bg-[#10233d] px-5 py-3">
            <div className="text-sm font-bold text-white">西安市初中学业水平考试招生管理平台</div>
            <div className="mt-0.5 text-[11px] text-white/60">志愿填报 · 交互还原（1比1官方还原）</div>
            <span className="absolute right-3 top-3 rounded-full bg-[#b94f38] px-2.5 py-1 text-[10px] font-bold text-white">中考志愿填报系统</span>
          </div>

          <div className="bg-[#f7f3ec] px-5 py-2.5 text-[11px] leading-relaxed text-[#667487]">
            请在规定时间内填报：第一批次须至少填 2 所、第二批次须填满 4 所，方可提交；定向生每生限报 1 所。拖动 ⠿ 可调整志愿顺序，输入或搜索学校名称可自动带出代码。
          </div>

          <div className="space-y-5 px-5 py-4">
            <VolunteerBatchEditor
              title="第一批次 · 省级示范高中"
              need="须至少填报 2 所方可提交"
              tip="同一批次为平行志愿，按“分数优先、遵循志愿”检索，建议保持冲稳保梯度。"
              slots={3}
              rows={b1}
              onChange={setB1}
              dataDistrict={dataDistrict}
              score={lock ? Number(lock.score) : undefined}
            />
            <VolunteerBatchEditor
              title="第二批次 · 省级标准化高中及其他普通高中"
              need="须填满 4 所方可提交"
              tip="平行志愿下，志愿顺序仍有意义：把更想去、但略冒险的学校放前面。"
              slots={4}
              rows={b2}
              onChange={setB2}
              dataDistrict={dataDistrict}
              score={lock ? Number(lock.score) : undefined}
            />

            {/* 定向生栏 */}
            <div className="rounded-xl border border-[#b94f38]/30 bg-[#fff7f2] p-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[#b94f38]">定向生（指标到校）志愿</h3>
                <span className="rounded-full bg-[#b94f38] px-2 py-0.5 text-[10px] font-bold text-white">限报 1 所</span>
              </div>
              <p className="mt-1 text-[11px] text-[#b94f38]">须具备就读初中定向资格，且与资格对应学校一致；不占用普通批次名额。</p>
              <div className="mt-2">
                <SchoolSelect
                  value={dir?.name || ""}
                  onInput={(v) => setDir({ id: "", name: v, code: "", ref: 0, rank: 0, ownership: undefined })}
                  onPick={(s) => setDir({ id: s.id, name: s.name, code: s.code, ref: s.referenceScore, rank: estimateRank(s.referenceScore, s.district).rank, ownership: s.ownership })}
                  dataDistrict={dataDistrict}
                />
                {dir && (
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-[#667487]">
                    <span>代码：<b className="font-mono text-[#10233d]">{dir.code || "—"}</b></span>
                    <span>2026预估分：<b className="text-[#10233d]">{dir.ref || "—"}</b></span>
                    <span>位次：<b className="text-[#10233d]">{dir.rank ? dir.rank.toLocaleString() : "—"}</b></span>
                    {dir.ownership && <OwnershipBadge ownership={dir.ownership} />}
                    <button type="button" onClick={() => setDir(null)} className="ml-auto text-[#b94f38] underline">清空</button>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="border-t border-[#ede8e0] bg-[#f7f3ec] px-5 py-3 text-center text-[11px] text-[#667487]">
            请在本站核对完成后，点击下方“前往官方系统正式填报”按钮进入官方平台完成最终登录与提交。
          </div>
        </section>

        {/* 3.5 精准推荐筛选（考试年份固定 2026；招生单元由已锁定区县决定；可叠加性质/层级） */}
        <section className="mt-4 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <h2 className="text-lg font-bold">精准推荐筛选</h2>
          <p className="mt-1 text-xs text-[#9ca3af]">先按招生单元锁定范围，再叠加学校性质与层级，系统据此匹配 2026 计划内学校。</p>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-[#4b5563]">考试年份</label>
              <div className="rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-4 py-3 text-base font-bold text-[#10233d]">2026（仅 2026 官方计划已核验）</div>
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-[#4b5563]">招生单元</label>
              <div className="rounded-xl border border-[#ede8e0] bg-[#fdfbf8] px-4 py-3 text-base font-bold text-[#10233d]">{districtLabel || "—"}</div>
            </div>
          </div>

          <div className="mt-4">
            <label className="mb-1.5 block text-sm font-medium text-[#4b5563]">学校性质</label>
            <div className="flex gap-2">
              {([["all", "全部"], ["public", "公办"], ["private", "民办"]] as const).map(([v, label]) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => setFOwnership(v)}
                  className={`flex-1 rounded-xl border px-3 py-2.5 text-sm font-semibold transition ${
                    fOwnership === v ? "border-[#b94f38] bg-[#fff7f2] text-[#b94f38]" : "border-[#ede8e0] bg-[#fdfbf8] text-[#4b5563] hover:bg-[#f3f4f6]"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <label className="mb-1.5 block text-sm font-medium text-[#4b5563]">学校层级</label>
            <div className="flex gap-2">
              {(["all", ...TIER_OPTIONS] as const).map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => setFTier(v as typeof fTier)}
                  className={`flex-1 rounded-xl border px-3 py-2.5 text-sm font-semibold transition ${
                    fTier === v ? "border-[#b94f38] bg-[#fff7f2] text-[#b94f38]" : "border-[#ede8e0] bg-[#fdfbf8] text-[#4b5563] hover:bg-[#f3f4f6]"
                  }`}
                >
                  {v === "all" ? "全部" : v}
                </button>
              ))}
            </div>
          </div>

          <p className="mt-4 rounded-xl bg-[#f7f3ec] p-3 text-[11px] leading-relaxed text-[#667487]">
            {DATA_SOURCE_STATEMENT}
          </p>
        </section>

        {/* 4. 生成 / 操作 */}
        <div className="mt-4">
          <button
            type="button"
            disabled={!rule.canGenerate}
            onClick={generate}
            className={`w-full rounded-2xl px-5 py-4 font-bold text-white transition ${
              rule.canGenerate ? "bg-[#10233d] hover:bg-[#0c1a2c]" : "cursor-not-allowed bg-[#cbb3aa]"
            }`}
          >
            {pkg === "free"
              ? "智能生成方案（解锁后可用）"
              : pkg === "match_29_9"
              ? `智能生成方案（剩余${Math.max(0, rule.simulationLimit - used)}次）`
              : "智能生成方案"}
          </button>
          {genMsg && <p className="mt-3 rounded-xl bg-[#fff7f2] p-3 text-sm text-[#667487]">{genMsg}</p>}
        </div>

        {/* 5. 填报方法步骤条 */}
        <section className="mt-4 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <h2 className="text-lg font-bold">填报志愿的方法</h2>
          <ol className="mt-3 space-y-3">
            {[
              { t: "登录系统", d: "输入 12 位报名号/准考证号与自己设定的密码进入中招管理系统。" },
              { t: "阅读说明", d: "仔细阅读填报志愿说明，了解批次、名额与提交要求。" },
              { t: "按批次填写", d: "第一批次至少 2 所、第二批次填满 4 所；同一批次为平行志愿，注意冲稳保梯度。" },
              { t: "保存可改", d: "填写完毕点“保存”，发现有误可再次修改；保存不等于确认。" },
              { t: "填联系方式", d: "填写录取通知书接收地址等联系方式信息。" },
              { t: "身份证确认", d: "输入报名时填写的身份证号确认，志愿生效——确认后任何人不得更改。" },
            ].map((s, i) => (
              <li key={i} className="flex gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#b94f38] text-sm font-black text-white">{i + 1}</span>
                <div>
                  <div className="text-sm font-bold text-[#10233d]">{s.t}</div>
                  <div className="text-xs leading-relaxed text-[#667487]">{s.d}</div>
                </div>
              </li>
            ))}
          </ol>
          <div className="mt-3 rounded-xl bg-[#fff7f2] p-3 text-xs leading-relaxed text-[#b94f38]">
            关键提醒：截止前未确认的，系统不默认提交，所填志愿无效。请务必在 7月20日 18:00 前主动点击确认。
          </div>
        </section>

        {/* 6. 常见问题 FAQ */}
        <section className="mt-4 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <h2 className="text-lg font-bold">常见问题</h2>
          <div className="mt-3 divide-y divide-[#f3f4f6]">
            {FAQ.map((item, i) => {
              const open = openFaq === i;
              return (
                <div key={i}>
                  <button type="button" onClick={() => setOpenFaq(open ? null : i)} className="flex w-full items-center justify-between py-3 text-left">
                    <span className="pr-3 text-sm font-bold text-[#10233d]">{item.q}</span>
                    <svg className={`h-4 w-4 shrink-0 text-[#b94f38] transition-transform ${open ? "rotate-45" : ""}`} viewBox="0 0 24 24" fill="currentColor">
                      <path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6V5z" />
                    </svg>
                  </button>
                  {open && <p className="pb-3 text-xs leading-relaxed text-[#667487]">{item.a}</p>}
                </div>
              );
            })}
          </div>
        </section>

        {/* 7. 官方入口准备区 */}
        <section className="mt-4 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <h2 className="text-lg font-bold">前往官方系统正式填报</h2>
          <pre className="mt-3 max-h-48 overflow-auto whitespace-pre-wrap rounded-xl bg-[#f7f3ec] p-4 text-xs leading-relaxed text-[#4b5563]">{officialText}</pre>
          <div className="mt-3 flex flex-col gap-2 sm:flex-row">
            <a href={officialSystemUrl} target="_blank" rel="noopener noreferrer" className="flex-1 rounded-xl bg-[#b94f38] px-4 py-3 text-center text-sm font-bold text-white transition hover:bg-[#a3432f]">
              前往官方系统正式填报
            </a>
            <button type="button" onClick={copyAll} className="flex-1 rounded-xl border border-[#10233d]/20 px-4 py-3 text-center text-sm font-bold text-[#10233d] transition hover:bg-[#f3f4f6]">
              复制我的志愿方案
            </button>
          </div>
          <p className="mt-3 text-xs text-[#9ca3af]">
            本站负责生成、整理和核对志愿信息。正式登录、身份验证和最终提交请在陕西官方系统完成，不代替官方系统进行登录、身份验证或正式提交。
          </p>
        </section>

        {/* 8. 填报规则说明 */}
        <section className="mt-4 rounded-2xl bg-white p-5 shadow-[0_12px_32px_rgba(16,35,61,.06)]">
          <h2 className="text-lg font-bold">填报规则说明</h2>
          <ul className="mt-2 space-y-1.5 text-sm leading-relaxed text-[#4b5563]">
            <li><b>第一批志愿：</b>优质/示范/重点高中批次，须至少填报 2 所。</li>
            <li><b>第二批志愿：</b>普通高中及其他招生批次，须填满 4 所。</li>
            <li><b>志愿顺序：</b>录取按志愿顺序依次检索，靠前志愿先被考虑，顺序直接影响录取结果。</li>
            <li><b>冲刺志愿：</b>分数略高于自身，有机会但存在风险。</li>
            <li><b>稳妥志愿：</b>分数和位次较匹配，录取把握较大。</li>
            <li><b>保底志愿：</b>分数明显低于自身，录取概率相对更高。</li>
            <li><b>定向生填报：</b>须与就读初中获得的定向名额对应，按区县与初中资格填报，每生限报 1 所。</li>
            {POLICY_TIMES.map((p) => (
              <li key={p.key}><b>{p.label}：</b>{p.date}{p.note ? `（${p.note}）` : ""}</li>
            ))}
          </ul>
        </section>

        <p className="mt-5 text-center text-xs text-[#9ca3af]">
          本页为志愿辅助工具，所有规则与时间为公开信息整理，最终以西安市教育考试中心官方发布为准。
        </p>
      </div>
    </main>
  );
}

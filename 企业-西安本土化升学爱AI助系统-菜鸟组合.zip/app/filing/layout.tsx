import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "中考志愿模拟",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

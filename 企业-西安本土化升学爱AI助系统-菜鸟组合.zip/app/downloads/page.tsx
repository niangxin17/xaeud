"use client";
import { ReportsRenderer } from "../components/report/ReportsRenderer";

export default function DownloadsPage() {
  return <ReportsRenderer />;
}

import { JSDOM } from 'file:///C:/Users/Administrator/.workbuddy/binaries/node/workspace/node_modules/jsdom/lib/api.js';
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

const DIR = new URL('../', import.meta.url);
const indexHtml = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const indexUrl = new URL('../index.html', import.meta.url).href;

function loadWith(override) {
  return new Promise((resolve) => {
    const dom = new JSDOM(indexHtml, {
      url: indexUrl,
      runScripts: 'dangerously',
      resources: 'usable',
      beforeParse(window) {
        if (override.endpoint) window.LY_ANALYTICS_ENDPOINT = override.endpoint;
        if (override.token) window.LY_ANALYTICS_WRITE_TOKEN = override.token;
      },
    });
    dom.window.addEventListener('load', () => setTimeout(() => resolve(dom.window), 80));
  });
}

let ok = true;
function check(label, cond) {
  console.log((cond ? 'PASS' : 'FAIL') + ' - ' + label);
  if (!cond) ok = false;
}

// 1) 默认：meta 标签 /collect
const w1 = await loadWith({});
check("默认端点来自 meta = /collect", w1.LYAnalytics && w1.LYAnalytics.ENDPOINT === '/collect');
check("默认无 token 时 WRITE_TOKEN 为空串", w1.LYAnalytics && w1.LYAnalytics.WRITE_TOKEN === '');

// 2) 全局覆盖 meta
const w2 = await loadWith({ endpoint: 'https://collect.laoyou.love/collect' });
check("window.LY_ANALYTICS_ENDPOINT 覆盖 meta", w2.LYAnalytics.ENDPOINT === 'https://collect.laoyou.love/collect');

// 3) token 注入到导出
const w3 = await loadWith({ token: 'secret-write-token' });
check("window.LY_ANALYTICS_WRITE_TOKEN 注入生效", w3.LYAnalytics.WRITE_TOKEN === 'secret-write-token');

// 4) 6 个事件类型均可被 track 调用（不抛错、不污染业务）
const events = ['page_view','score_submitted','school_match_viewed','volunteer_simulation_started','volunteer_plan_generated','diagnosis_requested'];
let trackOk = true;
for (const e of events) {
  try { const r = w1.track(e, { t: 1 }); if (!r || r.event !== e) trackOk = false; }
  catch (err) { trackOk = false; }
}
check("6 个事件均可 track 且返回 record", trackOk);

console.log(ok ? '\nVERIFY ALL PASSED' : '\nVERIFY FAILED');
process.exit(ok ? 0 : 1);

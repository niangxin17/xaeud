import { JSDOM, VirtualConsole } from 'file:///C:/Users/Administrator/.workbuddy/binaries/node/workspace/node_modules/jsdom/lib/api.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

// 跨 jsdom 实例共享的 localStorage，模拟“刷新后持久化”
const sharedStorage = (() => {
  const map = new Map();
  return {
    getItem: (k) => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => map.set(k, String(v)),
    removeItem: (k) => map.delete(k),
    clear: () => map.clear(),
    key: (i) => Array.from(map.keys())[i] ?? null,
    get length() { return map.size; }
  };
})();

const errors = [];
const vc = new VirtualConsole();
vc.on('jsdomError', (e) => errors.push(e.message));

function makeDom(file, query) {
  const html = fs.readFileSync(path.resolve(root, file), 'utf8');
  return new JSDOM(html, {
    runScripts: 'dangerously',
    resources: 'usable',
    url: 'file://' + path.resolve(root, file) + (query || ''),
    virtualConsole: vc,
    beforeParse(window) {
      try { Object.defineProperty(window, 'localStorage', { value: sharedStorage, configurable: true }); }
      catch (e) { try { window.localStorage = sharedStorage; } catch (e2) {} }
    }
  });
}

let failed = 0;
function assert(cond, msg) {
  if (!cond) { console.error('  FAIL', msg); failed++; process.exitCode = 1; }
  else console.log('  PASS', msg);
}

console.log('Browser (jsdom) acceptance:');

// ---- dom1: 结果页 ----
const dom1 = makeDom('index.html');
await new Promise((r) => dom1.window.addEventListener('load', r));
const w1 = dom1.window, d1 = w1.document;

assert(d1.getElementById('summary').textContent.includes('示例测算'), '首页摘要标注示例测算');
assert(d1.querySelectorAll('#resultList .scard').length === 8, '结果页渲染 8 所学校卡片');
assert(d1.querySelectorAll('#resultList .scard.tier-冲刺').length > 0, '存在冲刺档卡片');
assert(d1.getElementById('condScoreView').textContent.includes('分'), '测算条件卡显示预估分数');
assert(d1.getElementById('sumChong').textContent === '4' && d1.getElementById('sumWen').textContent === '2' && d1.getElementById('sumBao').textContent === '2', '结果摘要三块计数正确(580分)');
assert(d1.getElementById('drawerEmpty').hidden === false, '初始为空状态时显示空状态');
assert(d1.getElementById('proBtn') && d1.getElementById('svcMask'), '专业版方案卡与服务面板存在');

// 打开服务面板（不出现价格/支付）
d1.getElementById('proBtn').dispatchEvent(new w1.MouseEvent('click', { bubbles: true }));
assert(d1.getElementById('svcMask').hidden === false, '点击了解完整志愿方案打开服务面板');
d1.getElementById('svcClose').dispatchEvent(new w1.MouseEvent('click', { bubbles: true }));
assert(d1.getElementById('svcMask').hidden === true, '服务面板可关闭');

d1.getElementById('condScore').value = '580';
d1.getElementById('applyBtn').dispatchEvent(new w1.MouseEvent('click', { bubbles: true }));
d1.querySelector('#resultList .scard button.add-btn').dispatchEvent(new w1.MouseEvent('click', { bubbles: true }));

d1.getElementById('openDrawer').dispatchEvent(new w1.MouseEvent('click', { bubbles: true }));
let items = [...d1.querySelectorAll('#drawerList li')];
assert(items.length === 1, '抽屉显示 1 条已选');
assert(items[0].getAttribute('data-seq') === '1', '抽屉首条序号=1');
assert(d1.getElementById('drawerCount').textContent === '1', '抽屉计数=1');
assert(/冲刺|稳妥|保底/.test(items[0].querySelector('.d-name').textContent), '抽屉列表显示学校定位');

const secondAdd = d1.querySelectorAll('#resultList .scard button.add-btn')[1];
secondAdd.dispatchEvent(new w1.MouseEvent('click', { bubbles: true }));
items = [...d1.querySelectorAll('#drawerList li')];
assert(items.length === 2, '抽屉显示 2 条');

const up2 = d1.querySelectorAll('#drawerList li')[1].querySelector('button'); // 第二所上移
up2.dispatchEvent(new w1.MouseEvent('click', { bubbles: true }));
items = [...d1.querySelectorAll('#drawerList li')];
assert(items[0].getAttribute('data-seq') === '1' && items.length === 2, '上移后仍有 2 条且序号连续');
assert(items[0].querySelector('button').disabled === true, '上移后首条上移按钮禁用');

const raw = sharedStorage.getItem('zk_draft_v1');
assert(raw && JSON.parse(raw).length === 2, 'localStorage 已持久化 2 条草稿');

// ---- dom2: 模拟刷新（共享 storage）----
const dom2 = makeDom('index.html');
await new Promise((r) => dom2.window.addEventListener('load', r));
const d2 = dom2.window.document;
assert(d2.getElementById('drawerCount').textContent === '2', '刷新后抽屉仍显示 2 条（持久化生效）');

// ---- detail 页 ----
const dom3 = makeDom('detail.html', '?id=s1');
await new Promise((r) => dom3.window.addEventListener('load', r));
const d3 = dom3.window.document;
assert(d3.getElementById('dName').textContent.length > 0, '详情页显示校名');
assert(d3.getElementById('dTier').textContent.length > 0, '详情页顶部显示定位标签');
assert(d3.getElementById('dConclusion').textContent.length > 0, '详情页顶部显示推荐结论');
assert(d3.getElementById('dReason').textContent.length > 0, '详情页显示“为什么推荐”');
assert(d3.getElementById('dRisk').textContent.length > 0, '详情页显示“风险是什么”');
assert(d3.getElementById('dAdvice').textContent.length > 0, '详情页显示“建议怎么填”');

console.log('\nConsole errors during browser run:', errors.length ? errors : 'none');
console.log(failed === 0 ? 'Browser acceptance: ALL PASSED' : ('Browser acceptance: ' + failed + ' FAILED'));

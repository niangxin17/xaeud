import { JSDOM, VirtualConsole } from 'file:///C:/Users/Administrator/.workbuddy/binaries/node/workspace/node_modules/jsdom/lib/api.js';
import fs from 'fs';
import path from 'path';
const root = process.cwd();
const html = fs.readFileSync(path.resolve(root, 'index.html'), 'utf8');
const vc = new VirtualConsole();
const errs = [];
vc.on('jsdomError', e => errs.push(e.message));
const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  resources: 'usable',
  url: 'file://' + path.resolve(root, 'index.html'),
  virtualConsole: vc,
  pretendToBeVisual: true
});
await new Promise(r => setTimeout(r, 600));
const cards = [...dom.window.document.querySelectorAll('#resultList .scard')];
console.log('卡片数量:', cards.length);
const OK = ['低', '中', '高'];
cards.forEach(c => {
  const name = c.querySelector('h3')?.textContent;
  const riskB = c.querySelector('.scard-risk b')?.textContent;
  console.log(`${name}: 风险="${riskB}"`);
});
const bad = cards.filter(c => {
  const t = c.querySelector('.scard-risk b')?.textContent;
  return !t || !OK.includes(t);
});
console.log(bad.length ? `FAIL: ${bad.length} 张风险异常` : 'PASS: 全部学校风险字段正常');
console.log('console errors:', errs.length ? errs.join('; ') : 'none');

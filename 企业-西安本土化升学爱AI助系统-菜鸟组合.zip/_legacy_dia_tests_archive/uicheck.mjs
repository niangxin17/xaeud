import { JSDOM, VirtualConsole } from 'file:///C:/Users/Administrator/.workbuddy/binaries/node/workspace/node_modules/jsdom/lib/api.js';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const errs = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => errs.push(e.message));
function load(file, query) {
  const html = fs.readFileSync(path.resolve(root, file), 'utf8');
  return new JSDOM(html, { runScripts: 'dangerously', resources: 'usable', url: 'file://' + path.resolve(root, file) + (query || ''), virtualConsole: vc, pretendToBeVisual: true });
}
let failed = 0;
function ok(c, m){ if(!c){console.error('  FAIL',m);failed++;process.exitCode=1;} else console.log('  PASS',m); }

// 结果页
const dom = load('index.html');
await new Promise(r => dom.window.addEventListener('load', r));
const d = dom.window.document;
ok(d.querySelector('.hero .h1')?.textContent.includes('先看清孩子的位置'), 'Hero 价值主张正确');
ok(d.querySelector('.brand-name')?.textContent === '老友中考志愿', '品牌名=老友中考志愿');
ok(d.querySelector('.brand-tag')?.textContent.includes('示例测算'), '小标签标注示例测算');
ok(!!d.getElementById('ctaPrimary') && !!d.getElementById('ctaDrawer'), '主/次 CTA 存在');
ok(d.querySelectorAll('.hero-trust li').length === 3, '首屏三条信任说明');
ok(d.getElementById('condScoreView').textContent.includes('分'), '测算条件卡显示分数');
ok(d.getElementById('condPlanView').textContent.length > 0, '测算条件卡显示志愿策略');
ok(d.getElementById('sumChong').textContent === '4' && d.getElementById('sumWen').textContent === '2' && d.getElementById('sumBao').textContent === '2', '结果摘要三块计数正确');
ok(d.querySelectorAll('#resultList .scard .scard-conclusion').length === 8, '卡片含一句话结论');
ok(d.querySelectorAll('#resultList .scard .scard-metrics dd').length >= 8, '卡片含参考分/位次大数字');
ok(!!d.querySelector('.pro-card #proBtn'), '专业版方案卡存在');
// 卡片顺序固定：名称→标签→结论→指标→风险→理由→详情→加入
const c0 = d.querySelector('#resultList .scard');
const order = [...c0.children].map(e => e.className);
ok(order[0].includes('scard-head') && order[1].includes('scard-conclusion') && order[2].includes('scard-metrics') && order[3].includes('scard-risk') && order[4].includes('scard-reason') && order[5].includes('scard-actions'), '卡片信息顺序固定');

// 详情页
const dom2 = load('detail.html', '?id=s1');
await new Promise(r => dom2.window.addEventListener('load', r));
const d2 = dom2.window.document;
ok(d2.getElementById('dTier').textContent === '冲刺' || d2.getElementById('dTier').textContent.length > 0, '详情页顶部定位标签');
ok(d2.getElementById('dConclusion').textContent.length > 0, '详情页顶部推荐结论');
ok(!!d2.querySelector('.detail-bottom'), '详情页底部吸底操作区');

console.log('\nConsole errors:', errs.length ? errs : 'none');
console.log(failed === 0 ? 'UI check: ALL PASSED' : ('UI check: ' + failed + ' FAILED'));

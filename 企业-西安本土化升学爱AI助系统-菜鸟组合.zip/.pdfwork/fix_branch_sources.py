#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
定点修复：将 BR-003(西安兴庆中学)、BR-005(西安高新一中初中校区) 的来源
从「陕西日报媒体 URL」替换为「西安市教育局官方网站·通知公告」一手来源。

仅修改这 2 条记录的 sourceName/sourceUrl/sourceUpdatedAt/verificationNote，
不改动其他任何字段、不重跑 honors/branchOf 标注逻辑，避免数据漂移。

随后按 label_schools.py 同格式（json.dumps(ensure_ascii=False)，固定 key 顺序）
重写 data/growth-schools.json 与 app/lib/growth-verified-schools.ts，
保证 TS 快照与 JSON 一致（测试从 TS 快照读取）。
"""
import json, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JSON_PATH = os.path.join(ROOT, "data", "growth-schools.json")
TS_PATH = os.path.join(ROOT, "app", "lib", "growth-verified-schools.ts")

# 一手官方来源（已多次核验：西安市教育局 edu.xa.gov.cn 通知公告栏目，
# 标题《西安市民办义务教育学校转为公办学校名单》，发布时间 2022-06-13 19:09，来源西安市教育局）
OFFICIAL_SECTION = "https://edu.xa.gov.cn/xwzx/tzgg/"
SRC_NAME = "西安市教育局（官方网站·通知公告）"
SRC_DATE = "2022-06-13"
NOTE_SUFFIX = (
    "注：该官方文章深链 ID 未被检索工具捕获，sourceUrl 指向西安市教育局"
    "通知公告官方栏目根地址；原始官方页面包屑为 首页/新闻中心/通知公告/正文。"
)

UPDATES = {
    "BR-003": (
        "西安市教育局官方网站《通知公告》栏目《西安市民办义务教育学校转为公办学校名单》"
        "（发布时间：2022-06-13 19:09，来源：西安市教育局）。该名单载明："
        "西安兴庆中学（原西安交通大学附属中学分校）转公并入西安交通大学附属中学。"
        + NOTE_SUFFIX
    ),
    "BR-005": (
        "西安市教育局官方网站《通知公告》栏目《西安市民办义务教育学校转为公办学校名单》"
        "（发布时间：2022-06-13 19:09，来源：西安市教育局）。该名单载明："
        "西安高新一中初中校区转公。"
        + NOTE_SUFFIX
    ),
}

# ---- 1) 读取并定点修改 JSON ----
with open(JSON_PATH, "r", encoding="utf-8") as f:
    schools = json.load(f)
assert isinstance(schools, list), "growth-schools.json 应为数组"

by_id = {s["id"]: s for s in schools}
changed = []
for sid, note in UPDATES.items():
    if sid not in by_id:
        raise SystemExit(f"未找到 {sid}")
    s = by_id[sid]
    s["sourceName"] = SRC_NAME
    s["sourceUrl"] = OFFICIAL_SECTION
    s["sourceUpdatedAt"] = SRC_DATE
    s["verificationNote"] = note
    changed.append(sid)

with open(JSON_PATH, "w", encoding="utf-8") as f:
    json.dump(schools, f, ensure_ascii=False, indent=2)
    f.write("\n")
print("JSON 已更新:", changed)

# ---- 2) 按 label_schools.py 同格式重生成 TS 快照 ----
KEY_ORDER = [
    "id", "name", "stage", "district", "ownership", "address",
    "tuitionText", "commuteText", "mealText", "foreignTeacherText",
    "classSizeText", "managementText", "curriculumTags", "featureTags",
    "enrollmentScope", "registrationMaterials", "sourceName", "sourceUrl",
    "sourceUpdatedAt", "verificationLevel", "verificationLabel",
    "verificationNote", "isDemo", "extra", "honors", "branchOf",
    "admissionScore", "admissionBatch", "admissionTier", "directionalPlan",
    "admissionUnit", "enrollmentPlan", "cutHistory", "keyClassInfo",
]

lines = []
lines.append("// AUTO-GENERATED — 步骤19+ 学校库全量快照（含官方分类标签 honors / 名校分校 branchOf）。")
lines.append("// 数据来源：4 区官方 2026 学区划分 PDF（小学/初中）+ 西安市 2026 普通高中招生计划（高中）")
lines.append("//           + 西安市教育局/陕西省教育厅官方名单（省示范/市一级幼儿园、名校+、示范高中、名校分校）。")
lines.append("// 请勿手改；如需更新请重跑 .pdfwork/label_schools.py 重新生成本文件。")
lines.append("import type { GrowthSchool } from './growth-schools.ts';")
lines.append("")
lines.append("export const VERIFIED_SCHOOLS_PREVIEW: GrowthSchool[] = [")
for s in schools:
    obj = {k: s.get(k) for k in KEY_ORDER}
    lines.append(json.dumps(obj, ensure_ascii=False) + ",")
lines.append("];")
lines.append("")

with open(TS_PATH, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))
print("TS 快照已重生成，总条目:", len(schools))

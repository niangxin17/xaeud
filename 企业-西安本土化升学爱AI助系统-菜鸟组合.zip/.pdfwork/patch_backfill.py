#!/usr/bin/env python3
# 步骤19 收尾：
# 1) 补弥 3 条高中记录缺失的官方来源（上游 data/schools.json 中 planSource 为空的上游缺口）。
#    按区县映射至西安市2026年普通高中招生计划官方 PDF 同一发布的不同分册，日期 2026-07-16。
# 2) 规范化 extra 字段：extra 类型为 Record<string,string>，剥离其中的 null 值以满足 TS 类型约束
#    （这些 null 为上游 code 缺失，前端不读取 extra，剥离无副作用）。
# 3) 重新生成 TS 快照（保留 header 与接口字段顺序）。

import json

ROOT = "."
JSON_PATH = f"{ROOT}/data/growth-schools.json"
TS_PATH = f"{ROOT}/app/lib/growth-verified-schools.ts"

URL_CHANGAN = "https://edu.xa.gov.cn/web_files/edu/file/2026/07/16/202607161006061074641.pdf"  # 长安区/西咸分册
URL_CHENGLIUQU = "https://edu.xa.gov.cn/web_files/edu/file/2026/07/16/202607161006028510798.pdf"  # 城六区分册

# 兼容首次与已重命名两次运行：用当前可能存在的 id 均可定位。
FIX_URL = {
    "S-CAWH": URL_CHANGAN,                                   # 长安区
    "S-XXGD": URL_CHANGAN,                                   # 西咸新区沣东新城
    "S-HIGH_陕西师范大学陆港高级中学": URL_CHENGLIUQU,          # 旧 id（未重命名时）
    "S-陕西师范大学陆港高级中学": URL_CHENGLIUQU,              # 新 id（已重命名时）
}
RENAME_ID = {"S-HIGH_陕西师范大学陆港高级中学": "S-陕西师范大学陆港高级中学"}

d = json.load(open(JSON_PATH, encoding="utf-8"))
by_old = {x["id"]: x for x in d}
for old_id, url in FIX_URL.items():
    x = by_old.get(old_id)
    if not x:
        continue
    x["sourceUrl"] = url
    x["sourceUpdatedAt"] = "2026-07-16"
    x["verificationNote"] = x["verificationNote"].replace("（来源：None）", f"（来源：{url}）")
    if old_id in RENAME_ID:
        x["id"] = RENAME_ID[old_id]

# 剥离 extra 中的 null 值（Record<string,string> 约束）
for x in d:
    if isinstance(x.get("extra"), dict):
        x["extra"] = {k: v for k, v in x["extra"].items() if v is not None}

ids = [x["id"] for x in d]
assert len(ids) == len(set(ids)), f"重复 ID: {[i for i in ids if ids.count(i) > 1]}"
assert all(x["sourceUrl"] and x["sourceUpdatedAt"] for x in d
           if x["id"] in ("S-CAWH", "S-XXGD", "S-陕西师范大学陆港高级中学")), "来源回填失败"

json.dump(d, open(JSON_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("JSON 规范化完成，entries =", len(d))

lines = open(TS_PATH, encoding="utf-8").read().splitlines(keepends=True)
exp_idx = next(i for i, l in enumerate(lines) if l.startswith("export const VERIFIED_SCHOOLS_PREVIEW"))
header = "".join(lines[: exp_idx + 1])
body = []
n = len(d)
for i, x in enumerate(d):
    comma = "," if i < n - 1 else ""
    body.append(json.dumps(x, ensure_ascii=False) + comma + "\n")
open(TS_PATH, "w", encoding="utf-8").write(header + "".join(body) + "];\n")
print("TS 快照重新生成完成，entries =", n)

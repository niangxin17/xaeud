import pdfplumber, json, os, re
from collections import Counter, defaultdict
from pypdf import PdfReader

PDF_DIR = os.path.dirname(os.path.abspath(__file__))
DIST = {"yt": "雁塔区", "bl": "碑林区", "qj": "曲江新区", "gx": "西安高新区"}
DIST_CODE = {"yt": "YT", "bl": "BL", "qj": "QJ", "gx": "GX"}
SOURCE_UPDATED = "2026-06-05"

META_TABLE = {
    "yt-primary": {"district": "yt", "stage": "primary",
        "sourceName": "雁塔区2026年义务教育阶段小学学区划分一览表",
        "sourceUrl": "https://www.yanta.gov.cn/web_files/yanta/file/2026/06/05/202606051231316791024.pdf"},
    "yt-junior": {"district": "yt", "stage": "junior",
        "sourceName": "雁塔区2026年义务教育阶段初中学区划分一览表",
        "sourceUrl": "https://www.yanta.gov.cn/web_files/yanta/file/2026/06/05/202606051231394794701.pdf"},
    "bl-primary": {"district": "bl", "stage": "primary",
        "sourceName": "碑林区2026年义务教育阶段小学学区划分一览表",
        "sourceUrl": "https://www.beilin.gov.cn/web_files/beilin/file/2026/06/05/202606051159529721596.pdf"},
    "bl-junior": {"district": "bl", "stage": "junior",
        "sourceName": "碑林区2026年义务教育阶段初中学区划分一览表",
        "sourceUrl": "https://www.beilin.gov.cn/web_files/beilin/file/2026/06/05/202606051200057485439.pdf"},
    "qj": {"district": "qj", "stage": None,
        "sourceName": "曲江新区2026年义务教育学校学区划分一览表",
        "sourceUrl": "https://qjxq.xa.gov.cn/web_files/qjxq/file/2026/06/05/202606051409018137444.pdf"},
}
XUEDUAN = ["小学", "初中", "完全中学", "九年一贯制"]
SCHOOL_SUFFIX = ("小学", "中学", "学校", "分校", "校区", "学院", "附中", "附小")
PHONE_RE = re.compile(r'^[\d\s\-转]+$')


def norm(s):
    return (s or "").replace("\n", "").replace("\r", "").strip()


def is_phone_line(s):
    s = s.strip()
    return bool(s) and bool(re.search(r'\d{3,}', s)) and bool(PHONE_RE.match(s))


def stage_from_name(name):
    return "primary" if "小学" in name else "junior"


# ---------- 单学段/曲江：pdfplumber 表格 ----------
def extract_tables():
    out = []
    for key, meta in META_TABLE.items():
        dk = meta["district"]
        with pdfplumber.open(os.path.join(PDF_DIR, f"{key}.pdf")) as pdf:
            for page in pdf.pages:
                tables = page.extract_tables()
                if not tables:
                    continue
                t = tables[0]
                if not t:
                    continue
                header = [norm(c) for c in t[0]]
                is_header = any("序号" in h for h in header) or any("学校" in h for h in header)
                rows = t[1:] if is_header else t
                for row in rows:
                    cells = [norm(c) for c in row]
                    if len(cells) < 3:
                        continue
                    seq = cells[0]
                    name = cells[1]
                    scope = cells[2] if len(cells) > 2 else ""
                    note = cells[3] if len(cells) > 3 else ""
                    if not name:
                        continue
                    if name in ("学校名称", "学 校", "学校"):
                        continue
                    if name.startswith("注：") or name.startswith("注:"):
                        continue
                    if not scope:
                        continue
                    stage = meta["stage"] if meta["stage"] else stage_from_name(name)
                    out.append({
                        "district_key": dk, "stage": stage, "seq": seq,
                        "name": name, "scope": scope, "note": note, "phone": "",
                        "sourceName": meta["sourceName"], "sourceUrl": meta["sourceUrl"],
                    })
    return out


# ---------- 高新：pypdf 行文本 ----------
def parse_gx():
    out = []
    src_name = "西安高新区2026年义务教育阶段学区划分方案"
    src_url = "https://www.xa.gov.cn/web_files/xian/file/2026/06/05/202606051443391166718.pdf"
    r = PdfReader(os.path.join(PDF_DIR, "gx.pdf"))
    lines = [l.strip() for l in "\n".join((p.extract_text() or "") for p in r.pages).split("\n")]
    valid = []
    for idx, l in enumerate(lines):
        if re.match(r'^\d{1,3}\s+', l) and "学区划分" not in l and "所在街道" not in l:
            window = " ".join(lines[idx:idx + 2])
            if any(x in window for x in XUEDUAN) or any(w in window for w in ["小学", "中学", "学校"]):
                valid.append(idx)
    for vi, idx in enumerate(valid):
        end = valid[vi + 1] if vi + 1 < len(valid) else len(lines)
        sl = lines[idx:end]
        m = re.match(r'^(\d{1,3})\s+(.*)$', sl[0])
        seq = m.group(1)
        line0 = m.group(2).strip()
        combined = (line0 + " " + sl[1]).strip() if len(sl) > 1 else line0
        xd = None
        if "九年" in combined and "一贯制" in combined:
            xd = "九年一贯制"
            name = combined.replace(" ", "").split("九年一贯制")[0].strip()
        else:
            for x in XUEDUAN:
                if x in combined:
                    xd = x
                    name = combined.rsplit(x, 1)[0].strip()
                    break
        if xd is None:
            continue
        if xd != "九年一贯制" and not name.endswith(SCHOOL_SUFFIX) and len(sl) > 1:
            nxt = sl[1]
            if not is_phone_line(nxt) and not any(x in nxt for x in XUEDUAN) and "：" not in nxt:
                name = (name + nxt).rsplit(xd, 1)[0].strip() if xd in (name + nxt) else (name + nxt).strip()
        name = name.strip()
        # 学区划分
        xd_line = None
        for li, l in enumerate(sl):
            if xd == "九年一贯制":
                if "一贯制" in l:
                    xd_line = li
                    break
            elif xd in l:
                xd_line = li
                break
        start_li = xd_line if xd_line is not None else 0
        scope_parts = []
        for li in range(start_li, len(sl)):
            l = sl[li]
            if li == start_li:
                after = re.sub(r'^.*' + re.escape(xd), '', l, count=1).strip()
                ap = after.split()
                if ap and is_phone_line(ap[-1]):
                    after = " ".join(ap[:-1]).strip()
                if after:
                    scope_parts.append(after)
                continue
            if re.match(r'^[—\-·\s\d]+$', l) and len(l.strip()) <= 8:
                continue
            if is_phone_line(l):
                continue
            if l in ("小学：", "初中："):
                continue
            lp = l.split()
            if lp and is_phone_line(lp[-1]):
                l = " ".join(lp[:-1]).strip()
            if l:
                scope_parts.append(l)
        scope = " ".join(scope_parts).strip()
        scope = re.sub(r'(?<=[\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])', '', scope)
        scope = re.sub(r'^(九年一贯制|一贯制|九年|小学|初中)\s*', '', scope).strip()
        name = re.sub(r'(?<=[\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])', '', name)
        if xd == "九年一贯制":
            if "初中：" in scope:
                p_part = scope.split("初中：")[0].strip()
                j_part = "初中：" + scope.split("初中：", 1)[1].strip()
            else:
                p_part = j_part = scope
            out.append(dict(district_key="gx", stage="primary", seq=seq, name=name, scope=p_part, note="", phone="", sourceName=src_name, sourceUrl=src_url))
            out.append(dict(district_key="gx", stage="junior", seq=seq, name=name, scope=j_part, note="", phone="", sourceName=src_name, sourceUrl=src_url))
        else:
            stage = "primary" if "小学" in xd else "junior"
            out.append(dict(district_key="gx", stage=stage, seq=seq, name=name, scope=scope, note="", phone="", sourceName=src_name, sourceUrl=src_url))
    return out


COUNTER = defaultdict(int)


def build():
    raw = extract_tables() + parse_gx()
    entries = []
    for r in raw:
        dk = r["district_key"]
        stage = r["stage"]
        COUNTER[(dk, stage)] += 1
        n = COUNTER[(dk, stage)]
        prefix = "P" if stage == "primary" else "J"
        sid = f"{prefix}-{DIST_CODE[dk]}-{n:03d}"
        extra = {}
        if r["seq"]:
            extra["原始序号"] = r["seq"]
        if r["note"]:
            extra["备注"] = r["note"]
        if r["phone"]:
            extra["电话"] = r["phone"]
        entries.append({
            "id": sid, "name": r["name"], "stage": stage, "district": DIST[dk],
            "ownership": "public", "address": "", "tuitionText": "", "commuteText": "",
            "mealText": "", "foreignTeacherText": "", "classSizeText": "", "managementText": "",
            "curriculumTags": [], "featureTags": [], "enrollmentScope": r["scope"],
            "registrationMaterials": "", "sourceName": r["sourceName"], "sourceUrl": r["sourceUrl"],
            "sourceUpdatedAt": SOURCE_UPDATED, "verificationLevel": "A", "verificationLabel": "官方公开",
            "verificationNote": f"官方公示《{r['sourceName']}》第{r['seq'] or '—'}号「{r['name']}」学区范围单元格原文摘抄。",
            "isDemo": False, "extra": extra,
        })
    return entries


if __name__ == "__main__":
    ents = build()
    seen = set(); uniq = []
    for e in ents:
        if e["id"] in seen:
            continue
        seen.add(e["id"]); uniq.append(e)
    json.dump(uniq, open(os.path.join(PDF_DIR, "primary_junior_raw.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    c = Counter((e["district"], e["stage"]) for e in uniq)
    print("total:", len(uniq))
    for k, v in sorted(c.items()):
        print(" ", k, v)
    print("empty scope:", sum(1 for e in uniq if not e["enrollmentScope"]))
    print("phone leak:", sum(1 for e in uniq if re.search(r'\d{3,}[\d\-]*$', e["enrollmentScope"].strip())))

import re, json, os
from pypdf import PdfReader
from collections import Counter

PDF_DIR = os.path.dirname(os.path.abspath(__file__))
XUEDUAN = ["小学", "初中", "完全中学", "九年一贯制"]
SOURCE_NAME = "西安高新区2026年义务教育阶段学区划分方案"
SOURCE_URL = "https://www.xa.gov.cn/web_files/xian/file/2026/06/05/202606051443391166718.pdf"
SOURCE_UPDATED = "2026-06-05"
PHONE_RE = re.compile(r'^[\d\s\-转]+$')
SCHOOL_SUFFIX = ("小学", "中学", "学校", "分校", "校区", "学院", "附中", "附小")


def is_phone_line(s):
    s = s.strip()
    return bool(s) and bool(re.search(r'\d{3,}', s)) and bool(PHONE_RE.match(s))


def parse_gx():
    r = PdfReader(os.path.join(PDF_DIR, "gx.pdf"))
    text = "\n".join((p.extract_text() or "") for p in r.pages)
    lines = [l.strip() for l in text.split("\n")]
    valid = []
    for idx, l in enumerate(lines):
        if re.match(r'^\d{1,3}\s+', l) and "学区划分" not in l and "所在街道" not in l:
            window = " ".join(lines[idx:idx + 2])
            if any(x in window for x in XUEDUAN) or any(w in window for w in ["小学", "中学", "学校"]):
                valid.append(idx)
    records = []
    for vi, idx in enumerate(valid):
        end = valid[vi + 1] if vi + 1 < len(valid) else len(lines)
        sl = lines[idx:end]
        m = re.match(r'^(\d{1,3})\s+(.*)$', sl[0])
        seq = m.group(1)
        line0 = m.group(2).strip()
        # 拼接 line0+line1 用于判定学段与校名（处理换行/九年一贯制跨行）
        combined = (line0 + " " + sl[1]).strip() if len(sl) > 1 else line0
        xd = None
        if "九年" in combined and "一贯制" in combined:
            xd = "九年一贯制"
            name = combined.replace(" ", "").split("九年一贯制")[0].strip()
        else:
            for x in XUEDUAN:
                if x in combined:
                    xd = x
                    name = combined.rsplit(x, 1)[0].strip()
                    break
        if xd is None:
            continue
        # 若校名未以学校后缀结尾且 line1 存在，可能校名换行至 line1
        if xd != "九年一贯制" and not name.endswith(SCHOOL_SUFFIX) and len(sl) > 1:
            nxt = sl[1]
            if not is_phone_line(nxt) and not any(x in nxt for x in XUEDUAN) and "：" not in nxt:
                name = (name + nxt).rsplit(xd, 1)[0].strip() if xd in (name + nxt) else (name + nxt).strip()
        name = name.strip()
        # 学区划分：从学段之后的内容起，去掉电话行与孤立 小学：/初中： 标签
        scope_parts = []
        # 定位学段在 slice 中的行
        xd_line = None
        for li, l in enumerate(sl):
            if xd == "九年一贯制":
                if "一贯制" in l:
                    xd_line = li
                    break
            elif xd in l:
                xd_line = li
                break
        start_li = xd_line if xd_line is not None else 0
        for li in range(start_li, len(sl)):
            l = sl[li]
            if li == start_li:
                after = re.sub(r'^.*' + re.escape(xd), '', l, count=1)
                after = after.strip()
                ap = after.split()
                if ap and is_phone_line(ap[-1]):
                    after = " ".join(ap[:-1]).strip()
                if after:
                    scope_parts.append(after)
                continue
            # 跳过页码标记（如 — 2 — 或孤立数字）
            if re.match(r'^[—\-·\s\d]+$', l) and len(l.strip()) <= 8:
                continue
            if is_phone_line(l):
                continue
            if l in ("小学：", "初中："):
                continue
            # 剥离行尾残留电话（断词导致电话落在续行）
            lp = l.split()
            if lp and is_phone_line(lp[-1]):
                l = " ".join(lp[:-1]).strip()
            if l:
                scope_parts.append(l)
        scope = " ".join(scope_parts).strip()
        # 清理：①去掉两个汉字之间的换行空格（PDF 断词）②去掉开头残留的学段/标签词
        scope = re.sub(r'(?<=[\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])', '', scope)
        scope = re.sub(r'^(九年一贯制|一贯制|九年|小学|初中)\s*', '', scope).strip()
        name = re.sub(r'(?<=[\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])', '', name)
        if xd == "九年一贯制":
            if "初中：" in scope:
                p_part = scope.split("初中：")[0].strip()
                j_part = "初中：" + scope.split("初中：", 1)[1].strip()
            else:
                p_part = j_part = scope
            records.append((seq, name, "primary", p_part))
            records.append((seq, name, "junior", j_part))
        else:
            stage = "primary" if "小学" in xd else "junior"
            records.append((seq, name, stage, scope))
    return records


if __name__ == "__main__":
    recs = parse_gx()
    print("gx records:", len(recs), dict(Counter(r[2] for r in recs)))
    for seq, name, stage, scope in recs[:10]:
        print(f"  [{seq}] {stage} {name} | {scope[:40]}")
    # 九年一贯制样例
    for seq, name, stage, scope in recs:
        if "第二学校" in name:
            print("  9Y:", stage, name, "|", scope[:70]); break
    # 校验：是否还有残留电话 / 学段前缀 / 换行空格
    import re as _re
    phone_leak = [r for r in recs if _re.search(r'\d{3,}[\d\-]*$', r[3].strip())]
    wrap_space = [r for r in recs if _re.search(r'[\u4e00-\u9fff]\s+[\u4e00-\u9fff]', r[3])]
    lead_bad = [r for r in recs if _re.match(r'^(小学|初中|一贯制|九年)', r[3])]
    print("phone leak:", len(phone_leak), "wrap-space:", len(wrap_space), "lead-bad:", len(lead_bad))
    for r in phone_leak[:5]:
        print("   PHONE:", r[1], "|", r[3][-30:])
    for r in wrap_space[:5]:
        print("   WRAP:", r[1], "|", repr(r[3][:40]))

import json, os, re

ROOT = "C:/Users/Administrator/Documents/中考网站架构/finalapp"
PDFWORK = os.path.join(ROOT, ".pdfwork")
SENIOR_SRC = os.path.join(ROOT, "data", "schools.json")
PJ_RAW = os.path.join(PDFWORK, "primary_junior_raw.json")
OUT_JSON = os.path.join(ROOT, "data", "growth-schools.json")
OUT_TS = os.path.join(ROOT, "app", "lib", "growth-verified-schools.ts")

DISTRICT_MAP = {
    "chengliuqu": "城六区", "changan": "长安区", "xixian": "西咸新区",
    "huyi": "鄠邑区", "lantian": "蓝田县", "zhouzhi": "周至县",
    "lintong": "临潼区", "gaoling": "高陵区", "yanliang": "阎良区",
}

DATE_RE = re.compile(r'(\d{4})(\d{2})(\d{2})')


def parse_date(url):
    if not url:
        return ""
    m = DATE_RE.search(os.path.basename(url))
    if m:
        return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
    return ""


def load_pj():
    return json.load(open(PJ_RAW, encoding="utf-8"))


def map_senior():
    data = json.load(open(SENIOR_SRC, encoding="utf-8"))
    out = []
    for e in data:
        if e.get("schoolType") != "high":
            continue
        region = (e.get("region") or "").strip()
        district = region if region else DISTRICT_MAP.get(e.get("district"), "城六区")
        # 统一命名，避免与义务教育「西安高新区」在筛选下拉中分裂
        if district == "高新区":
            district = "西安高新区"
        cut = e.get("cut") or {}
        score = cut.get("2026") or e.get("referenceScore") or e.get("est2026") or None
        sid = "S-" + str(e.get("id")).upper()
        tier = e.get("tier") or None
        extra = {
            "planStatus": e.get("planStatus"),
            "code": e.get("code"),
            "schoolType": "high",
        }
        out.append({
            "id": sid,
            "name": e.get("name"),
            "stage": "senior",
            "district": district,
            "ownership": e.get("ownership") or "public",
            "address": "",
            "tuitionText": "", "commuteText": "", "mealText": "",
            "foreignTeacherText": "", "classSizeText": "", "managementText": "",
            "curriculumTags": [], "featureTags": [],
            "enrollmentScope": "",
            "registrationMaterials": "",
            "admissionScore": score,
            "admissionBatch": e.get("batch"),
            "admissionTier": tier,
            "directionalPlan": e.get("dingxiang"),
            "admissionUnit": e.get("admissionUnit"),
            "enrollmentPlan": e.get("enroll"),
            "cutHistory": cut if cut else None,
            "keyClassInfo": e.get("keyClass") or None,
            "sourceName": "西安市2026年普通高中招生计划",
            "sourceUrl": e.get("planSource") or "",
            "sourceUpdatedAt": parse_date(e.get("planSource") or ""),
            "verificationLevel": "A",
            "verificationLabel": "官方公开",
            "verificationNote": f"西安市2026年普通高中招生计划官方公示（来源：{e.get('planSource')}）「{e.get('name')}」录取信息原文摘抄。",
            "isDemo": False,
            "extra": extra,
        })
    return out


def main():
    pj = load_pj()
    sr = map_senior()
    all_entries = pj + sr
    # 校验 ID 唯一
    ids = [e["id"] for e in all_entries]
    dup = len(ids) - len(set(ids))
    print("pj:", len(pj), "senior:", len(sr), "total:", len(all_entries), "dup_ids:", dup)
    json.dump(all_entries, open(OUT_JSON, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    # 生成 TS 快照
    header = (
        "// AUTO-GENERATED — 步骤19 学校库全量快照。\n"
        "// 数据来源：4 区官方 2026 学区划分 PDF（小学/初中，A 级官方公开）+\n"
        "//           西安市 2026 年普通高中招生计划（高中，A 级官方公开，derived from data/schools.json）。\n"
        "// 请勿手改；如需更新请重跑提取/映射脚本并重新生成本文件。\n"
        "import type { GrowthSchool } from './growth-schools.ts';\n\n"
        "export const VERIFIED_SCHOOLS_PREVIEW: GrowthSchool[] = [\n"
    )
    body = ",\n".join(json.dumps(e, ensure_ascii=False) for e in all_entries)
    footer = "\n];\n"
    with open(OUT_TS, "w", encoding="utf-8") as f:
        f.write(header)
        f.write(body)
        f.write(footer)
    print("wrote", OUT_JSON, "and", OUT_TS)
    # 统计
    from collections import Counter
    c = Counter((e["district"], e["stage"]) for e in all_entries)
    for k, v in sorted(c.items()):
        print("  ", k, v)


if __name__ == "__main__":
    main()

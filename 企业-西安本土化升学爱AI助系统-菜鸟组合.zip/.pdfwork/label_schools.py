#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
步骤19+ ：为学校库追加「官方分类标签」并补录重点校/分校。
仅使用官方来源（西安市教育局 edu.xa.gov.cn、陕西省教育厅 jyt.shaanxi.gov.cn、
西安市人民政府 xa.gov.cn），不采用任何商业排名，不出现「排名」字样。

- 对库内已有学校按官方名单打 honors（省示范高中 / 省标准化高中 / 名校+牵头校）。
- 新增：省示范幼儿园（重点幼儿园）、名校分校（branchOf）、库外知名小学（名校+牵头校）。
- 每条新增记录均为 A 级官方来源、isPublishable 通过。
- 写回 data/growth-schools.json，并重生成 app/lib/growth-verified-schools.ts。
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JSON_PATH = os.path.join(ROOT, "data", "growth-schools.json")
TS_PATH = os.path.join(ROOT, "app", "lib", "growth-verified-schools.ts")

# ---------------------------------------------------------------------------
# 官方来源 URL（均来自政府门户）
# ---------------------------------------------------------------------------
SRC_KINDERGARTEN_DEMO = "https://jyt.shaanxi.gov.cn/gk/zc/gfxwj_20255/gfxwj_20254/202402/t20240222_3416446.html"  # 陕西省示范幼儿园（2023批次，西安27所），2024-02-22
SRC_MINGXIAO_PLUS = "https://www.xa.gov.cn/web_files/xian/file/2023/01/17/202301171606220165374.pdf"  # 2022年市级名校+共同体名单（51个），2023-01-17
SRC_SENIOR_DEMO = "https://www.shaanxi.gov.cn/hd/sxzswd/sjzswd/202502/t20250213_3436107.html"  # 陕西省普通高中示范学校名单，2025-02-13
SRC_SENIOR_STD = "https://jyt.shaanxi.gov.cn/gk/fdnr/gsgggk/202108/t20210825_3407664.html"  # 陕西省普通高中标准化学校名单，2021-08-25

# ---------------------------------------------------------------------------
# 省示范高中（agent 官方名单，44 所；用于给库内高中打「省示范高中」）
# ---------------------------------------------------------------------------
SENIOR_DEMO = set([
    "西北工业大学附属中学", "西安市铁一中学", "西安交通大学附属中学", "西北大学附属中学",
    "西安市第三中学", "西安市第二十六中学", "西安市第六中学",
    "西安市第八十三中学", "西安市西光中学", "西安市第八十九中学",
    "西安市第一中学", "西安市第七十中学", "西安市远东第一中学", "西安市庆安高级中学", "西安市远东第二中学",
    "西安市第八十五中学", "西安市育才中学", "陕西师范大学附属中学", "西安高新第一中学", "西安市曲江第一中学",
    "西安市航天中学", "西安建筑科技大学附属中学", "西安电子科技大学附属中学", "西安高新第三中学",
    "西安高级中学", "西安市第七十五中学", "西安市第六十六中学", "西安市西航一中", "西安市经开第一中学",
    "西安铁一中滨河高级中学", "西安市东城第一中学",
    "西安市车辆中学", "西安高新一中沣东中学", "陕西省西咸新区秦汉中学",
    "西安市阎良区西飞第一中学",
    "西安市临潼区华清中学", "西安市临潼区临潼中学",
    "西安市长安区第一中学", "西安市长安区第二中学",
    "西安市高陵区第一中学",
    "西安市鄠邑区第一中学", "西安惠安中学",
    "周至中学",
    "西安市田家炳中学",
])

# 省标准化高中（agent 官方名单中点名的 6 所新增，用于打「省标准化高中」）
SENIOR_STD = set([
    "西安市航天城第一中学", "陕西师范大学附属中学分校", "西安交通大学附属中学航天学校",
    "西安市经开第三中学", "西安市高新第二高级中学", "西安市曲江第二中学",
])

# 名校+ 牵头校（中学组，精确名；库内命中即打「名校+牵头校」）
MINGXIAO_PLUS_SEC_EXACT = [
    "西安市第八十九中学", "西安市铁一中学", "西安市长安区第一中学", "西安高新第一中学",
    "西安经开第一学校", "浐灞第二中学", "陕西师范大学附属中学", "高新一中沣东中学",
    "西安交通大学附属中学",
]
# 名校+ 牵头校（小学组，按子串匹配库内校名）
MINGXIAO_PLUS_PRI_SUBSTR = [
    "后宰门小学", "西光实验小学", "大学南路小学", "大雁塔小学", "翠华路小学",
    "纺织城小学", "曲江第二小学", "高新区第二小学",
]

# ---------------------------------------------------------------------------
# 新增：省示范幼儿园（重点幼儿园）。(名称, 区县)
# 来源：陕西省教育厅命名通知（SRC_KINDERGARTEN_DEMO 及历年批次）。
# ---------------------------------------------------------------------------
KINDERGARTENS = [
    ("新城区电力幼儿园", "新城区"),
    ("西安理工大学幼儿园", "碑林区"),
    ("莲湖区第八幼儿园", "莲湖区"),
    ("未央区长乐西苑幼儿园", "未央区"),
    ("雁塔橡树逸园幼儿园", "雁塔区"),
    ("西安市雁塔区嘉祥第三幼儿园", "雁塔区"),
    ("阎良区武屯幼儿园", "阎良区"),
    ("阎良区关山中心幼儿园", "阎良区"),
    ("临潼区相桥中心幼儿园", "临潼区"),
    ("长安区郭杜街道中心幼儿园", "长安区"),
    ("高陵区四季阳光幼儿园", "高陵区"),
    ("高陵区鹿苑第二幼儿园", "高陵区"),
    ("蓝田县普化镇中心幼儿园", "蓝田县"),
    ("蓝田县安村镇中心幼儿园", "蓝田县"),
    ("西咸新区沣东新城第一幼儿园", "西咸新区沣东新城"),
    ("西安沣东第三幼儿园", "西咸新区沣东新城"),
    ("西咸新区沣西新城第五幼儿园", "西咸新区沣西新城"),
    ("西咸新区沣东新城后卫馨佳苑幼儿园", "西咸新区沣东新城"),
    ("西咸新区沣西沣润幼儿园", "西咸新区沣西新城"),
    ("西安国际陆港第二幼儿园", "国际港务区"),
    ("西安高新第六幼儿园", "高新区"),
    ("西安经开第二幼儿园", "经开区"),
    ("西安航天城第二幼儿园", "航天基地"),
    ("西安航空基地第一幼儿园", "航空基地"),
    ("莲湖民族幼儿园", "莲湖区"),
    ("灞桥区幼儿园", "灞桥区"),
    ("灞桥区东城第一幼儿园一印分园", "灞桥区"),
    ("未央区中心幼儿园", "未央区"),
    ("临潼区铁炉中心幼儿园", "临潼区"),
    ("长安区郭杜街道茅坡新城幼儿园", "长安区"),
    ("长安区第一幼儿园", "长安区"),
    ("鄠邑区涝店中心幼儿园", "鄠邑区"),
    ("户县大王镇中心幼儿园", "鄠邑区"),
    ("周至县楼观镇中心幼儿园", "周至县"),
    ("周至县职工幼儿园", "周至县"),
    ("西咸新区沣东新城第四幼儿园", "西咸新区沣东新城"),
    ("西安高新第五幼儿园", "高新区"),
    ("西安经开第六幼儿园", "经开区"),
    ("莲湖区第六幼儿园", "莲湖区"),
    ("阎良区北屯幼儿园", "阎良区"),
    ("阎良区第二幼儿园", "阎良区"),
    ("长安家园幼儿园", "长安区"),
    ("高陵区湾子中心幼儿园", "高陵区"),
    ("周至县新区幼儿园", "周至县"),
    ("西安国际陆港第一幼儿园", "国际港务区"),
    ("高新区吉的堡望庭幼儿园", "高新区"),
    ("西安经开第一幼儿园", "经开区"),
    ("浐灞第一幼儿园", "浐灞生态区"),
    ("浐灞第二幼儿园", "浐灞生态区"),
    ("西安航天城第一幼儿园", "航天基地"),
    ("新城区华山幼儿园", "新城区"),
    ("新城区黄河幼儿园", "新城区"),
    ("莲湖区远东保育院", "莲湖区"),
    ("空军西安蓝天幼儿园", "莲湖区"),
    ("民航幼儿园", "莲湖区"),
    ("莲湖区远东实验幼儿园", "莲湖区"),
    ("阎良区西飞保育院", "阎良区"),
    ("高陵区长庆泾渭苑多彩幼儿园", "高陵区"),
    ("西安高新第一幼儿园", "高新区"),
    ("中国人民解放军国防大学幼儿园（西安园）", "西安市"),
    ("未央区开元幼儿园", "未央区"),
    ("临潼区幼儿园", "临潼区"),
]

# ---------------------------------------------------------------------------
# 新增：名校分校（branchOf=母校）。(名称, 母校, 学段, 区县, 性质)
# 来源：各区县政府门户 / 西安市教育局民转公名单（agent 官方核查）。
# ---------------------------------------------------------------------------
BRANCHES = [
    ("西安翱翔中学", "西北工业大学附属中学", "junior", "碑林区", "private",
     "https://www.beilin.gov.cn/zwgk/fdzdgk/ggqsydw/xx/zx/1722423336633896961.html", "2026-08-14",
     "碑林区政府公开的西工大附中分校（翱翔中学）更名/招生信息。", ""),
    ("西安辅轮中学", "西安市铁一中学", "junior", "碑林区", "private",
     "https://beilin.xiancity.cn/system/2024/06/26/031144657.shtml", "2024-06-26",
     "碑林区2024招生方案载铁一中分校（辅轮中学）信息。", ""),
    ("西安兴庆中学", "西安交通大学附属中学", "junior", "碑林区", "public",
     "https://www.sxdaily.com.cn/2022-06/13/content_9652051.html", "2022-06-13",
     "西安市教育局民转公名单（38所）载交大附中分校（兴庆中学）转公并入交大附中。", ""),
    ("西安崇是中学", "陕西师范大学附属中学", "senior", "雁塔区", "private",
     "https://xxgkw.sdfz.com.cn/about/54/9158", "2026-08-14",
     "陕西师范大学附属中学官网简介载崇是中学（原陕师大附中分校）为完全中学。", "省标准化高中"),
    ("陕西师范大学陆港中学", "陕西师范大学附属中学", "senior", "浐灞国际港", "public",
     "https://xxgkw.sdfz.com.cn/about/54/9158", "2026-08-14",
     "陕西师范大学附属中学官网合作办学栏目载陆港中学由附中管理。", ""),
    ("西安高新一中沣东中学", "西安高新第一中学", "senior", "西咸新区沣东新城", "private",
     "https://www.xixianxinqu.gov.cn/xwzx/xcdt/1828004010811527170.html", "2026-08-14",
     "西咸新区官网介绍高新一中沣东中学为高新一中分校。", "省示范高中"),
    ("西安高新一中初中校区", "西安高新第一中学", "junior", "高新区", "public",
     "https://www.sxdaily.com.cn/2022-06/13/content_9652051.html", "2022-06-13",
     "西安市教育局民转公名单载高新一中初中校区转公。", ""),
    ("西安滨河学校", "西安市铁一中学", "senior", "灞桥区", "private",
     "https://www.xa.gov.cn/gk/jyly/mbxx/1943116917073522690.html", "2025-07-09",
     "西安市人民政府门户载铁一中滨河学校（滨河学校）民办招生计划。", "省示范高中"),
    ("西安市经开第一中学", "陕西省西安中学", "senior", "经开区", "public",
     "https://xetdz.xa.gov.cn/xwzx/jkdt/1813380811289276418.html", "2026-08-14",
     "经开区官网载经开一中由西安中学托管。", "省示范高中"),
]

# ---------------------------------------------------------------------------
# 新增：库外知名小学（名校+ 牵头校，不在4区库内）。
# (名称, 区县, 性质)
# ---------------------------------------------------------------------------
FAMOUS_PRIMARIES = [
    ("西安市新城区后宰门小学", "新城区", "public"),
    ("西安市新城区西光实验小学", "新城区", "public"),
    ("西安市灞桥区纺织城小学", "灞桥区", "public"),
]


def make_base(stage, district, ownership, name, source_name, source_url,
              source_updated, note, honors, branch_of=None):
    return {
        "id": None,  # 占位，后面分配
        "name": name,
        "stage": stage,
        "district": district,
        "ownership": ownership,
        "address": "",
        "tuitionText": "",
        "commuteText": "",
        "mealText": "",
        "foreignTeacherText": "",
        "classSizeText": "",
        "managementText": "",
        "curriculumTags": [],
        "featureTags": [],
        "enrollmentScope": "",
        "registrationMaterials": "",
        "sourceName": source_name,
        "sourceUrl": source_url,
        "sourceUpdatedAt": source_updated,
        "verificationLevel": "A",
        "verificationLabel": "官方公开",
        "verificationNote": note,
        "isDemo": False,
        "extra": {},
        "honors": list(honors),
        "branchOf": branch_of,
    }


def main():
    with open(JSON_PATH, encoding="utf-8") as f:
        schools = json.load(f)

    by_name = {}
    for s in schools:
        by_name.setdefault(s["name"], []).append(s)

    # ---- 1) 给库内已有学校打标签 ----
    for s in schools:
        honors = set(s.get("honors") or [])
        stage = s["stage"]
        name = s["name"]
        if stage == "senior":
            if name in SENIOR_DEMO:
                honors.add("省示范高中")
            if name in SENIOR_STD:
                honors.add("省标准化高中")
            if name in MINGXIAO_PLUS_SEC_EXACT:
                honors.add("名校+牵头校")
        if stage in ("primary", "junior"):
            if stage == "junior" and name in MINGXIAO_PLUS_SEC_EXACT:
                honors.add("名校+牵头校")
            if stage == "primary":
                for sub in MINGXIAO_PLUS_PRI_SUBSTR:
                    if sub in name:
                        honors.add("名校+牵头校")
                        break
        if honors:
            s["honors"] = sorted(honors)
        else:
            s["honors"] = s.get("honors") or []
        # 保证 branchOf 字段存在（库内原有记录缺省为 null）
        if "branchOf" not in s:
            s["branchOf"] = None

    # ---- 2) 新增：省示范幼儿园 ----
    for name, district in KINDERGARTENS:
        if any(x["name"] == name for x in schools):
            continue  # 去重，避免重复
        e = make_base(
            "kindergarten", district, "unknown", name,
            "陕西省教育厅关于命名陕西省示范幼儿园的通知", SRC_KINDERGARTEN_DEMO,
            "2024-02-22",
            "官方公示《陕西省示范幼儿园》名单（西安市）原文摘抄，属省示范幼儿园（重点幼儿园）。",
            ["省示范幼儿园"],
        )
        schools.append(e)

    # ---- 3) 新增：名校分校 ----
    for name, parent, stage, district, owner, url, updated, note, tier in BRANCHES:
        if any(x["name"] == name for x in schools):
            continue
        e = make_base(
            stage, district, owner, name,
            "西安市教育局/区县政府门户 名校分校官方信息", url, updated,
            note, ["名校分校"], branch_of=parent,
        )
        if tier:
            e["admissionTier"] = tier
        schools.append(e)

    # ---- 4) 新增：库外知名小学（名校+ 牵头校）----
    for name, district, owner in FAMOUS_PRIMARIES:
        if any(x["name"] == name for x in schools):
            continue
        e = make_base(
            "primary", district, owner, name,
            "西安市教育局2022年市级名校+共同体名单", SRC_MINGXIAO_PLUS,
            "2023-01-17",
            "官方公示《2022年市级名校+共同体名单》原文摘抄，属名校+牵头校。",
            ["名校+牵头校"],
        )
        schools.append(e)

    # ---- 4.5) 对「库内已存在」的母校分校补打 branchOf + 名校分校 ----
    branch_map = {b[0]: b[1] for b in BRANCHES}
    for s in schools:
        if s["name"] in branch_map and not s.get("branchOf"):
            s["branchOf"] = branch_map[s["name"]]
            hs = set(s.get("honors") or [])
            hs.add("名校分校")
            s["honors"] = sorted(hs)

    # ---- 5) 分配 ID（K-/BR-/P-ADD- 前缀，避免与现有 P-/J-/S- 冲突）----
    counters = {"K": 1, "BR": 1, "P-ADD": 1}
    existing_ids = {s["id"] for s in schools}
    for s in schools:
        if s.get("id"):
            continue
        if s["stage"] == "kindergarten":
            pre = "K"
        elif s.get("branchOf"):
            pre = "BR"
        else:
            pre = "P-ADD"
        n = counters[pre]
        cand = f"{pre}-{n:03d}"
        while cand in existing_ids:
            n += 1
            cand = f"{pre}-{n:03d}"
        counters[pre] = n + 1
        existing_ids.add(cand)
        s["id"] = cand

    # 清理 extra 内 null
    for s in schools:
        if isinstance(s.get("extra"), dict):
            s["extra"] = {k: v for k, v in s["extra"].items() if v is not None}

    # ---- 6) 写回 JSON ----
    with open(JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(schools, f, ensure_ascii=False, indent=2)
        f.write("\n")

    # ---- 7) 重生成 TS 快照 ----
    lines = []
    lines.append("// AUTO-GENERATED — 步骤19+ 学校库全量快照（含官方分类标签 honors / 名校分校 branchOf）。")
    lines.append("// 数据来源：4 区官方 2026 学区划分 PDF（小学/初中）+ 西安市 2026 普通高中招生计划（高中）")
    lines.append("//           + 西安市教育局/陕西省教育厅官方名单（省示范/市一级幼儿园、名校+、示范高中、名校分校）。")
    lines.append("// 请勿手改；如需更新请重跑 .pdfwork/label_schools.py 重新生成本文件。")
    lines.append('import type { GrowthSchool } from \'./growth-schools.ts\';')
    lines.append("")
    lines.append("export const VERIFIED_SCHOOLS_PREVIEW: GrowthSchool[] = [")
    for s in schools:
        obj = {k: s.get(k) for k in [
            "id", "name", "stage", "district", "ownership", "address",
            "tuitionText", "commuteText", "mealText", "foreignTeacherText",
            "classSizeText", "managementText", "curriculumTags", "featureTags",
            "enrollmentScope", "registrationMaterials", "sourceName", "sourceUrl",
            "sourceUpdatedAt", "verificationLevel", "verificationLabel",
            "verificationNote", "isDemo", "extra", "honors", "branchOf",
            "admissionScore", "admissionBatch", "admissionTier", "directionalPlan",
            "admissionUnit", "enrollmentPlan", "cutHistory", "keyClassInfo",
        ]}
        lines.append(json.dumps(obj, ensure_ascii=False) + ",")
    lines.append("];")
    lines.append("")
    with open(TS_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    # ---- 8) 统计 ----
    from collections import Counter
    stage_count = Counter(s["stage"] for s in schools)
    honor_count = Counter()
    for s in schools:
        for h in (s.get("honors") or []):
            honor_count[h] += 1
    branch_count = sum(1 for s in schools if s.get("branchOf"))
    print("总计条目:", len(schools))
    print("学段分布:", dict(stage_count))
    print("标签分布:", dict(honor_count))
    print("名校分校数(branchOf):", branch_count)


if __name__ == "__main__":
    main()

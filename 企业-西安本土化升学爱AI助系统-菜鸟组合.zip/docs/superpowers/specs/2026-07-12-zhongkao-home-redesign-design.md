# 中考志愿首页与付费动线重建设计

## 目标
恢复参考图中的“输入分数，找到更适合的高中”首页，形成免费测算、学校匹配、志愿模拟、套餐选择、订单创建和支付状态闭环。

## 根因
当前首页中文编码损坏，元信息仍是 Starter Project；生产指标混入验收事件；旧看板字段与 Worker 返回结构不一致；五档服务和付费动线未真正接上。

## 产品结构
首页包含顶部导航、免费测算 Hero、深蓝决策图、三项价值卡、三步能力区、明确下一步区、五档套餐、信任说明和页脚。免费测算收集分数、区县和策略，展示基础定位与有限匹配，不强制手机号。

套餐固定为 9.9、29.9、199、599、5999 元，分别对应打印版草案、完整学校匹配、不限次志愿模拟、老师审核一次和一对一升学规划。

## 订单与支付
微信和支付宝共用订单模型。订单包含 order_id、plan_id、amount、channel、status、session_id 和时间戳。前端不保存密钥；服务端从运行时环境读取支付配置。没有完整商户配置时只展示订单意向，不伪称已收款。

## 数据口径
正式事件包括 score_submitted、school_match_viewed、volunteer_simulation_started、volunteer_plan_generated、plan_selected、order_created、payment_succeeded 和 entitlement_unlocked。environment=test 的事件不进入生产指标。

## 验收
首页中文无乱码；测算、匹配、模拟和套餐选择可用；订单接口能明确区分待配置与已支付；指标排除测试数据；正式域名首页、采集、指标和订单接口均通过线上验证。
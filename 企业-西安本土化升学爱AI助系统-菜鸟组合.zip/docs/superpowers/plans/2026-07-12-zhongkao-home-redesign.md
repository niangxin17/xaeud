# 中考志愿首页与付费动线重建 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task.

**Goal:** 重建参考图首页、接通套餐订单动线、清理生产指标口径。

**Architecture:** Next 页面负责首页与结算确认；Cloudflare Worker 负责订单、支付回调、采集和指标；D1 保存订单和事件。微信与支付宝共用订单模型。

**Tech Stack:** Next/vinext、React、Tailwind、Cloudflare Worker、D1、Sites。

## Global Constraints
- 源码统一 UTF-8 无 BOM，页面不得乱码。
- 保留参考图的米白、深蓝、砖红和五档套餐价格。
- 未配置商户密钥时不得声称真实收款。
- 指标查询排除 environment=test。
- 发布前完成构建和线上接口回归。

### Task 1: 首页产品化
Files: app/page.tsx, app/layout.tsx, app/globals.css
- [ ] 修复 UTF-8 中文并重建 Hero、测算卡、决策图、三步区、五档套餐和信任区。
- [ ] 测算触发 score_submitted，套餐触发 plan_selected，进入结算确认。
- [ ] 更新 title、description、lang，移除 Starter Project 元数据。
- [ ] 运行 npm run build，预期成功。

### Task 2: 订单与支付边界
Files: worker/index.ts, app/checkout/page.tsx, test/order-flow.test.mjs
- [ ] POST /api/orders 接收 planId、channel、sessionId，返回 orderId、status、paymentReady。
- [ ] 校验套餐、金额和渠道白名单。
- [ ] 未配置商户密钥时支付回调返回 503，不伪造成功。
- [ ] 运行 node test/order-flow.test.mjs 与 npm run build。

### Task 3: 生产指标和看板
Files: worker/index.ts, app/dashboard/page.tsx, test/metrics-production.test.mjs
- [ ] 写测试验证 environment=test 不计入 total、sessions、counts、funnel、recent。
- [ ] 正式事件默认 environment=production。
- [ ] 看板显示真实字段并增加套餐、订单、支付事件。

### Task 4: 集成验收发布
Files: app/analytics.tsx, worker/index.ts
- [ ] 统一八个正式事件并带 environment=production。
- [ ] 运行完整构建和回归测试。
- [ ] 推送精确源码，保存 Sites 版本并部署正式域名。
- [ ] 线上验证首页 200、采集 204、未授权指标 401、授权指标 200、订单状态明确。
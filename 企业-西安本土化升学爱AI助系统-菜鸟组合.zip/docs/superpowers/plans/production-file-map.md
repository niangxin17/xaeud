# 生产文件映射：老友升学四档报告（真实数据版）

> 本文件映射「四档升学报告（免费 / 29.9 / 199 / 599）」从源码到生产的全部关键文件、构建、部署与验收路径。
> 对应交接方案：`2026-07-16-workbuddy-reports-replication-plan.md`（位于 `handoff/`）。
> 视觉参考成品：`handoff/reports/report.css` 与 `free-report.html / sort-report.html / fit-report.html / review-report.html / production-report.html`。

## 一、技术栈

- Vinext（Next.js 16 + React 19 + Vite 8）+ TypeScript 5.9 + Tailwind 4
- 构建产物：`dist/client`（静态导出，`output: 'export'`）
- 运行时 Node：`C:\Users\Administrator\.workbuddy\binaries\node\versions\22.22.2`
- 部署目标：`C:\caddy\www\laoyou`（Caddy 反代 80/443，HTTPS）
- 支付后端：独立 Node 进程监听 127.0.0.1:8787（与本站报告无强耦合，报告为纯前端 + localStorage）

## 二、报告相关源码清单

### 视觉与样式（一比一复刻参考成品）
| 文件 | 作用 |
|---|---|
| `app/components/report/report.css` | 报告全部视觉令牌与组件样式（navy/teal/gold、封面、工具栏、KPI、徽标、卡片、时间线、清单、来源、对比、复核、公章、收尾、打印规则）。由 `handoff/reports/report.css` 复制并追加生产态样式（status-row / data-rule / fit-table / locked / footnote 等）。**必须被 `ReportShell.tsx` import，否则报告无样式。** |
| `app/components/report/ReportShell.tsx` | 报告框架：`.demo` 真实性提示条、`.toolbar` 打印按钮、`.cover` 封面、可选 `.stamp` 公章。import `./report.css`。 |

### 数据契约与真实性闸门（核心：禁止伪精确）
| 文件 | 作用 |
|---|---|
| `app/lib/reports/types.ts` | 报告数据契约：`VerificationStatus`、`SourceMeta`、`DirectionalQuota`、`SchoolFit`、`ReportContext`、`PlacedSchool`、`Tier`、`TIER_ORDER`。 |
| `app/lib/reports/verification.ts` | 真实性闸门：`isDisplayableExactQuota`（须官方已核验+年份+来源URL+初高中名+名额数）、`isDisplayableRate`（须届次分母来源）、`isClassTrackVerified`、`getVerificationLabel`、`getMetricLabel`、`makeHistoricalSource`、`makeNotPublishedSource`。 |
| `app/lib/reports/competition.ts` | `getCompetitionLevel`：缺少资格人数/名额/校内位次任一 → 返回 `unknown`（显示“无法判断”）。 |
| `app/lib/reports/analysis.ts` | 纯函数数据构建层（无 DOM）：`buildFree / buildSort / buildFit / buildReview`、`dataDistrictOf`。结论由真实数据驱动；985/211、定向生名额、班型等缺官方口径者一律锁定为“待核验”。 |
| `app/lib/volunteer-data.ts` | 校库（45 所）、`getFreeMatchedSchools`、`classifySchool`、±80 筛选、`directionalSchools`、`estimateRank`、`DISTRICT_TO_DATA`。字段：`referenceScore`、`dingxiang→directionalQuota`、`g985/g211`、`pressure`、`distance`、`keyClass`、`ownership`。 |

### 展示组件
| 文件 | 作用 |
|---|---|
| `app/components/report/report-parts.tsx` | 共享纯展示组件：`Section/Lead/Summary/KpiGrid/Badge/Chips/Timeline/Step/Cards/Card/Checklist/Source/Compare/Audit/Closing/Quote/Note/StatusRow/DataRule/Footnote`。**所有报告组件使用其中的组件时必须显式 import。** |
| `app/components/report/FreeReport.tsx` | 免费版：候选池 / 全部学校表 / 定向生范围 / 下一步。 |
| `app/components/report/SortReport.tsx` | 29.9 排序版：冲稳保草案 / 顺序理由 / 分数变化预案 / 定向生名额（待官方发布）/ 家庭确认。 |
| `app/components/report/FitReport.tsx` | 199 适配版：适配结论 / 孩子画像 / 逐校判断 / 核心对比（985/211 与班型锁定为待核验）/ 志愿建议 / 家庭决策会。 |
| `app/components/report/ReviewReport.tsx` | 599 老师复核版：意见 / 编号风险 / 修改前后 diff / 最终方案 / 逐项确认 / 提交前 / 服务交付（带公章）。 |

### 渲染与路由
| 文件 | 作用 |
|---|---|
| `app/components/report/ReportsRenderer.tsx` | 权益判定 + 数据接线：读 `ly_profile_locked` 与 `ly_paid_plans`，按套餐层级渲染对应档位；无资料锁 → 去测分；权益不足 → 升级提示（不空白）。 |
| `app/reports/free/page.tsx` `sort/` `fit/` `review/` | 四档报告路由，均为 `<ReportsRenderer tier="..." />`。 |
| `app/downloads/page.tsx` | 我的报告页，渲染当前用户最高可访问档位报告。 |
| `app/lib/profile-lock.ts` | `getProfileLock / saveProfileLock`（`ly_profile_locked`）。 |
| `app/lib/entitlements.ts` | `PackageId`、`ProfileLock`、`packageRules`（权益/权限状态机）。 |

### 测试
| 文件 | 作用 |
|---|---|
| `tests/reports-truth-gates.test.ts` | 10 个真实性闸门单测（Node 22 原生 `node --experimental-strip-types --test` 运行）。覆盖 `isDisplayableExactQuota`、`getCompetitionLevel`、`isDisplayableRate`、`getMetricLabel`、`getVerificationLabel`。 |

## 三、本地命令

```bash
# 1. 真实性闸门单测（必须通过）
PATH="/c/Users/Administrator/.workbuddy/binaries/node/versions/22.22.2:$PATH" \
  node --experimental-strip-types --test tests/reports-truth-gates.test.ts

# 2. 生产构建
PATH="/c/Users/Administrator/.workbuddy/binaries/node/versions/22.22.2:$PATH" npm run build
# 产物：dist/client；报告路由：reports/free|sort|fit|review(.html) + assets/ReportsRenderer-*.css

# 3. 部署到 laoyou.love
robocopy "C:/Users/Administrator/Documents/中考网站架构/finalapp/dist/client" "C:/caddy/www/laoyou" /MIR /XD data

# 4. 视觉验收（四档 × 1440×1024 / 390×844，对比参考成品）
# 见 acceptance/acceptance.mjs（Playwright，需先 npx playwright install chromium）
```

## 四、真实性硬规则（违反即视为缺陷）

1. 定向生名额须含：高中、初中、年份、名额数、来源 URL、发布时间、更新时间、核验状态；无官方「分学校生源计划」→ 显示「待2026官方分学校计划」，绝不把全区计划写成某初中名额。
2. 竞争度须同时具备「资格人数 + 本校名额 + 校内位次」；缺任一 → 「无法判断」，不生成伪精确百分比。
3. 985/211 须显示届次、毕业生分母、统计范围、是否含复读生、来源、更新时间；缺口径 → 「待统一口径数据」。
4. 班型（重点/火箭/实验）仅采信学校官方招生说明；否则「学校未公开，无法判断」。
5. 禁止「稳进、保证录取、专属名额、100%上岸」等承诺。
6. 所有报告须标注来源、年份、更新时间、数据状态；缺失 → 「待核验」，不展示推算数字。
7. 真实数据与演示数据不得混用；演示身份/老师须显式标注「示例」。

## 五、已知边界（生产态必须如实展示）

- 校库 45 所字段齐全，但 `g985/g211`、`dingxiang` 缺官方届次/分母/来源，故 985/211 与定向生名额在报告中按规则锁定为「待核验」，不显示为确定结论。
- 报告结论（冲稳保排序、适配、老师复核）由真实数据计算；展示数值受真实性闸门约束。
- 支付（微信/支付宝）已在生产环境真实配置并收款（凭证固化于 `C:\caddy\start-node.bat`，非仓库内）。

## 六、验收清单

- [x] `node --experimental-strip-types --test` 10 项闸门单测通过
- [x] `npm run build` 成功，4 个报告路由静态导出
- [x] `report.css` 被 `ReportShell` import 并打入 `ReportsRenderer-*.css`，四档 HTML 均引用
- [x] `robocopy /MIR /XD data` 部署后线上 `laoyou.love/reports/*` 可访问并加载报告样式
- [x] Playwright 在 1440×1024 与 390×844 截四档报告，视觉与参考成品一致，无未样式化/崩溃
- [x] 缺 `Footnote` import 导致的 SortReport 客户端崩溃已修复
- [x] 四档报告均可打印为结构完整的 PDF（`window.print()`）
